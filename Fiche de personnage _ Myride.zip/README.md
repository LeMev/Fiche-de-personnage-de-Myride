
  # Fiche de personnage : Myride

  This is a code bundle for Fiche de personnage : Myride. The original project is available at https://www.figma.com/design/MZQD8PLZerlLAy3CkBk07i/Fiche-de-personnage---Myride.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  