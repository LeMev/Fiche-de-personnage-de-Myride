import { useState } from 'react';
import { CampaignManager } from './components/CampaignManager';
import { CharacterManager } from './components/CharacterManager';
import { CharacterSheet } from './components/CharacterSheet';
import { GroupInventoryManager } from './components/GroupInventoryManager';
import { PasswordGuard } from './components/PasswordGuard';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner@2.0.3';
import type { Campaign, Character } from './types/game';

type AppState = 
  | { view: 'campaigns' }
  | { view: 'characters'; campaign: Campaign }
  | { view: 'character'; character: Character }
  | { view: 'group-inventory'; campaign: Campaign; characters: Character[]; updateCampaign: (campaign: Campaign) => Promise<Campaign> };

export default function App() {
  const [appState, setAppState] = useState<AppState>({ view: 'campaigns' });
  const [pendingCharacter, setPendingCharacter] = useState<Character | null>(null);
  const [showPasswordGuard, setShowPasswordGuard] = useState(false);

  const handleSelectCampaign = (campaign: Campaign) => {
    setAppState({ view: 'characters', campaign });
  };

  const handleSelectCharacter = (character: Character) => {
    // Check if character is protected by password
    if (character.lock?.enabled) {
      setPendingCharacter(character);
      setShowPasswordGuard(true);
    } else {
      setAppState({ view: 'character', character });
    }
  };

  const handlePasswordSuccess = () => {
    if (pendingCharacter) {
      setAppState({ view: 'character', character: pendingCharacter });
    }
    setPendingCharacter(null);
    setShowPasswordGuard(false);
  };

  const handlePasswordCancel = () => {
    setPendingCharacter(null);
    setShowPasswordGuard(false);
  };

  const handleCharacterUpdate = (updatedCharacter: Character) => {
    // Update the character in the current app state
    if (appState.view === 'character') {
      setAppState({ view: 'character', character: updatedCharacter });
    }
  };

  const handleSelectGroupInventory = (campaign: Campaign, characters: Character[], updateCampaign: (campaign: Campaign) => Promise<Campaign>) => {
    setAppState({ view: 'group-inventory', campaign, characters, updateCampaign });
  };

  const handleBackToCampaigns = () => {
    setAppState({ view: 'campaigns' });
  };

  const handleBackToCharacters = () => {
    if (appState.view === 'character') {
      // Find the campaign for this character
      const campaignId = appState.character.campaignId;
      // For now, we'll create a minimal campaign object
      // In a real app, you might want to store the full campaign object
      const campaign: Campaign = {
        id: campaignId,
        name: 'Campagne', // This would be fetched from the backend
        createdAt: new Date().toISOString(),
      };
      setAppState({ view: 'characters', campaign });
    } else if (appState.view === 'group-inventory') {
      setAppState({ view: 'characters', campaign: appState.campaign });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {appState.view === 'campaigns' && (
        <CampaignManager onSelectCampaign={handleSelectCampaign} />
      )}
      
      {appState.view === 'characters' && (
        <CharacterManager 
          campaign={appState.campaign}
          onBack={handleBackToCampaigns}
          onSelectCharacter={handleSelectCharacter}
          onSelectGroupInventory={handleSelectGroupInventory}
        />
      )}
      
      {appState.view === 'character' && (
        <CharacterSheet 
          character={appState.character}
          onBack={handleBackToCharacters}
          onCharacterUpdate={handleCharacterUpdate}
        />
      )}
      
      {appState.view === 'group-inventory' && (
        <GroupInventoryManager
          campaign={appState.campaign}
          characters={appState.characters}
          onUpdateCampaign={async (campaign) => {
            try {
              const updatedCampaign = await appState.updateCampaign(campaign);
              setAppState({ ...appState, campaign: updatedCampaign });
            } catch (error) {
              console.error('Error updating campaign:', error);
              toast.error('Erreur lors de la sauvegarde de l\'inventaire de groupe');
              // Fall back to local state update
              setAppState({ ...appState, campaign });
            }
          }}
          onUpdateCharacter={(character) => {
            const updatedCharacters = appState.characters.map(c => 
              c.id === character.id ? character : c
            );
            setAppState({ ...appState, characters: updatedCharacters });
          }}
          onBack={handleBackToCharacters}
        />
      )}
      
      <PasswordGuard
        character={pendingCharacter}
        open={showPasswordGuard}
        onSuccess={handlePasswordSuccess}
        onCancel={handlePasswordCancel}
      />
      
      <Toaster />
    </div>
  );
}