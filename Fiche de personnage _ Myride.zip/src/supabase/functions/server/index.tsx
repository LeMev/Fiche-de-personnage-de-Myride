import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import type { Campaign, Character, GlossaryItem, GlossaryFolder } from "../../../types/game.ts";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-7fc223a6/health", (c) => {
  return c.json({ status: "ok" });
});

// Campaign routes
app.get("/make-server-7fc223a6/campaigns", async (c) => {
  try {
    const campaigns = await kv.getByPrefix("campaign:");
    return c.json(campaigns || []);
  } catch (error) {
    console.log(`Error getting campaigns: ${error}`);
    return c.json({ error: "Failed to get campaigns" }, 500);
  }
});

app.post("/make-server-7fc223a6/campaigns", async (c) => {
  try {
    const body = await c.req.json();
    const campaign: Campaign = {
      id: crypto.randomUUID(),
      name: body.name,
      description: body.description,
      createdAt: new Date().toISOString(),
    };
    
    await kv.set(`campaign:${campaign.id}`, campaign);
    return c.json(campaign);
  } catch (error) {
    console.log(`Error creating campaign: ${error}`);
    return c.json({ error: "Failed to create campaign" }, 500);
  }
});

app.put("/make-server-7fc223a6/campaigns/:id", async (c) => {
  try {
    const campaignId = c.req.param("id");
    const body = await c.req.json();
    
    // Get existing campaign
    const existingCampaign = await kv.get(`campaign:${campaignId}`);
    if (!existingCampaign) {
      return c.json({ error: "Campaign not found" }, 404);
    }
    
    const updatedCampaign = {
      ...existingCampaign,
      ...body,
      id: campaignId,
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`campaign:${campaignId}`, updatedCampaign);
    return c.json(updatedCampaign);
  } catch (error) {
    console.log(`Error updating campaign: ${error}`);
    return c.json({ error: "Failed to update campaign" }, 500);
  }
});

app.delete("/make-server-7fc223a6/campaigns/:id", async (c) => {
  try {
    const campaignId = c.req.param("id");
    
    // Delete all characters in this campaign
    const characters = await kv.getByPrefix(`character:${campaignId}:`);
    const characterKeys = characters.map((char: Character) => `character:${campaignId}:${char.id}`);
    if (characterKeys.length > 0) {
      await kv.mdel(characterKeys);
    }
    
    // Delete the campaign
    await kv.del(`campaign:${campaignId}`);
    
    return c.json({ success: true });
  } catch (error) {
    console.log(`Error deleting campaign: ${error}`);
    return c.json({ error: "Failed to delete campaign" }, 500);
  }
});

// Character routes
app.get("/make-server-7fc223a6/campaigns/:campaignId/characters", async (c) => {
  try {
    const campaignId = c.req.param("campaignId");
    const characters = await kv.getByPrefix(`character:${campaignId}:`);
    return c.json(characters || []);
  } catch (error) {
    console.log(`Error getting characters: ${error}`);
    return c.json({ error: "Failed to get characters" }, 500);
  }
});

app.post("/make-server-7fc223a6/campaigns/:campaignId/characters", async (c) => {
  try {
    const campaignId = c.req.param("campaignId");
    const body = await c.req.json();
    
    const character: Character = {
      id: crypto.randomUUID(),
      campaignId,
      role: body.role || 'PC',
      name: body.name,
      aliases: [],
      race: body.race || '',
      class: body.class || '',
      level: body.level || 1,
      age: body.age || 20,
      alignment: body.alignment || '',
      combatStance: body.combatStance || '',
      appearance: '',
      distinctiveSign: '',
      attributes: {
        corps: 10,
        vitalité: 10,
        esprit: 10,
        habilité: 10,
        sociale: 10,
        pouvoir: 10,
      },
      skills: {
        corps: { mouvement: 0, mêlée: 0, puissance: 0 },
        vitalité: { endurance: 0, résistance: 0, récupération: 0 },
        esprit: { perception: 0, analyse: 0, volonté: 0 },
        habilité: { distance: 0, discrétion: 0, talent: 0 },
        sociale: { persuasion: 0, intimidation: 0, représentation: 0 },
        pouvoir: { incantation: 0, canalisation: 0, rituel: 0 },
      },
      skillMastery: {},
      progression: {
        availableSkillPoints: 0,
      },
      resources: {
        hp: { current: 20, max: 20 },
        mp: { current: 10, max: 10 },
        totalArmor: 0,
        armorAutocalcEnabled: true,
        armorManualValue: 0,
        custom: [],
      },
      magic: {
        schools: [],
        expandedSchools: [],
      },
      abilities: [],
      abilityFolders: [],
      background: {
        origin: '',
        family: '',
        personality: '',
        objectives: '',
        languages: [],
      },
      inventory: {
        items: [],
        folders: [],
        currency: {
          bronze: 0,
          silver: 0,
          gold: 0,
        },
        totalWeight: 0,
      },
      focus: {
        active: false,
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`character:${campaignId}:${character.id}`, character);
    return c.json(character);
  } catch (error) {
    console.log(`Error creating character: ${error}`);
    return c.json({ error: "Failed to create character" }, 500);
  }
});

app.put("/make-server-7fc223a6/characters/:id", async (c) => {
  try {
    const characterId = c.req.param("id");
    const body = await c.req.json();
    
    // Find the character first to get the campaign ID
    const existingCharacter = await kv.get(`character:${body.campaignId}:${characterId}`);
    if (!existingCharacter) {
      return c.json({ error: "Character not found" }, 404);
    }
    
    const updatedCharacter = {
      ...existingCharacter,
      ...body,
      id: characterId,
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`character:${body.campaignId}:${characterId}`, updatedCharacter);
    return c.json(updatedCharacter);
  } catch (error) {
    console.log(`Error updating character: ${error}`);
    return c.json({ error: "Failed to update character" }, 500);
  }
});

app.delete("/make-server-7fc223a6/characters/:campaignId/:id", async (c) => {
  try {
    const campaignId = c.req.param("campaignId");
    const characterId = c.req.param("id");
    
    await kv.del(`character:${campaignId}:${characterId}`);
    return c.json({ success: true });
  } catch (error) {
    console.log(`Error deleting character: ${error}`);
    return c.json({ error: "Failed to delete character" }, 500);
  }
});

// Glossary routes
app.get("/make-server-7fc223a6/glossary", async (c) => {
  try {
    console.log("📖 [Glossary] GET /glossary - Loading all items and folders");
    
    const items = await kv.getByPrefix("glossary:item:");
    const folders = await kv.getByPrefix("glossary:folder:");
    
    console.log(`✅ [Glossary] Loaded ${items.length} items and ${folders.length} folders`);
    
    return c.json({
      items: items || [],
      folders: folders || [],
    });
  } catch (error) {
    console.error(`❌ [Glossary] Error getting glossary: ${error}`);
    return c.json({ error: `Failed to get glossary: ${error.message}` }, 500);
  }
});

app.post("/make-server-7fc223a6/glossary/items", async (c) => {
  try {
    const body = await c.req.json();
    console.log("📝 [Glossary] POST /glossary/items - Creating item:", body.name);
    
    const item: GlossaryItem = {
      id: crypto.randomUUID(),
      type: body.type,
      name: body.name,
      school: body.school,
      tags: body.tags || [],
      folderId: body.folderId,
      description: body.description || '',
      costProfiles: body.costProfiles || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      source: body.source || 'user',
      activationType: body.activationType,
      frequency: body.frequency,
      prerequisites: body.prerequisites,
      effects: body.effects,
      range: body.range,
      duration: body.duration,
      scaling: body.scaling,
      limitations: body.limitations,
    };
    
    await kv.set(`glossary:item:${item.id}`, item);
    console.log(`✅ [Glossary] Created item: ${item.id}`);
    
    return c.json({ data: item });
  } catch (error) {
    console.error(`❌ [Glossary] Error creating item: ${error}`);
    return c.json({ error: `Failed to create item: ${error.message}` }, 500);
  }
});

app.put("/make-server-7fc223a6/glossary/items/:id", async (c) => {
  try {
    const itemId = c.req.param("id");
    const body = await c.req.json();
    console.log(`✏️ [Glossary] PUT /glossary/items/${itemId} - Updating item`);
    
    // Get existing item
    const existingItem = await kv.get(`glossary:item:${itemId}`);
    if (!existingItem) {
      console.error(`❌ [Glossary] Item not found: ${itemId}`);
      return c.json({ error: "Item not found" }, 404);
    }
    
    const updatedItem = {
      ...existingItem,
      ...body,
      id: itemId,
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`glossary:item:${itemId}`, updatedItem);
    console.log(`✅ [Glossary] Updated item: ${itemId}`);
    
    return c.json({ data: updatedItem });
  } catch (error) {
    console.error(`❌ [Glossary] Error updating item: ${error}`);
    return c.json({ error: `Failed to update item: ${error.message}` }, 500);
  }
});

app.delete("/make-server-7fc223a6/glossary/items/:id", async (c) => {
  try {
    const itemId = c.req.param("id");
    console.log(`🗑️ [Glossary] DELETE /glossary/items/${itemId}`);
    
    await kv.del(`glossary:item:${itemId}`);
    console.log(`✅ [Glossary] Deleted item: ${itemId}`);
    
    return c.json({ success: true });
  } catch (error) {
    console.error(`❌ [Glossary] Error deleting item: ${error}`);
    return c.json({ error: `Failed to delete item: ${error.message}` }, 500);
  }
});

app.post("/make-server-7fc223a6/glossary/folders", async (c) => {
  try {
    const body = await c.req.json();
    console.log("📁 [Glossary] POST /glossary/folders - Creating folder:", body.name);
    
    const folder: GlossaryFolder = {
      id: crypto.randomUUID(),
      parentId: body.parentId,
      name: body.name,
      order: body.order || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`glossary:folder:${folder.id}`, folder);
    console.log(`✅ [Glossary] Created folder: ${folder.id}`);
    
    return c.json({ data: folder });
  } catch (error) {
    console.error(`❌ [Glossary] Error creating folder: ${error}`);
    return c.json({ error: `Failed to create folder: ${error.message}` }, 500);
  }
});

app.put("/make-server-7fc223a6/glossary/folders/:id", async (c) => {
  try {
    const folderId = c.req.param("id");
    const body = await c.req.json();
    console.log(`✏️ [Glossary] PUT /glossary/folders/${folderId} - Updating folder`);
    
    // Get existing folder
    const existingFolder = await kv.get(`glossary:folder:${folderId}`);
    if (!existingFolder) {
      console.error(`❌ [Glossary] Folder not found: ${folderId}`);
      return c.json({ error: "Folder not found" }, 404);
    }
    
    const updatedFolder = {
      ...existingFolder,
      ...body,
      id: folderId,
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`glossary:folder:${folderId}`, updatedFolder);
    console.log(`✅ [Glossary] Updated folder: ${folderId}`);
    
    return c.json({ data: updatedFolder });
  } catch (error) {
    console.error(`❌ [Glossary] Error updating folder: ${error}`);
    return c.json({ error: `Failed to update folder: ${error.message}` }, 500);
  }
});

app.delete("/make-server-7fc223a6/glossary/folders/:id", async (c) => {
  try {
    const folderId = c.req.param("id");
    console.log(`🗑️ [Glossary] DELETE /glossary/folders/${folderId}`);
    
    // Check if folder has items
    const items = await kv.getByPrefix("glossary:item:");
    const hasItems = items.some((item: GlossaryItem) => item.folderId === folderId);
    
    if (hasItems) {
      console.error(`❌ [Glossary] Cannot delete folder with items: ${folderId}`);
      return c.json({ error: "Cannot delete folder with items" }, 400);
    }
    
    await kv.del(`glossary:folder:${folderId}`);
    console.log(`✅ [Glossary] Deleted folder: ${folderId}`);
    
    return c.json({ success: true });
  } catch (error) {
    console.error(`❌ [Glossary] Error deleting folder: ${error}`);
    return c.json({ error: `Failed to delete folder: ${error.message}` }, 500);
  }
});

app.post("/make-server-7fc223a6/glossary/items/move", async (c) => {
  try {
    const body = await c.req.json();
    const { itemIds, folderId } = body;
    console.log(`📦 [Glossary] POST /glossary/items/move - Moving ${itemIds.length} items to folder:`, folderId || 'root');
    
    // Update each item's folderId
    for (const itemId of itemIds) {
      const item = await kv.get(`glossary:item:${itemId}`);
      if (item) {
        const updatedItem = {
          ...item,
          folderId: folderId || undefined,
          updatedAt: new Date().toISOString(),
        };
        await kv.set(`glossary:item:${itemId}`, updatedItem);
      } else {
        console.warn(`⚠️ [Glossary] Item not found during move: ${itemId}`);
      }
    }
    
    console.log(`✅ [Glossary] Moved ${itemIds.length} items`);
    return c.json({ success: true });
  } catch (error) {
    console.error(`❌ [Glossary] Error moving items: ${error}`);
    return c.json({ error: `Failed to move items: ${error.message}` }, 500);
  }
});

Deno.serve(app.fetch);