import { glossaryApi } from '../hooks/useApi';
import { normalizeGlossaryItemForSave } from '../utils/glossaryUtils';
import type { GlossaryItem, GlossaryFolder } from '../types/game';

const CACHE_KEY = 'myride.glossary.cache';
const CACHE_VERSION = 1;

interface GlossaryCache {
  version: number;
  items: GlossaryItem[];
  folders: GlossaryFolder[];
  lastSync: string;
}

/**
 * GlossaryRepository - Unified persistence layer for Glossary
 * Features:
 * - In-memory cache + localStorage fallback
 * - Optimistic updates with rollback on error
 * - Automatic ID management (temporary IDs replaced by server IDs)
 */
class GlossaryRepositoryClass {
  private cache: { items: GlossaryItem[]; folders: GlossaryFolder[] } | null = null;
  private loading = false;

  /**
   * Load glossary from server → cache → localStorage (offline fallback)
   */
  async load(): Promise<{ items: GlossaryItem[]; folders: GlossaryFolder[] }> {
    if (this.loading) {
      // Wait for existing load to complete
      while (this.loading) {
        await new Promise(resolve => setTimeout(resolve, 50));
      }
      return this.cache || { items: [], folders: [] };
    }

    // Return cache if already loaded
    if (this.cache) {
      return this.cache;
    }

    this.loading = true;
    
    try {
      // Try server first
      const data = await glossaryApi.getGlossary();
      this.cache = data;
      
      // Save to localStorage for offline access
      this.saveToLocalStorage(data);
      
      return data;
    } catch (error) {
      console.warn('Failed to load from server, trying localStorage:', error);
      
      // Fallback to localStorage
      const localData = this.loadFromLocalStorage();
      if (localData) {
        this.cache = localData;
        return localData;
      }
      
      // No data available, return empty
      this.cache = { items: [], folders: [] };
      return this.cache;
    } finally {
      this.loading = false;
    }
  }

  /**
   * Create a new glossary item
   */
  async createItem(input: Omit<GlossaryItem, 'id' | 'createdAt' | 'updatedAt'>): Promise<GlossaryItem> {
    // Normalize input
    const normalized = normalizeGlossaryItemForSave(input) as typeof input;
    
    // Generate temporary ID for optimistic UI
    const tempId = `tmp-${Date.now()}-${Math.random()}`;
    const tempItem: GlossaryItem = {
      ...normalized,
      id: tempId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as GlossaryItem;
    
    // Optimistic update
    if (this.cache) {
      this.cache.items = [...this.cache.items, tempItem];
    }
    
    try {
      // Save to server
      const savedItem = await glossaryApi.createGlossaryItem(normalized);
      
      // Replace temp item with server item
      if (this.cache) {
        this.cache.items = this.cache.items.map(item => 
          item.id === tempId ? savedItem : item
        );
        this.saveToLocalStorage(this.cache);
      }
      
      return savedItem;
    } catch (error) {
      // Rollback on error
      if (this.cache) {
        this.cache.items = this.cache.items.filter(item => item.id !== tempId);
      }
      throw error;
    }
  }

  /**
   * Update an existing glossary item
   */
  async updateItem(id: string, patch: Partial<GlossaryItem>): Promise<GlossaryItem> {
    // Normalize patch
    const normalized = normalizeGlossaryItemForSave(patch);
    
    // Store original for rollback
    const originalItem = this.cache?.items.find(item => item.id === id);
    if (!originalItem) {
      throw new Error(`Item ${id} not found in cache`);
    }
    
    // Optimistic update
    const optimisticItem = { ...originalItem, ...normalized };
    if (this.cache) {
      this.cache.items = this.cache.items.map(item =>
        item.id === id ? optimisticItem : item
      );
    }
    
    try {
      // Save to server
      const savedItem = await glossaryApi.updateGlossaryItem(id, normalized);
      
      // Update cache with server response
      if (this.cache) {
        this.cache.items = this.cache.items.map(item =>
          item.id === id ? savedItem : item
        );
        this.saveToLocalStorage(this.cache);
      }
      
      return savedItem;
    } catch (error) {
      // Rollback on error
      if (this.cache) {
        this.cache.items = this.cache.items.map(item =>
          item.id === id ? originalItem : item
        );
      }
      throw error;
    }
  }

  /**
   * Delete glossary item(s)
   */
  async deleteItem(ids: string | string[]): Promise<void> {
    const idsArray = Array.isArray(ids) ? ids : [ids];
    
    // Store originals for rollback
    const originalItems = this.cache?.items.filter(item => 
      idsArray.includes(item.id)
    ) || [];
    
    // Optimistic update
    if (this.cache) {
      this.cache.items = this.cache.items.filter(item => 
        !idsArray.includes(item.id)
      );
    }
    
    try {
      // Delete from server
      await Promise.all(
        idsArray.map(id => glossaryApi.deleteGlossaryItem(id))
      );
      
      // Update localStorage
      if (this.cache) {
        this.saveToLocalStorage(this.cache);
      }
    } catch (error) {
      // Rollback on error
      if (this.cache && originalItems.length > 0) {
        this.cache.items = [...this.cache.items, ...originalItems];
      }
      throw error;
    }
  }

  /**
   * Create a new folder
   */
  async createFolder(input: Omit<GlossaryFolder, 'id' | 'createdAt' | 'updatedAt'>): Promise<GlossaryFolder> {
    // Generate temporary ID
    const tempId = `tmp-${Date.now()}-${Math.random()}`;
    const tempFolder: GlossaryFolder = {
      ...input,
      id: tempId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    // Optimistic update
    if (this.cache) {
      this.cache.folders = [...this.cache.folders, tempFolder];
    }
    
    try {
      // Save to server
      const savedFolder = await glossaryApi.createGlossaryFolder(input);
      
      // Replace temp folder with server folder
      if (this.cache) {
        this.cache.folders = this.cache.folders.map(folder => 
          folder.id === tempId ? savedFolder : folder
        );
        this.saveToLocalStorage(this.cache);
      }
      
      return savedFolder;
    } catch (error) {
      // Rollback on error
      if (this.cache) {
        this.cache.folders = this.cache.folders.filter(folder => folder.id !== tempId);
      }
      throw error;
    }
  }

  /**
   * Update an existing folder
   */
  async updateFolder(id: string, patch: Partial<GlossaryFolder>): Promise<GlossaryFolder> {
    // Store original for rollback
    const originalFolder = this.cache?.folders.find(folder => folder.id === id);
    if (!originalFolder) {
      throw new Error(`Folder ${id} not found in cache`);
    }
    
    // Optimistic update
    const optimisticFolder = { 
      ...originalFolder, 
      ...patch,
      updatedAt: new Date().toISOString(),
    };
    if (this.cache) {
      this.cache.folders = this.cache.folders.map(folder =>
        folder.id === id ? optimisticFolder : folder
      );
    }
    
    try {
      // Save to server
      const savedFolder = await glossaryApi.updateGlossaryFolder(id, patch);
      
      // Update cache with server response
      if (this.cache) {
        this.cache.folders = this.cache.folders.map(folder =>
          folder.id === id ? savedFolder : folder
        );
        this.saveToLocalStorage(this.cache);
      }
      
      return savedFolder;
    } catch (error) {
      // Rollback on error
      if (this.cache) {
        this.cache.folders = this.cache.folders.map(folder =>
          folder.id === id ? originalFolder : folder
        );
      }
      throw error;
    }
  }

  /**
   * Delete folder
   */
  async deleteFolder(id: string): Promise<void> {
    // Store original for rollback
    const originalFolder = this.cache?.folders.find(folder => folder.id === id);
    
    // Check if folder is not empty
    const hasItems = this.cache?.items.some(item => item.folderId === id);
    if (hasItems) {
      throw new Error('Cannot delete folder with items. Move items first.');
    }
    
    // Optimistic update
    if (this.cache) {
      this.cache.folders = this.cache.folders.filter(folder => folder.id !== id);
    }
    
    try {
      // Delete from server
      await glossaryApi.deleteGlossaryFolder(id);
      
      // Update localStorage
      if (this.cache) {
        this.saveToLocalStorage(this.cache);
      }
    } catch (error) {
      // Rollback on error
      if (this.cache && originalFolder) {
        this.cache.folders = [...this.cache.folders, originalFolder];
      }
      throw error;
    }
  }

  /**
   * Move items to a folder (or to root if folderId is null)
   */
  async moveItemsToFolder(itemIds: string[], folderId: string | null): Promise<void> {
    // Store originals for rollback
    const originalItems = this.cache?.items.filter(item =>
      itemIds.includes(item.id)
    ) || [];
    
    // Optimistic update
    if (this.cache) {
      this.cache.items = this.cache.items.map(item =>
        itemIds.includes(item.id)
          ? { ...item, folderId: folderId || undefined }
          : item
      );
    }
    
    try {
      // Move on server
      await glossaryApi.moveItemsToFolder(itemIds, folderId);
      
      // Update localStorage
      if (this.cache) {
        this.saveToLocalStorage(this.cache);
      }
    } catch (error) {
      // Rollback on error
      if (this.cache && originalItems.length > 0) {
        this.cache.items = this.cache.items.map(item => {
          const original = originalItems.find(o => o.id === item.id);
          return original || item;
        });
      }
      throw error;
    }
  }

  /**
   * Get current cache (synchronous)
   */
  getCache(): { items: GlossaryItem[]; folders: GlossaryFolder[] } | null {
    return this.cache;
  }

  /**
   * Clear cache (force reload on next access)
   */
  clearCache(): void {
    this.cache = null;
  }

  /**
   * Save to localStorage
   */
  private saveToLocalStorage(data: { items: GlossaryItem[]; folders: GlossaryFolder[] }): void {
    try {
      const cacheData: GlossaryCache = {
        version: CACHE_VERSION,
        items: data.items,
        folders: data.folders,
        lastSync: new Date().toISOString(),
      };
      localStorage.setItem(CACHE_KEY, JSON.stringify(cacheData));
    } catch (error) {
      console.warn('Failed to save to localStorage:', error);
    }
  }

  /**
   * Load from localStorage
   */
  private loadFromLocalStorage(): { items: GlossaryItem[]; folders: GlossaryFolder[] } | null {
    try {
      const cached = localStorage.getItem(CACHE_KEY);
      if (!cached) return null;
      
      const parsed: GlossaryCache = JSON.parse(cached);
      
      // Version check
      if (parsed.version !== CACHE_VERSION) {
        console.warn('Cache version mismatch, clearing cache');
        localStorage.removeItem(CACHE_KEY);
        return null;
      }
      
      return {
        items: parsed.items || [],
        folders: parsed.folders || [],
      };
    } catch (error) {
      console.warn('Failed to load from localStorage:', error);
      return null;
    }
  }
}

// Singleton instance
export const GlossaryRepository = new GlossaryRepositoryClass();
