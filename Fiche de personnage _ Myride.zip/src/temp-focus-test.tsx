import React from 'react';
import { Button } from './components/ui/button';
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from './components/ui/tooltip';
import { Focus } from 'lucide-react';

// Test rapide du bouton Focus
export function FocusTest() {
  const [focusActive, setFocusActive] = React.useState(false);

  return (
    <div className="p-4">
      <h3>Test du bouton Focus</h3>
      <div className="mt-4">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant={focusActive ? "default" : "outline"}
                size="sm"
                onClick={() => setFocusActive(!focusActive)}
                aria-pressed={focusActive}
                className={focusActive ? "gap-2" : ""}
              >
                <Focus className="w-4 h-4" />
                {focusActive ? "Focus (–1 PM)" : "Focus"}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Réduit de 1 PM tous les coûts en PM tant que Focus est activé</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      <div className="mt-4">
        <p>État Focus : {focusActive ? "Activé" : "Désactivé"}</p>
        <p>Test calcul coût : 3 PM → {focusActive ? Math.max(0, 3 - 1) : 3} PM</p>
        <p>Test calcul coût : 1 PM → {focusActive ? Math.max(0, 1 - 1) : 1} PM</p>
        <p>Test calcul coût : 0 PM → {focusActive ? Math.max(0, 0 - 1) : 0} PM</p>
      </div>
    </div>
  );
}