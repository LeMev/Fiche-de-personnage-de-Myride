import type { 
  Character, 
  CharacteristicDefinition, 
  SkillDefinition, 
  MasteryTier, 
  AttributeValidationResult, 
  SkillAllocationResult 
} from '../types/game';

// Constants
export const BASE_ATTRIBUTE_VALUE = 10;
export const MIN_ATTRIBUTE_VALUE = 10;
export const MAX_ATTRIBUTE_VALUE = 70;
export const ADDITIONAL_POINTS_BUDGET = 220;
export const EXPECTED_TOTAL = 280; // 6 * 10 + 220

// Helper object for easy access to skills by attribute
export const SKILLS_BY_ATTRIBUTE = {
  corps: ['mouvement', 'mêlée', 'puissance'],
  vitalité: ['endurance', 'résistance', 'récupération'],
  esprit: ['perception', 'analyse', 'volonté'],
  habilité: ['distance', 'discrétion', 'talent'],
  sociale: ['persuasion', 'intimidation', 'représentation'],
  pouvoir: ['incantation', 'canalisation', 'rituel']
} as const;

// Helper object for attribute labels
export const ATTRIBUTE_LABELS = {
  corps: 'Corps',
  vitalité: 'Vitalité',
  esprit: 'Esprit',
  habilité: 'Habilité',
  sociale: 'Sociale',
  pouvoir: 'Pouvoir'
} as const;

// Helper object for skill labels
export const SKILL_LABELS = {
  mouvement: 'Mouvement',
  mêlée: 'Mêlée',
  puissance: 'Puissance',
  endurance: 'Endurance',
  résistance: 'Résistance',
  récupération: 'Récupération',
  perception: 'Perception',
  analyse: 'Analyse',
  volonté: 'Volonté',
  distance: 'Distance',
  discrétion: 'Discrétion',
  talent: 'Talent',
  persuasion: 'Persuasion',
  intimidation: 'Intimidation',
  représentation: 'Représentation',
  incantation: 'Incantation',
  canalisation: 'Canalisation',
  rituel: 'Rituel'
} as const;

// Characteristic definitions with their skills
export const CHARACTERISTICS: CharacteristicDefinition[] = [
  {
    name: 'corps',
    label: 'Corps',
    skills: [
      { key: 'mouvement', label: 'Mouvement', characteristic: 'corps' },
      { key: 'mêlée', label: 'Mêlée', characteristic: 'corps' },
      { key: 'puissance', label: 'Puissance', characteristic: 'corps' }
    ]
  },
  {
    name: 'vitalité',
    label: 'Vitalité',
    skills: [
      { key: 'endurance', label: 'Endurance', characteristic: 'vitalité' },
      { key: 'résistance', label: 'Résistance', characteristic: 'vitalité' },
      { key: 'récupération', label: 'Récupération', characteristic: 'vitalité' }
    ]
  },
  {
    name: 'esprit',
    label: 'Esprit',
    skills: [
      { key: 'perception', label: 'Perception', characteristic: 'esprit' },
      { key: 'analyse', label: 'Analyse', characteristic: 'esprit' },
      { key: 'volonté', label: 'Volonté', characteristic: 'esprit' }
    ]
  },
  {
    name: 'habilité',
    label: 'Habilité',
    skills: [
      { key: 'distance', label: 'Distance', characteristic: 'habilité' },
      { key: 'discrétion', label: 'Discrétion', characteristic: 'habilité' },
      { key: 'talent', label: 'Talent', characteristic: 'habilité' }
    ]
  },
  {
    name: 'sociale',
    label: 'Sociale',
    skills: [
      { key: 'persuasion', label: 'Persuasion', characteristic: 'sociale' },
      { key: 'intimidation', label: 'Intimidation', characteristic: 'sociale' },
      { key: 'représentation', label: 'Représentation', characteristic: 'sociale' }
    ]
  },
  {
    name: 'pouvoir',
    label: 'Pouvoir',
    skills: [
      { key: 'incantation', label: 'Incantation', characteristic: 'pouvoir' },
      { key: 'canalisation', label: 'Canalisation', characteristic: 'pouvoir' },
      { key: 'rituel', label: 'Rituel', characteristic: 'pouvoir' }
    ]
  }
];

// Mastery tiers with their effects
export const MASTERY_TIERS: MasteryTier[] = [
  {
    level: 0,
    name: 'Novice',
    description: 'Aucun bonus particulier'
  },
  {
    level: 5,
    name: 'Adepte',
    description: 'Réussite critique améliorée',
    criticalSuccess: 'Réussite critique à 6 ou moins'
  },
  {
    level: 10,
    name: 'Maîtrise',
    description: 'Une relance par long repos',
    special: '1 relance d\'un échec non-critique par long repos'
  },
  {
    level: 15,
    name: 'Expertise',
    description: 'Échec critique réduit',
    criticalFailure: 'Échec critique à 97 ou plus'
  },
  {
    level: 20,
    name: 'Maître',
    description: 'Réussite critique maximale',
    criticalSuccess: 'Réussite critique à 7 ou moins'
  }
];

// Calculate remaining points for attribute allocation
export function getRemainingPoints(attributes: Character['attributes']): number {
  const totalSpent = getTotal(attributes) - (BASE_ATTRIBUTE_VALUE * 6);
  return ADDITIONAL_POINTS_BUDGET - totalSpent;
}

// Calculate total attribute points
export function getTotal(attributes: Character['attributes']): number {
  return Object.values(attributes).reduce((sum, value) => sum + value, 0);
}

// Check if attributes are within bounds
export function isWithinBounds(attributes: Character['attributes']): boolean {
  return Object.values(attributes).every(value => 
    value >= MIN_ATTRIBUTE_VALUE && value <= MAX_ATTRIBUTE_VALUE
  );
}

// Validate attribute allocation
export function validateAttributes(attributes: Character['attributes']): AttributeValidationResult {
  const totalPoints = getTotal(attributes);
  const remainingPoints = getRemainingPoints(attributes);
  const withinBounds = isWithinBounds(attributes);
  const errors: string[] = [];

  if (!withinBounds) {
    const invalidAttrs = Object.entries(attributes).filter(([_, value]) => 
      value < MIN_ATTRIBUTE_VALUE || value > MAX_ATTRIBUTE_VALUE
    );
    errors.push(`Caractéristiques hors limites (${MIN_ATTRIBUTE_VALUE}-${MAX_ATTRIBUTE_VALUE}): ${invalidAttrs.map(([name]) => name).join(', ')}`);
  }

  if (remainingPoints < 0) {
    errors.push(`Budget dépassé de ${Math.abs(remainingPoints)} points`);
  }

  return {
    isValid: errors.length === 0,
    remainingPoints,
    totalPoints,
    expectedTotal: EXPECTED_TOTAL,
    maxBudget: ADDITIONAL_POINTS_BUDGET,
    errors
  };
}

// Calculate skill point allocation for a characteristic
export function getSkillPointsForCharacteristic(characteristicValue: number): number {
  return Math.ceil(characteristicValue / 10);
}

// Calculate skill allocation status for all characteristics
export function calculateSkillAllocation(character: Character): SkillAllocationResult {
  const result: SkillAllocationResult = {};

  CHARACTERISTICS.forEach(char => {
    const available = getSkillPointsForCharacteristic(character.attributes[char.name]);
    const skillValues = character.skills[char.name];
    const used = Object.values(skillValues).reduce((sum, value) => sum + value, 0);
    
    result[char.name] = {
      available,
      used,
      canSpend: available + character.progression.availableSkillPoints
    };
  });

  return result;
}

// Get mastery tier for a skill based on its point value
export function getMasteryTier(skillPoints: number): MasteryTier {
  if (skillPoints >= 20) return MASTERY_TIERS[4]; // Maître
  if (skillPoints >= 15) return MASTERY_TIERS[3]; // Expertise
  if (skillPoints >= 10) return MASTERY_TIERS[2]; // Maîtrise
  if (skillPoints >= 5) return MASTERY_TIERS[1];  // Adepte
  return MASTERY_TIERS[0]; // Novice
}

// Calculate skill bonus percentage
export function getSkillBonus(skillPoints: number): number {
  return skillPoints; // +1% per point
}

// Get all skills with their current mastery
export function getCharacterSkillMastery(character: Character): Record<string, { 
  points: number; 
  tier: MasteryTier; 
  bonus: number; 
  rerollsAvailable: number; 
}> {
  const result: Record<string, any> = {};

  CHARACTERISTICS.forEach(char => {
    const skillValues = character.skills[char.name];
    
    Object.entries(skillValues).forEach(([skillKey, points]) => {
      const fullSkillName = `${char.name}.${skillKey}`;
      const tier = getMasteryTier(points);
      const bonus = getSkillBonus(points);
      const masteryData = character.skillMastery[fullSkillName];
      
      result[fullSkillName] = {
        points,
        tier,
        bonus,
        rerollsAvailable: masteryData?.rerollsAvailable || (tier.level === 10 ? 1 : 0)
      };
    });
  });

  return result;
}

// Initialize default attributes for new character
export function createDefaultAttributes(): Character['attributes'] {
  return {
    corps: BASE_ATTRIBUTE_VALUE,
    vitalité: BASE_ATTRIBUTE_VALUE,
    esprit: BASE_ATTRIBUTE_VALUE,
    habilité: BASE_ATTRIBUTE_VALUE,
    sociale: BASE_ATTRIBUTE_VALUE,
    pouvoir: BASE_ATTRIBUTE_VALUE
  };
}

// Initialize default skills for new character
export function createDefaultSkills(): Character['skills'] {
  return {
    corps: { mouvement: 0, mêlée: 0, puissance: 0 },
    vitalité: { endurance: 0, résistance: 0, récupération: 0 },
    esprit: { perception: 0, analyse: 0, volonté: 0 },
    habilité: { distance: 0, discrétion: 0, talent: 0 },
    sociale: { persuasion: 0, intimidation: 0, représentation: 0 },
    pouvoir: { incantation: 0, canalisation: 0, rituel: 0 }
  };
}

// Initialize default skill mastery for new character
export function createDefaultSkillMastery(): Character['skillMastery'] {
  const mastery: Character['skillMastery'] = {};
  
  CHARACTERISTICS.forEach(char => {
    char.skills.forEach(skill => {
      const fullSkillName = `${char.name}.${skill.key}`;
      mastery[fullSkillName] = {
        tier: 0,
        rerollsUsed: 0,
        rerollsAvailable: 0
      };
    });
  });

  return mastery;
}

// Update skill mastery when skill points change
export function updateSkillMastery(character: Character): Character['skillMastery'] {
  const updated = { ...character.skillMastery };
  
  CHARACTERISTICS.forEach(char => {
    const skillValues = character.skills[char.name];
    
    Object.entries(skillValues).forEach(([skillKey, points]) => {
      const fullSkillName = `${char.name}.${skillKey}`;
      const tier = getMasteryTier(points);
      
      if (!updated[fullSkillName]) {
        updated[fullSkillName] = {
          tier: tier.level,
          rerollsUsed: 0,
          rerollsAvailable: 0
        };
      } else {
        updated[fullSkillName].tier = tier.level;
      }
      
      // Reset rerolls if tier changed to 10 (Maîtrise)
      if (tier.level === 10 && updated[fullSkillName].tier !== 10) {
        updated[fullSkillName].rerollsAvailable = 1;
        updated[fullSkillName].rerollsUsed = 0;
      } else if (tier.level !== 10) {
        updated[fullSkillName].rerollsAvailable = 0;
        updated[fullSkillName].rerollsUsed = 0;
      }
    });
  });

  return updated;
}

// Reset rerolls on long rest (for tier 10 mastery)
export function resetSkillRerolls(character: Character): Character['skillMastery'] {
  const updated = { ...character.skillMastery };
  
  Object.keys(updated).forEach(skillName => {
    if (updated[skillName].tier === 10) {
      updated[skillName].rerollsUsed = 0;
      updated[skillName].rerollsAvailable = 1;
    }
  });

  return updated;
}

// Migration function to update legacy character data to new nomenclature
export function migrateCharacterNomenclature(character: Character): { character: Character; wasMigrated: boolean } {
  const migrated = { ...character };
  let wasMigrated = false;

  // Ensure attributes and skills exist
  if (!migrated.attributes) {
    return { character, wasMigrated: false };
  }
  if (!migrated.skills) {
    return { character, wasMigrated: false };
  }

  // Check if character needs migration
  const needsMigration = 
    'mentale' in migrated.attributes ||
    ('athlétisme' in (migrated.skills.corps || {})) ||
    ('lutte' in (migrated.skills.corps || {})) ||
    ('mouvement' in (migrated.skills.habilité || {})) ||
    ('technique' in (migrated.skills.habilité || {}));

  if (needsMigration) {
    wasMigrated = true;

    // Migrate attributes: mentale → esprit
    if ('mentale' in migrated.attributes) {
      (migrated.attributes as any).esprit = (migrated.attributes as any).mentale;
      delete (migrated.attributes as any).mentale;
    }

    // Migrate corps skills: athlétisme → mouvement, lutte → mêlée
    if (migrated.skills.corps) {
      const corpsSkills = migrated.skills.corps as any;
      
      if ('athlétisme' in corpsSkills) {
        corpsSkills.mouvement = corpsSkills.athlétisme;
        delete corpsSkills.athlétisme;
      }
      
      if ('lutte' in corpsSkills) {
        corpsSkills.mêlée = corpsSkills.lutte;
        delete corpsSkills.lutte;
      }
    }

    // Migrate habilité skills: mouvement → distance, technique → talent
    if (migrated.skills.habilité) {
      const habilitéSkills = migrated.skills.habilité as any;
      
      if ('mouvement' in habilitéSkills) {
        habilitéSkills.distance = habilitéSkills.mouvement;
        delete habilitéSkills.mouvement;
      }
      
      if ('technique' in habilitéSkills) {
        habilitéSkills.talent = habilitéSkills.technique;
        delete habilitéSkills.technique;
      }
    }

    // Migrate skills from mentale to esprit if they exist
    if ((migrated.skills as any).mentale) {
      (migrated.skills as any).esprit = (migrated.skills as any).mentale;
      delete (migrated.skills as any).mentale;
    }

    // Migrate skill mastery references
    if (migrated.skillMastery) {
      const newSkillMastery: Character['skillMastery'] = {};
      
      Object.entries(migrated.skillMastery).forEach(([oldKey, mastery]) => {
        let newKey = oldKey;
        
        // Update characteristic references
        newKey = newKey.replace('mentale.', 'esprit.');
        
        // Update skill references
        newKey = newKey.replace('corps.athlétisme', 'corps.mouvement');
        newKey = newKey.replace('corps.lutte', 'corps.mêlée');
        newKey = newKey.replace('habilité.mouvement', 'habilité.distance');
        newKey = newKey.replace('habilité.technique', 'habilité.talent');
        
        newSkillMastery[newKey] = mastery;
      });
      
      migrated.skillMastery = newSkillMastery;
    }

    // Update timestamp
    migrated.updatedAt = new Date().toISOString();
  }

  return { character: migrated, wasMigrated };
}