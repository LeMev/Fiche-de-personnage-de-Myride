/**
 * Schéma de validation canonique pour les capacités (Abilities)
 * Format d'import/export standardisé pour Myride RPG
 */

export interface CanonicalAbility {
  name: string;
  type: 'passive' | 'active';
  description: string;
  effects: string;
  costs: Array<{
    context: string;
    resources: Array<{
      type: string;
      amount: number;
      perUnit?: string;
    }>;
  }>;
  frequency: 'once-per-turn' | 'once-per-day' | 'charges' | 'cooldown' | 'unlimited';
  restRefresh: 'short' | 'long' | 'none';
  prerequisites: string;
  // Champs optionnels supplémentaires pour les capacités actives
  activationType?: 'action' | 'bonus' | 'reaction' | 'free' | 'rest';
  charges?: number;
  maxCharges?: number;
  dailyUses?: number;
  cooldownTurns?: number;
  hasCharges?: boolean;
  rechargesOnLongRest?: boolean;
}

export interface CanonicalAbilityPayload {
  abilities: CanonicalAbility[];
}

/**
 * Convertit une capacité vers le format canonique avec ordre déterministe des clés
 */
export function toCanonicalAbility(ability: any): CanonicalAbility {
  // Ordre déterministe des clés - obligatoires d'abord
  const canonical: CanonicalAbility = {
    name: String(ability.name || ''),
    type: (ability.type === 'passive' || ability.type === 'active') ? ability.type : 'passive',
    description: String(ability.description || ''),
    effects: String(ability.effects || ''),
    costs: Array.isArray(ability.costs) ? ability.costs.map((cost: any) => ({
      context: String(cost.context || ''),
      resources: Array.isArray(cost.resources) ? cost.resources.map((r: any) => {
        const resource: any = {
          type: String(r.type || ''),
          amount: Number(r.amount) || 0,
        };
        if (r.perUnit) {
          resource.perUnit = String(r.perUnit);
        }
        return resource;
      }) : []
    })) : [],
    frequency: (['once-per-turn', 'once-per-day', 'charges', 'cooldown', 'unlimited'].includes(ability.frequency)) 
      ? ability.frequency 
      : 'unlimited',
    restRefresh: (['short', 'long', 'none'].includes(ability.restRefresh)) 
      ? ability.restRefresh 
      : 'none',
    prerequisites: String(ability.prerequisites || ''),
  };
  
  // Ajouter les champs optionnels seulement s'ils sont présents
  if (ability.activationType && ['action', 'bonus', 'reaction', 'free', 'rest'].includes(ability.activationType)) {
    canonical.activationType = ability.activationType;
  }
  
  if (ability.charges !== undefined && ability.charges !== null) {
    canonical.charges = Number(ability.charges);
  }
  
  if (ability.maxCharges !== undefined && ability.maxCharges !== null) {
    canonical.maxCharges = Number(ability.maxCharges);
  }
  
  if (ability.dailyUses !== undefined && ability.dailyUses !== null) {
    canonical.dailyUses = Number(ability.dailyUses);
  }
  
  if (ability.cooldownTurns !== undefined && ability.cooldownTurns !== null) {
    canonical.cooldownTurns = Number(ability.cooldownTurns);
  }
  
  if (ability.hasCharges !== undefined && ability.hasCharges !== null) {
    canonical.hasCharges = Boolean(ability.hasCharges);
  }
  
  if (ability.rechargesOnLongRest !== undefined && ability.rechargesOnLongRest !== null) {
    canonical.rechargesOnLongRest = Boolean(ability.rechargesOnLongRest);
  }
  
  return canonical;
}

/**
 * Valide qu'une capacité canonique a tous les champs requis
 */
export function validateCanonicalAbility(ability: any): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Champs requis
  if (!ability.name || typeof ability.name !== 'string' || ability.name.trim() === '') {
    errors.push('Le champ "name" est requis et doit être une chaîne non vide');
  }

  if (!ability.type || (ability.type !== 'passive' && ability.type !== 'active')) {
    errors.push('Le champ "type" doit être "passive" ou "active"');
  }

  // Champs optionnels mais avec type vérifié
  if (ability.description !== undefined && typeof ability.description !== 'string') {
    errors.push('Le champ "description" doit être une chaîne');
  }

  if (ability.effects !== undefined && typeof ability.effects !== 'string') {
    errors.push('Le champ "effects" doit être une chaîne');
  }

  if (ability.costs !== undefined && !Array.isArray(ability.costs)) {
    errors.push('Le champ "costs" doit être un tableau');
  }

  if (ability.frequency !== undefined && !['once-per-turn', 'once-per-day', 'charges', 'cooldown', 'unlimited'].includes(ability.frequency)) {
    errors.push('Le champ "frequency" doit être une valeur valide');
  }

  if (ability.restRefresh !== undefined && !['short', 'long', 'none'].includes(ability.restRefresh)) {
    errors.push('Le champ "restRefresh" doit être "short", "long" ou "none"');
  }

  if (ability.prerequisites !== undefined && typeof ability.prerequisites !== 'string') {
    errors.push('Le champ "prerequisites" doit être une chaîne');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Normalise les données d'entrée en format canonique
 * Gère plusieurs formats d'entrée possibles
 */
export function normalizeInput(input: any): CanonicalAbilityPayload {
  // Étape 1: Parser et nettoyer
  let parsed = input;
  if (typeof input === 'string') {
    // Retirer les fences Markdown éventuels
    let cleaned = input.trim();
    if (cleaned.startsWith('```')) {
      cleaned = cleaned.replace(/^```(?:json)?\s*\n?/i, '').replace(/\n?```\s*$/i, '');
    }
    // Retirer BOM si présent
    if (cleaned.charCodeAt(0) === 0xFEFF) {
      cleaned = cleaned.slice(1);
    }
    
    // Parse JSON
    try {
      parsed = JSON.parse(cleaned);
    } catch (parseError) {
      throw new Error('Format JSON invalide. Vérifiez la syntaxe.');
    }
  }

  // Étape 2: Normalisation d'entrée
  let abilities: any[] = [];

  if (Array.isArray(parsed)) {
    // Cas b) Array d'objets
    abilities = parsed;
  } else if (parsed && typeof parsed === 'object') {
    if (Array.isArray(parsed.abilities)) {
      // Cas a) Objet avec clé abilities
      abilities = parsed.abilities;
    } else {
      // Cas c) Objet "capacité" unique
      abilities = [parsed];
    }
  } else {
    throw new Error('Format d\'entrée invalide');
  }

  // Étape 3: Convertir chaque capacité au format canonique
  const canonicalAbilities = abilities.map((ability, index) => {
    const canonical = toCanonicalAbility(ability);
    const validation = validateCanonicalAbility(canonical);
    
    if (!validation.valid) {
      throw new Error(`Capacité ${index + 1} invalide: ${validation.errors.join(', ')}`);
    }
    
    return canonical;
  });

  return {
    abilities: canonicalAbilities
  };
}

/**
 * Sérialise un payload canonique en JSON pretty-print
 */
export function serializeCanonical(payload: CanonicalAbilityPayload): string {
  return JSON.stringify(payload, null, 2);
}

/**
 * Exemple de format canonique pour l'aide utilisateur
 */
export function getExampleCanonical(): string {
  const example: CanonicalAbilityPayload = {
    abilities: [
      {
        name: "Maîtrise du Katana",
        type: "passive",
        description: "Années d'entraînement avec le katana traditionnel.",
        effects: "+10% aux jets d'attaque au mélée avec katana",
        costs: [],
        frequency: "unlimited",
        restRefresh: "none",
        prerequisites: "Force 12, Classe Samouraï"
      },
      {
        name: "Frappe Éclair",
        type: "active",
        description: "Attaque rapide qui prend l'ennemi par surprise.",
        effects: "+5 aux dégâts, ignore l'armure légère",
        costs: [
          {
            context: "Combat",
            resources: [
              {
                type: "PM",
                amount: 2
              }
            ]
          }
        ],
        frequency: "once-per-turn",
        restRefresh: "none",
        prerequisites: "Talent 14",
        activationType: "bonus",
        dailyUses: 3
      }
    ]
  };
  
  return serializeCanonical(example);
}
