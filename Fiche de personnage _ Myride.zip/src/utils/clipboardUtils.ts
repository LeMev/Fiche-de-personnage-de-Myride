import type { Ability, Spell, RunePower } from '../types/game';

// Types pour les données sérialisées (sans IDs internes)
export interface SerializedAbility {
  name: string;
  type: 'passive' | 'active';
  description: string;
  effects: string;
  tags: string[];
  costs: Array<{
    context: string;
    resources: Array<{
      type: string;
      amount: number;
      perUnit?: string;
    }>;
  }>;
  activationType?: 'action' | 'bonus' | 'reaction' | 'free' | 'rest';
  frequency?: 'once-per-turn' | 'once-per-day' | 'charges' | 'cooldown' | 'unlimited';
  charges?: number;
  maxCharges?: number;
  dailyUses?: number;
  cooldownTurns?: number;
  restRefresh?: 'short' | 'long' | 'none';
  prerequisites?: string;
}

export interface SerializedSpell {
  name: string;
  type: 'spell';
  description: string;
  tags?: string[];
  costs: Array<{
    context: string;
    resources: Array<{
      type: string;
      amount: number;
      perUnit?: string;
    }>;
  }>;
  range?: string;
  duration?: string;
  scaling?: string;
  activationType: 'action' | 'bonus' | 'reaction' | 'free' | 'ritual';
  prerequisites?: string;
  limitations?: string;
  charges?: number;
  maxCharges?: number;
  dailyUses?: number;
  cooldownTurns?: number;
}

export interface SerializedRunePower {
  name: string;
  type: 'runePower';
  description: string;
  tags?: string[];
  costs: Array<{
    context: string;
    resources: Array<{
      type: string;
      amount: number;
      perUnit?: string;
    }>;
  }>;
  activationType: 'action' | 'bonus' | 'reaction' | 'free' | 'ritual';
  range?: string;
  duration?: string;
  scaling?: string;
  prerequisites?: string;
  limitations?: string;
}

// Fonctions de sérialisation
export function serializeAbility(ability: Ability): SerializedAbility {
  return {
    name: ability.name,
    type: ability.type,
    description: ability.description,
    effects: ability.effects,
    tags: ability.tags || [],
    costs: ability.costs.map(cost => ({
      context: cost.context,
      resources: cost.resources.map(r => ({
        type: r.type,
        amount: r.amount,
        perUnit: r.perUnit
      }))
    })),
    activationType: ability.activationType,
    frequency: ability.frequency,
    charges: ability.charges,
    maxCharges: ability.maxCharges,
    dailyUses: ability.dailyUses,
    cooldownTurns: ability.cooldownTurns,
    restRefresh: ability.restRefresh,
    prerequisites: ability.prerequisites
  };
}

export function serializeSpell(spell: Spell): SerializedSpell {
  return {
    name: spell.name,
    type: 'spell',
    description: spell.description,
    tags: spell.tags || [],
    costs: spell.costs.map(cost => ({
      context: cost.context,
      resources: cost.resources.map(r => ({
        type: r.type,
        amount: r.amount,
        perUnit: r.perUnit
      }))
    })),
    range: spell.range,
    duration: spell.duration,
    scaling: spell.scaling,
    activationType: spell.activationType,
    prerequisites: spell.prerequisites,
    limitations: spell.limitations,
    charges: spell.charges,
    maxCharges: spell.maxCharges,
    dailyUses: spell.dailyUses,
    cooldownTurns: spell.cooldownTurns
  };
}

export function serializeRunePower(power: RunePower): SerializedRunePower {
  return {
    name: power.name,
    type: 'runePower',
    description: power.description,
    tags: [], // RunePower n'a pas de tags dans le type actuel
    costs: power.costs.map(cost => ({
      context: cost.context,
      resources: cost.resources.map(r => ({
        type: r.type,
        amount: r.amount,
        perUnit: r.perUnit
      }))
    })),
    activationType: power.activationType,
    range: power.range,
    duration: power.duration,
    scaling: power.scaling,
    prerequisites: power.prerequisites,
    limitations: power.limitations
  };
}

// Fonctions de désérialisation pour créer de nouveaux objets
export function deserializeAbility(data: SerializedAbility): Omit<Ability, 'id' | 'folderId' | 'createdAt' | 'updatedAt'> {
  return {
    name: data.name,
    type: data.type,
    description: data.description,
    effects: data.effects,
    tags: data.tags,
    costs: data.costs.map(cost => ({
      context: cost.context,
      resources: cost.resources.map(r => ({
        id: crypto.randomUUID(),
        type: r.type,
        amount: r.amount,
        perUnit: r.perUnit
      }))
    })),
    activationType: data.activationType,
    frequency: data.frequency,
    charges: data.charges,
    maxCharges: data.maxCharges,
    dailyUses: data.dailyUses,
    cooldownTurns: data.cooldownTurns,
    restRefresh: data.restRefresh,
    prerequisites: data.prerequisites
  };
}

export function deserializeSpell(data: SerializedSpell): Omit<Spell, 'id'> {
  return {
    name: data.name,
    description: data.description,
    tags: data.tags || [],
    costs: data.costs.map(cost => ({
      id: crypto.randomUUID(),
      context: cost.context,
      resources: cost.resources.map(r => ({
        id: crypto.randomUUID(),
        type: r.type,
        amount: r.amount,
        perUnit: r.perUnit
      }))
    })),
    range: data.range,
    duration: data.duration,
    scaling: data.scaling,
    activationType: data.activationType,
    prerequisites: data.prerequisites,
    limitations: data.limitations,
    charges: data.charges,
    maxCharges: data.maxCharges,
    dailyUses: data.dailyUses,
    cooldownTurns: data.cooldownTurns
  };
}

export function deserializeRunePower(data: SerializedRunePower): Omit<RunePower, 'id'> {
  return {
    name: data.name,
    description: data.description,
    costs: data.costs.map(cost => ({
      id: crypto.randomUUID(),
      context: cost.context,
      resources: cost.resources.map(r => ({
        id: crypto.randomUUID(),
        type: r.type,
        amount: r.amount,
        perUnit: r.perUnit
      }))
    })),
    activationType: data.activationType,
    range: data.range,
    duration: data.duration,
    scaling: data.scaling,
    prerequisites: data.prerequisites,
    limitations: data.limitations
  };
}

// Fonctions pour le presse-papiers
export async function copyToClipboard(data: any): Promise<void> {
  const text = JSON.stringify(data, null, 2);
  
  try {
    // Try modern Clipboard API first
    await navigator.clipboard.writeText(text);
  } catch (clipboardError) {
    // Fallback method using a temporary textarea for environments where Clipboard API is blocked
    try {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      
      if (!successful) {
        throw new Error('execCommand failed');
      }
    } catch (fallbackError) {
      console.error('Erreur lors de la copie:', fallbackError);
      throw new Error('Impossible de copier vers le presse-papiers');
    }
  }
}

export async function pasteFromClipboard(): Promise<any> {
  // In environments where Clipboard API is blocked, we need to use a different approach
  // Show a prompt dialog for the user to paste manually
  try {
    const text = await navigator.clipboard.readText();
    return JSON.parse(text);
  } catch (clipboardError) {
    // Clipboard API blocked - use manual prompt fallback
    const text = window.prompt(
      '⚠️ Accès au presse-papiers bloqué\n\n' +
      'Veuillez coller manuellement le contenu JSON ici :\n' +
      '(Utilisez Ctrl+V ou Cmd+V pour coller)'
    );
    if (!text || text.trim() === '') {
      // User cancelled or provided empty input
      throw new Error('CANCELLED');
    }
    try {
      return JSON.parse(text);
    } catch (parseError) {
      throw new Error('Format JSON invalide');
    }
  }
}

// Fonction pour générer un nom unique en cas de conflit
export function generateUniqueName(baseName: string, existingNames: string[]): string {
  let newName = baseName;
  let counter = 1;
  
  while (existingNames.includes(newName)) {
    newName = `${baseName} (copie${counter > 1 ? ` ${counter}` : ''})`;
    counter++;
  }
  
  return newName;
}

// Fonctions de validation pour s'assurer que les données collées sont valides
export function isValidSerializedAbility(data: any): data is SerializedAbility {
  return (
    typeof data === 'object' &&
    typeof data.name === 'string' &&
    (data.type === 'passive' || data.type === 'active') &&
    typeof data.description === 'string' &&
    typeof data.effects === 'string' &&
    Array.isArray(data.tags) &&
    Array.isArray(data.costs)
  );
}

export function isValidSerializedSpell(data: any): data is SerializedSpell {
  return (
    typeof data === 'object' &&
    typeof data.name === 'string' &&
    data.type === 'spell' &&
    typeof data.description === 'string' &&
    Array.isArray(data.costs)
  );
}

export function isValidSerializedRunePower(data: any): data is SerializedRunePower {
  return (
    typeof data === 'object' &&
    typeof data.name === 'string' &&
    data.type === 'runePower' &&
    typeof data.description === 'string' &&
    Array.isArray(data.costs)
  );
}

export function isValidSerializedAbilityArray(data: any): data is SerializedAbility[] {
  return Array.isArray(data) && data.every(isValidSerializedAbility);
}

export function isValidSerializedSpellArray(data: any): data is SerializedSpell[] {
  return Array.isArray(data) && data.every(isValidSerializedSpell);
}