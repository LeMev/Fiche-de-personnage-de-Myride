import type { Character, Spell, RunePower } from '../types/game';

// Calculate PM cost with Focus consideration
const calculatePMCost = (baseCost: number, focusActive: boolean): number => {
  if (focusActive && baseCost > 0) {
    return Math.max(0, baseCost - 1);
  }
  return baseCost;
};

// Simple magic casting functions similar to abilities
export const canUseMagic = (item: Spell | RunePower, character: Character) => {
  const currentPM = character.resources?.mp?.current || 0;
  const costProfiles = item.costs || [];
  const defaultCost = costProfiles[0];
  const basePMCost = defaultCost?.resources.find(r => r.type === 'PM')?.amount || 0;
  const focusActive = character.focus?.active || false;
  const actualPMCost = calculatePMCost(basePMCost, focusActive);
  
  if (actualPMCost > currentPM) {
    return { canUse: false, reason: `PM insuffisants (${actualPMCost} requis, ${currentPM} disponibles)` };
  }
  
  return { canUse: true };
};

export const validateMagicCosts = (item: Spell | RunePower, currentResources: any, focusActive: boolean = false) => {
  const costProfiles = item.costs || [];
  const defaultCost = costProfiles[0];
  
  if (!defaultCost) return { valid: true };
  
  for (const resource of defaultCost.resources) {
    if (resource.type === 'PM') {
      const actualCost = calculatePMCost(resource.amount, focusActive);
      if (currentResources.mp.current < actualCost) {
        return { valid: false, reason: `PM insuffisants (${actualCost} requis)` };
      }
    } else if (resource.type === 'PV') {
      if (currentResources.hp.current < resource.amount) {
        return { valid: false, reason: `PV insuffisants (${resource.amount} requis)` };
      }
    }
  }
  
  return { valid: true };
};

export const deductMagicCosts = (item: Spell | RunePower, currentResources: any, focusActive: boolean = false) => {
  const updatedResources = { ...currentResources };
  const costProfiles = item.costs || [];
  const defaultCost = costProfiles[0];
  
  if (!defaultCost) return { updatedResources, pmReduction: 0 };
  
  let pmReduction = 0;
  
  for (const resource of defaultCost.resources) {
    if (resource.type === 'PM') {
      const actualCost = calculatePMCost(resource.amount, focusActive);
      updatedResources.mp.current = Math.max(0, updatedResources.mp.current - actualCost);
      pmReduction = resource.amount - actualCost;
    } else if (resource.type === 'PV') {
      updatedResources.hp.current = Math.max(0, updatedResources.hp.current - resource.amount);
    }
  }
  
  return { updatedResources, pmReduction };
};

// Get display fields for list view
export const getSpellDisplayFields = (spell: Spell) => {
  const fields: Array<{ label: string; value: string }> = [];

  // Cost
  if (spell.costs && spell.costs.length > 0) {
    const costStrings = spell.costs.map(cost => {
      const resourceStrings = cost.resources.map(r => 
        `${r.amount} ${r.type}${r.perUnit ? ` ${r.perUnit}` : ''}`
      );
      return `${cost.context}: ${resourceStrings.join(', ')}`;
    });
    fields.push({ label: 'Coût', value: costStrings.join(' | ') });
  }

  // Activation
  if (spell.activationType) {
    const activationLabels = {
      action: 'Action',
      bonus: 'Action bonus',
      reaction: 'Réaction',
      free: 'Action libre',
      ritual: 'Rituel'
    };
    fields.push({ 
      label: 'Activation', 
      value: activationLabels[spell.activationType] || spell.activationType 
    });
  }

  // Range
  if (spell.range) {
    fields.push({ label: 'Portée', value: spell.range });
  }

  // Duration
  if (spell.duration) {
    fields.push({ label: 'Durée', value: spell.duration });
  }

  // Effect (description)
  if (spell.description) {
    fields.push({ label: 'Effet', value: spell.description });
  }

  // Scaling
  if (spell.scaling) {
    fields.push({ label: 'Montée en puissance', value: spell.scaling });
  }

  // Prerequisites
  if (spell.prerequisites) {
    fields.push({ label: 'Prérequis', value: spell.prerequisites });
  }

  // Limits
  if (spell.limits) {
    fields.push({ label: 'Limites', value: spell.limits });
  }

  // Tags
  if (spell.tags && spell.tags.length > 0) {
    fields.push({ label: 'Tags', value: spell.tags.join(', ') });
  }

  return fields;
};

export const getPowerDisplayFields = (power: RunePower) => {
  const fields: Array<{ label: string; value: string }> = [];

  // Cost
  if (power.costs && power.costs.length > 0) {
    const costStrings = power.costs.map(cost => {
      const resourceStrings = cost.resources.map(r => 
        `${r.amount} ${r.type}${r.perUnit ? ` ${r.perUnit}` : ''}`
      );
      return `${cost.context}: ${resourceStrings.join(', ')}`;
    });
    fields.push({ label: 'Coût', value: costStrings.join(' | ') });
  }

  // Activation
  if (power.activationType) {
    const activationLabels = {
      action: 'Action',
      bonus: 'Action bonus', 
      reaction: 'Réaction',
      free: 'Action libre',
      ritual: 'Rituel'
    };
    fields.push({ 
      label: 'Activation', 
      value: activationLabels[power.activationType] || power.activationType 
    });
  }

  // Range
  if (power.range) {
    fields.push({ label: 'Portée', value: power.range });
  }

  // Duration
  if (power.duration) {
    fields.push({ label: 'Durée', value: power.duration });
  }

  // Effect (description)
  if (power.description) {
    fields.push({ label: 'Effet', value: power.description });
  }

  // Scaling
  if (power.scaling) {
    fields.push({ label: 'Montée en puissance', value: power.scaling });
  }

  // Prerequisites
  if (power.prerequisites) {
    fields.push({ label: 'Prérequis', value: power.prerequisites });
  }

  // Limits
  if (power.limits) {
    fields.push({ label: 'Limites', value: power.limits });
  }

  return fields;
};