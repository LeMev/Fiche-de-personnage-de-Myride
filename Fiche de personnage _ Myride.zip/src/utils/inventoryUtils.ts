import type { InventoryItem, Character, EncumbranceLevel, InventorySortField, InventoryFilterCategory, InventoryFilterEquipped } from '../types/game';

// Weight calculation utilities
export function calculateTotalWeight(items: InventoryItem[]): number {
  return items.reduce((total, item) => {
    if (!item.weight) return total;
    
    let itemWeight = item.weight * item.quantity;
    
    // Convert to common unit (kg) for calculation
    switch (item.weightUnit) {
      case 'g':
        itemWeight = itemWeight / 1000;
        break;
      case 'lb':
        itemWeight = itemWeight * 0.453592;
        break;
      case 'oz':
        itemWeight = itemWeight * 0.0283495;
        break;
      // 'kg' is already in the right unit
    }
    
    return total + itemWeight;
  }, 0);
}

export function getEncumbranceLevel(
  totalWeight: number, 
  thresholds?: { light: number; medium: number; heavy: number }
): EncumbranceLevel {
  if (!thresholds) return 'none';
  
  const { light, medium, heavy } = thresholds;
  
  if (totalWeight > heavy) return 'overloaded';
  if (totalWeight > medium) return 'heavy';
  if (totalWeight > light) return 'medium';
  return 'light';
}

// Item filtering utilities
export function getItemsInFolder(
  items: InventoryItem[], 
  folderId: string | undefined,
  filterCategory: InventoryFilterCategory,
  filterEquipped: InventoryFilterEquipped
): InventoryItem[] {
  return items.filter(item => {
    // Filter by folder
    if (folderId !== undefined && item.folderId !== folderId) return false;
    if (folderId === undefined && item.folderId !== undefined) return false;
    
    // Apply other filters
    if (filterCategory !== 'all' && item.category !== filterCategory) return false;
    if (filterEquipped === 'equipped' && !item.equipped) return false;
    if (filterEquipped === 'unequipped' && item.equipped) return false;
    
    return true;
  });
}

// Item sorting utilities
export function sortItems(
  items: InventoryItem[], 
  sortField: InventorySortField, 
  sortDirection: 'asc' | 'desc'
): InventoryItem[] {
  return [...items].sort((a, b) => {
    let aValue: any = a[sortField];
    let bValue: any = b[sortField];
    
    if (typeof aValue === 'string') {
      aValue = aValue.toLowerCase();
      bValue = bValue.toLowerCase();
    }
    
    if (sortDirection === 'asc') {
      return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
    } else {
      return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
    }
  });
}

// Character update utilities
export function updateCharacterInventory(
  character: Character,
  updates: Partial<Character['inventory']>
): Character {
  return {
    ...character,
    inventory: {
      ...character.inventory,
      ...updates,
    },
    updatedAt: new Date().toISOString(),
  };
}

export function updateCharacterItem(
  character: Character,
  itemId: string,
  updates: Partial<InventoryItem>
): Character {
  return updateCharacterInventory(character, {
    items: character.inventory.items.map(item =>
      item.id === itemId ? { ...item, ...updates } : item
    ),
  });
}

export function removeCharacterItem(
  character: Character,
  itemId: string
): Character {
  return updateCharacterInventory(character, {
    items: character.inventory.items.filter(item => item.id !== itemId),
  });
}

export function addCharacterItem(
  character: Character,
  newItem: InventoryItem
): Character {
  return updateCharacterInventory(character, {
    items: [...character.inventory.items, newItem],
  });
}