import type { Ability, AbilitySortField, AbilityFilterType, AbilityFilterCost, AbilityFilterUsage } from '../types/game';

export const filterAndSortAbilities = (
  abilities: Ability[],
  filters: {
    searchTerm: string;
    filterType: AbilityFilterType;
    filterCost: AbilityFilterCost;
    filterUsage: AbilityFilterUsage;
    sortField: AbilitySortField;
  }
) => {
  const { searchTerm, filterType, filterCost, filterUsage, sortField } = filters;
  
  let filtered = abilities.filter(ability => {
    // Search term filter
    if (searchTerm && !ability.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !ability.description.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // Type filter
    if (filterType !== 'all' && ability.type !== filterType) {
      return false;
    }
    
    // Cost filter
    if (filterCost === 'with-cost' && ability.costs.length === 0) {
      return false;
    }
    if (filterCost === 'no-cost' && ability.costs.length > 0) {
      return false;
    }
    
    // Usage filter
    if (filterUsage === 'used-today' && (!ability.usedToday || ability.usedToday === 0)) {
      return false;
    }
    if (filterUsage === 'available' && ability.usedToday && ability.dailyUses && ability.usedToday >= ability.dailyUses) {
      return false;
    }
    
    return true;
  });

  // Sort
  filtered.sort((a, b) => {
    // Passive abilities first, then active
    if (a.type !== b.type) {
      return a.type === 'passive' ? -1 : 1;
    }
    
    switch (sortField) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'type':
        return a.type.localeCompare(b.type);
      case 'activationType':
        return (a.activationType || '').localeCompare(b.activationType || '');
      case 'createdAt':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      default:
        return a.name.localeCompare(b.name);
    }
  });

  return filtered;
};

export const canUseAbility = (ability: Ability) => {
  if (ability.type === 'passive') return false;
  
  if (ability.dailyUses && (ability.usedToday || 0) >= ability.dailyUses) {
    return { canUse: false, reason: 'Capacité déjà utilisée le nombre maximum de fois aujourd\'hui' };
  }

  if (ability.currentCooldown && ability.currentCooldown > 0) {
    return { canUse: false, reason: `Capacité en récupération pour ${ability.currentCooldown} tours` };
  }

  return { canUse: true };
};

// Calculate PM cost with Focus consideration
const calculatePMCost = (baseCost: number, focusActive: boolean): number => {
  if (focusActive && baseCost > 0) {
    return Math.max(0, baseCost - 1);
  }
  return baseCost;
};

export const validateResourceCosts = (ability: Ability, currentResources: any, focusActive: boolean = false) => {
  for (const cost of ability.costs) {
    for (const resource of cost.resources) {
      if (resource.type === 'PM') {
        const actualCost = calculatePMCost(resource.amount, focusActive);
        if (currentResources.mp.current < actualCost) {
          return { valid: false, reason: `PM insuffisants (${actualCost} requis)` };
        }
      } else if (resource.type === 'PV') {
        if (currentResources.hp.current < resource.amount) {
          return { valid: false, reason: `PV insuffisants (${resource.amount} requis)` };
        }
      }
    }
  }
  return { valid: true };
};

export const deductResourceCosts = (ability: Ability, currentResources: any, focusActive: boolean = false) => {
  const updatedResources = { ...currentResources };
  let totalPMReduction = 0;
  
  for (const cost of ability.costs) {
    for (const resource of cost.resources) {
      if (resource.type === 'PM') {
        const actualCost = calculatePMCost(resource.amount, focusActive);
        updatedResources.mp.current -= actualCost;
        totalPMReduction += resource.amount - actualCost;
      } else if (resource.type === 'PV') {
        updatedResources.hp.current -= resource.amount;
      }
    }
  }
  
  return { updatedResources, pmReduction: totalPMReduction };
};

export const createAbilityId = () => {
  return `ability-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};

export const createEmptyAbility = (): Partial<Ability> => ({
  name: '',
  type: 'passive',
  description: '',
  costs: [],
  effects: '',
  frequency: 'unlimited',
  restRefresh: 'none',
});