import type { GlossaryItem, Ability, Spell } from '../types/game';

/**
 * Normalizes a GlossaryItem before saving to the server
 * Removes volatile UI state and ensures required fields are present
 */
export function normalizeGlossaryItemForSave(item: Partial<GlossaryItem>): Partial<GlossaryItem> {
  // Remove volatile UI-only fields
  const normalized: any = { ...item };
  delete normalized.selected;
  delete normalized.uiState;
  
  // Ensure required arrays exist with defaults
  if (!normalized.tags) normalized.tags = [];
  if (!normalized.costProfiles) normalized.costProfiles = [];
  if (!normalized.description) normalized.description = '';
  
  // Force update timestamp
  normalized.updatedAt = new Date().toISOString();
  
  return normalized;
}

/**
 * Converts a glossary item to an Ability
 */
export function glossaryItemToAbility(item: GlossaryItem, existingNames: string[]): Ability | null {
  if (item.type !== 'capacité') return null;
  
  // Generate unique name if needed
  let uniqueName = item.name;
  let counter = 1;
  while (existingNames.includes(uniqueName)) {
    uniqueName = `${item.name} (copie ${counter})`;
    counter++;
  }
  
  return {
    id: crypto.randomUUID(),
    name: uniqueName,
    type: 'active', // Default to active, could be determined from item data
    description: item.description,
    folderId: item.folderId,
    tags: item.tags || [],
    costs: item.costProfiles as any, // Type assertion - in real app would be properly typed
    activationType: item.activationType as any,
    frequency: item.frequency,
    prerequisites: item.prerequisites,
    effects: item.effects || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

/**
 * Converts a glossary item to a Spell
 */
export function glossaryItemToSpell(item: GlossaryItem): Spell | null {
  if (item.type !== 'magie') return null;
  
  return {
    id: crypto.randomUUID(),
    name: item.name,
    description: item.description,
    costs: item.costProfiles.map((cost: any) => ({
      id: crypto.randomUUID(),
      context: cost.context,
      resources: cost.resources.map((r: any) => ({
        id: crypto.randomUUID(),
        type: r.type,
        amount: r.amount,
        perUnit: r.perUnit
      }))
    })),
    activationType: (item.activationType as any) || 'action',
    range: item.range,
    duration: item.duration,
    scaling: item.scaling,
    prerequisites: item.prerequisites,
    limitations: item.limitations,
    tags: item.tags || [],
  };
}

/**
 * Converts an Ability to a glossary item
 */
export function abilityToGlossaryItem(ability: Ability): GlossaryItem {
  return {
    id: crypto.randomUUID(),
    type: 'capacité',
    name: ability.name,
    school: undefined,
    tags: ability.tags || [],
    folderId: ability.folderId,
    description: ability.description,
    costProfiles: ability.costs,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    source: 'user',
    activationType: ability.activationType,
    frequency: ability.frequency,
    prerequisites: ability.prerequisites,
    effects: ability.effects,
  };
}

/**
 * Converts a Spell to a glossary item
 */
export function spellToGlossaryItem(spell: Spell, schoolName: string): GlossaryItem {
  return {
    id: crypto.randomUUID(),
    type: 'magie',
    name: spell.name,
    school: schoolName,
    tags: spell.tags || [],
    folderId: undefined,
    description: spell.description,
    costProfiles: spell.costs,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    source: 'user',
    activationType: spell.activationType,
    range: spell.range,
    duration: spell.duration,
    scaling: spell.scaling,
    prerequisites: spell.prerequisites,
    limitations: spell.limitations,
  };
}

/**
 * Validates a glossary item
 */
export function validateGlossaryItem(item: Partial<GlossaryItem>): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (!item.name || item.name.trim().length === 0) {
    errors.push('Le nom est requis');
  }
  
  if (!item.type) {
    errors.push('Le type est requis');
  }
  
  if (!item.description || item.description.trim().length === 0) {
    errors.push('La description est requise');
  }
  
  if (item.type === 'magie' && !item.school) {
    errors.push('L\'école de magie est requise pour les sorts');
  }
  
  return {
    valid: errors.length === 0,
    errors,
  };
}