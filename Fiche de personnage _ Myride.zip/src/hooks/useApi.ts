import { useState, useEffect } from 'react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import type { Campaign, Character, MagicSchool, GlossaryItem, GlossaryFolder } from '../types/game';

const BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-7fc223a6`;

async function apiCall(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`API Error: ${response.status} - ${error}`);
  }

  return response.json();
}

// Migration function for legacy magic data
function migrateMagicData(character: any): Character {
  if (!character.magic || !character.magic.schools) {
    return character;
  }

  const migratedSchools: MagicSchool[] = character.magic.schools.map((school: any) => {
    // If already in new format, return as-is
    if (school.type && (school.spells || school.baseRunes)) {
      return school;
    }

    // Convert legacy format
    return {
      id: school.id || crypto.randomUUID(),
      name: school.name,
      description: school.description || '',
      type: 'standard' as const,
      isShared: false,
      createdBy: character.id,
      spells: school.spells ? school.spells.map((spell: any) => ({
        id: spell.id || crypto.randomUUID(),
        name: spell.name,
        description: spell.effects || '',
        costs: spell.cost ? [{ 
          context: 'Standard', 
          resources: [{ type: 'PM', amount: parseInt(spell.cost) || 1 }] 
        }] : [{ context: 'Standard', resources: [{ type: 'PM', amount: 1 }] }],
        activationType: spell.activationType || 'action',
        range: '',
        duration: '',
        scaling: spell.requiredRolls || '',
        prerequisites: '',
        limitations: ''
      })) : []
    };
  });

  return {
    ...character,
    magic: {
      schools: migratedSchools
    }
  };
}

export function useCampaigns() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCampaigns = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await apiCall('/campaigns');
      setCampaigns(data);
    } catch (err) {
      console.error('Error fetching campaigns:', err);
      setError(err instanceof Error ? err.message : 'Erreur lors du chargement des campagnes');
    } finally {
      setLoading(false);
    }
  };

  const createCampaign = async (name: string, description?: string) => {
    try {
      const newCampaign = await apiCall('/campaigns', {
        method: 'POST',
        body: JSON.stringify({ name, description }),
      });
      setCampaigns(prev => [...prev, newCampaign]);
      return newCampaign;
    } catch (err) {
      console.error('Error creating campaign:', err);
      throw err;
    }
  };

  const updateCampaign = async (campaign: Campaign) => {
    try {
      const updatedCampaign = await apiCall(`/campaigns/${campaign.id}`, {
        method: 'PUT',
        body: JSON.stringify(campaign),
      });
      setCampaigns(prev => prev.map(c => c.id === campaign.id ? updatedCampaign : c));
      return updatedCampaign;
    } catch (err) {
      console.error('Error updating campaign:', err);
      throw err;
    }
  };

  const deleteCampaign = async (id: string) => {
    try {
      await apiCall(`/campaigns/${id}`, { method: 'DELETE' });
      setCampaigns(prev => prev.filter(c => c.id !== id));
    } catch (err) {
      console.error('Error deleting campaign:', err);
      throw err;
    }
  };

  useEffect(() => {
    fetchCampaigns();
  }, []);

  return {
    campaigns,
    loading,
    error,
    createCampaign,
    updateCampaign,
    deleteCampaign,
    refetch: fetchCampaigns,
  };
}

export function useCharacters(campaignId: string | null) {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCharacters = async () => {
    if (!campaignId) return;
    
    try {
      setLoading(true);
      setError(null);
      const data = await apiCall(`/campaigns/${campaignId}/characters`);
      const migratedData = data.map((character: any) => migrateMagicData(character));
      setCharacters(migratedData);
    } catch (err) {
      console.error('Error fetching characters:', err);
      setError(err instanceof Error ? err.message : 'Erreur lors du chargement des personnages');
    } finally {
      setLoading(false);
    }
  };

  const createCharacter = async (characterData: Partial<Character>) => {
    if (!campaignId) throw new Error('Campaign ID required');
    
    try {
      const newCharacter = await apiCall(`/campaigns/${campaignId}/characters`, {
        method: 'POST',
        body: JSON.stringify(characterData),
      });
      setCharacters(prev => [...prev, newCharacter]);
      return newCharacter;
    } catch (err) {
      console.error('Error creating character:', err);
      throw err;
    }
  };

  const updateCharacter = async (character: Character) => {
    try {
      const updatedCharacter = await apiCall(`/characters/${character.id}`, {
        method: 'PUT',
        body: JSON.stringify(character),
      });
      setCharacters(prev => prev.map(c => c.id === character.id ? updatedCharacter : c));
      return updatedCharacter;
    } catch (err) {
      console.error('Error updating character:', err);
      throw err;
    }
  };

  const deleteCharacter = async (characterId: string) => {
    if (!campaignId) throw new Error('Campaign ID required');
    
    try {
      await apiCall(`/characters/${campaignId}/${characterId}`, { method: 'DELETE' });
      setCharacters(prev => prev.filter(c => c.id !== characterId));
    } catch (err) {
      console.error('Error deleting character:', err);
      throw err;
    }
  };

  useEffect(() => {
    fetchCharacters();
  }, [campaignId]);

  return {
    characters,
    loading,
    error,
    createCharacter,
    updateCharacter,
    deleteCharacter,
    refetch: fetchCharacters,
  };
}

// Glossary API - Standalone methods (not a hook)
export const glossaryApi = {
  async getGlossary(): Promise<{ items: GlossaryItem[]; folders: GlossaryFolder[] }> {
    const endpoint = '/glossary';
    console.groupCollapsed(`🔍 [API] GET ${endpoint}`);
    console.log('Timestamp:', new Date().toISOString());
    
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', response.status, errorText);
        throw new Error(`API Error (${response.status}): ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ Response:', data);
      console.groupEnd();
      return data;
    } catch (error) {
      console.error('❌ Error:', error);
      console.groupEnd();
      throw error;
    }
  },

  async createGlossaryItem(input: Omit<GlossaryItem, 'id' | 'createdAt' | 'updatedAt'>): Promise<GlossaryItem> {
    const endpoint = '/glossary/items';
    console.groupCollapsed(`📝 [API] POST ${endpoint}`);
    console.log('Timestamp:', new Date().toISOString());
    console.log('Payload:', input);
    
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(input),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', response.status, errorText);
        throw new Error(`API Error (${response.status}): ${errorText}`);
      }

      const result = await response.json();
      const savedItem = result.data || result;
      console.log('✅ Saved item:', savedItem);
      console.groupEnd();
      return savedItem;
    } catch (error) {
      console.error('❌ Error:', error);
      console.groupEnd();
      throw error;
    }
  },

  async updateGlossaryItem(id: string, patch: Partial<GlossaryItem>): Promise<GlossaryItem> {
    const endpoint = `/glossary/items/${id}`;
    console.groupCollapsed(`✏️ [API] PUT ${endpoint}`);
    console.log('Timestamp:', new Date().toISOString());
    console.log('Payload:', patch);
    
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(patch),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', response.status, errorText);
        throw new Error(`API Error (${response.status}): ${errorText}`);
      }

      const result = await response.json();
      const savedItem = result.data || result;
      console.log('✅ Updated item:', savedItem);
      console.groupEnd();
      return savedItem;
    } catch (error) {
      console.error('❌ Error:', error);
      console.groupEnd();
      throw error;
    }
  },

  async deleteGlossaryItem(id: string): Promise<void> {
    const endpoint = `/glossary/items/${id}`;
    console.groupCollapsed(`🗑️ [API] DELETE ${endpoint}`);
    console.log('Timestamp:', new Date().toISOString());
    
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', response.status, errorText);
        throw new Error(`API Error (${response.status}): ${errorText}`);
      }

      console.log('✅ Item deleted');
      console.groupEnd();
    } catch (error) {
      console.error('❌ Error:', error);
      console.groupEnd();
      throw error;
    }
  },

  async createGlossaryFolder(input: Omit<GlossaryFolder, 'id' | 'createdAt' | 'updatedAt'>): Promise<GlossaryFolder> {
    const endpoint = '/glossary/folders';
    console.groupCollapsed(`📁 [API] POST ${endpoint}`);
    console.log('Timestamp:', new Date().toISOString());
    console.log('Payload:', input);
    
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(input),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', response.status, errorText);
        throw new Error(`API Error (${response.status}): ${errorText}`);
      }

      const result = await response.json();
      const savedFolder = result.data || result;
      console.log('✅ Saved folder:', savedFolder);
      console.groupEnd();
      return savedFolder;
    } catch (error) {
      console.error('❌ Error:', error);
      console.groupEnd();
      throw error;
    }
  },

  async updateGlossaryFolder(id: string, patch: Partial<GlossaryFolder>): Promise<GlossaryFolder> {
    const endpoint = `/glossary/folders/${id}`;
    console.groupCollapsed(`✏️ [API] PUT ${endpoint}`);
    console.log('Timestamp:', new Date().toISOString());
    console.log('Payload:', patch);
    
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(patch),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', response.status, errorText);
        throw new Error(`API Error (${response.status}): ${errorText}`);
      }

      const result = await response.json();
      const savedFolder = result.data || result;
      console.log('✅ Updated folder:', savedFolder);
      console.groupEnd();
      return savedFolder;
    } catch (error) {
      console.error('❌ Error:', error);
      console.groupEnd();
      throw error;
    }
  },

  async deleteGlossaryFolder(id: string): Promise<void> {
    const endpoint = `/glossary/folders/${id}`;
    console.groupCollapsed(`🗑️ [API] DELETE ${endpoint}`);
    console.log('Timestamp:', new Date().toISOString());
    
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', response.status, errorText);
        throw new Error(`API Error (${response.status}): ${errorText}`);
      }

      console.log('✅ Folder deleted');
      console.groupEnd();
    } catch (error) {
      console.error('❌ Error:', error);
      console.groupEnd();
      throw error;
    }
  },

  async moveItemsToFolder(itemIds: string[], folderId: string | null): Promise<void> {
    const endpoint = '/glossary/items/move';
    console.groupCollapsed(`📦 [API] POST ${endpoint}`);
    console.log('Timestamp:', new Date().toISOString());
    console.log('Payload:', { itemIds, folderId });
    
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ itemIds, folderId }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', response.status, errorText);
        throw new Error(`API Error (${response.status}): ${errorText}`);
      }

      console.log('✅ Items moved');
      console.groupEnd();
    } catch (error) {
      console.error('❌ Error:', error);
      console.groupEnd();
      throw error;
    }
  },
};