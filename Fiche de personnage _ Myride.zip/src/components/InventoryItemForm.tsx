import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import type { InventoryItem, Folder } from '../types/game';
import { WEIGHT_UNITS } from '../constants/inventoryConstants';

interface InventoryItemFormProps {
  formData: Partial<InventoryItem>;
  setFormData: (data: Partial<InventoryItem>) => void;
  onSubmit: (e: React.FormEvent) => void;
  onCancel: () => void;
  isEditing?: boolean;
  folders: Folder[];
}

export function InventoryItemForm({
  formData,
  setFormData,
  onSubmit,
  onCancel,
  isEditing = false,
  folders
}: InventoryItemFormProps) {
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Nom de l'objet *</Label>
        <Input
          id="name"
          value={formData.name || ''}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Nom de l'objet"
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="quantity">Quantité</Label>
          <Input
            id="quantity"
            type="number"
            min="1"
            value={formData.quantity || 1}
            onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 1 })}
          />
        </div>

        <div>
          <Label htmlFor="category">Catégorie</Label>
          <Select 
            value={formData.category || 'misc'} 
            onValueChange={(value) => setFormData({ ...formData, category: value as any })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="weapon">Arme</SelectItem>
              <SelectItem value="armor">Armure</SelectItem>
              <SelectItem value="consumable">Consommable</SelectItem>
              <SelectItem value="quest">Objet de quête</SelectItem>
              <SelectItem value="unknown">Inconnu</SelectItem>
              <SelectItem value="container">Conteneur</SelectItem>
              <SelectItem value="misc">Divers</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Weight System */}
      <div className="space-y-4 border-t pt-4">
        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2">
            <Label htmlFor="weight">Poids (par unité)</Label>
            <Input
              id="weight"
              type="number"
              min="0"
              step="0.1"
              value={formData.weight || ''}
              onChange={(e) => setFormData({ 
                ...formData, 
                weight: parseFloat(e.target.value) || 0 
              })}
              placeholder="0"
            />
          </div>
          <div>
            <Label htmlFor="weight-unit">Unité</Label>
            <Select 
              value={formData.weightUnit || 'kg'}
              onValueChange={(value) => setFormData({ ...formData, weightUnit: value as any })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {WEIGHT_UNITS.map(unit => (
                  <SelectItem key={unit.value} value={unit.value}>
                    {unit.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Folder Selection */}
      <div>
        <Label htmlFor="folder">Dossier</Label>
        <Select 
          value={formData.folderId || 'none'}
          onValueChange={(value) => setFormData({ 
            ...formData, 
            folderId: value === 'none' ? undefined : value 
          })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Aucun dossier" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Aucun dossier</SelectItem>
            {folders.map(folder => (
              <SelectItem key={folder.id} value={folder.id}>
                {folder.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Tags */}
      <div>
        <Label htmlFor="tags">Tags (séparés par des virgules)</Label>
        <Input
          id="tags"
          value={formData.tags?.join(', ') || ''}
          onChange={(e) => setFormData({ 
            ...formData, 
            tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0)
          })}
          placeholder="magique, rare, combat..."
        />
      </div>

      {/* Charge System */}
      <div className="space-y-4 border-t pt-4">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="has-charges"
            checked={formData.hasCharges || false}
            onCheckedChange={(checked) => setFormData({ 
              ...formData, 
              hasCharges: checked as boolean,
              currentCharges: checked ? (formData.currentCharges || 0) : undefined,
              rechargesOnLongRest: checked ? (formData.rechargesOnLongRest || false) : undefined,
            })}
          />
          <Label htmlFor="has-charges">Cet objet utilise un système de charges</Label>
        </div>

        {formData.hasCharges && (
          <div className="space-y-4 ml-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="current-charges">Charges actuelles</Label>
                <Input
                  id="current-charges"
                  type="number"
                  min="0"
                  value={formData.currentCharges || 0}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    currentCharges: parseInt(e.target.value) || 0 
                  })}
                />
              </div>
              <div>
                <Label htmlFor="max-charges-new">Charges maximum</Label>
                <Input
                  id="max-charges-new"
                  type="number"
                  min="1"
                  value={formData.maxCharges || 1}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    maxCharges: parseInt(e.target.value) || 1 
                  })}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="recharges-long-rest"
                checked={formData.rechargesOnLongRest || false}
                onCheckedChange={(checked) => setFormData({ 
                  ...formData, 
                  rechargesOnLongRest: checked as boolean 
                })}
              />
              <Label htmlFor="recharges-long-rest">Se régénère après un long repos</Label>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="damage">Dégâts/Bonus</Label>
          <Input
            id="damage"
            value={formData.damage || ''}
            onChange={(e) => setFormData({ ...formData, damage: e.target.value })}
            placeholder="Ex: 1d8+2"
          />
        </div>

        <div>
          <Label htmlFor="rarity">Rareté</Label>
          <Select 
            value={formData.rarity || 'common'} 
            onValueChange={(value) => setFormData({ ...formData, rarity: value as any })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="common">Commun</SelectItem>
              <SelectItem value="uncommon">Peu commun</SelectItem>
              <SelectItem value="rare">Rare</SelectItem>
              <SelectItem value="epic">Épique</SelectItem>
              <SelectItem value="legendary">Légendaire</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Armor Bonus - only show for armor items */}
      {formData.category === 'armor' && (
        <div>
          <Label htmlFor="armor-bonus">Bonus d'armure</Label>
          <Input
            id="armor-bonus"
            type="number"
            min="0"
            value={formData.armorBonus || 0}
            onChange={(e) => setFormData({ 
              ...formData, 
              armorBonus: parseInt(e.target.value) || 0 
            })}
            placeholder="Bonus d'armure fourni"
          />
        </div>
      )}

      <div>
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          value={formData.notes || ''}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          placeholder="Description, effets spéciaux..."
          rows={3}
        />
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="equipped"
            checked={formData.equipped || false}
            onCheckedChange={(checked) => setFormData({ ...formData, equipped: !!checked })}
          />
          <Label htmlFor="equipped">Équipé</Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="identified"
            checked={formData.identified !== false}
            onCheckedChange={(checked) => setFormData({ ...formData, identified: !!checked })}
          />
          <Label htmlFor="identified">Identifié</Label>
        </div>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Annuler
        </Button>
        <Button type="submit">
          {isEditing ? 'Enregistrer' : 'Ajouter'}
        </Button>
      </div>
    </form>
  );
}