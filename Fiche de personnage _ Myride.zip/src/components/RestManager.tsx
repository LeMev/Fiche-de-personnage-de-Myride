import { useState } from 'react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import type { Character, Ability, InventoryItem } from '../types/game';
import { resetSkillRerolls } from '../utils/characterUtils';
import { Moon, Sun, Bed, RefreshCw, Clock, Info, Battery } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface RestManagerProps {
  character: Character;
  onUpdateCharacter: (character: Character) => void;
}

export function RestManager({ character, onUpdateCharacter }: RestManagerProps) {
  const [showShortRestDialog, setShowShortRestDialog] = useState(false);
  const [showLongRestDialog, setShowLongRestDialog] = useState(false);

  const getAffectedAbilities = (restType: 'short' | 'long') => {
    return character.abilities.filter(ability => {
      if (restType === 'short') {
        return ability.restRefresh === 'short' || ability.restRefresh === 'long';
      } else {
        return ability.restRefresh === 'long' || 
               (ability.usedToday && ability.usedToday > 0) ||
               (ability.currentCooldown && ability.currentCooldown > 0) ||
               (ability.hasCharges && ability.rechargesOnLongRest && 
                ability.currentCharges !== undefined && ability.maxCharges !== undefined &&
                ability.currentCharges < ability.maxCharges);
      }
    });
  };

  const getAffectedItems = (restType: 'long') => {
    return character.inventory.items.filter(item => {
      return item.hasCharges && item.rechargesOnLongRest && 
             item.currentCharges !== undefined && item.maxCharges !== undefined &&
             item.currentCharges < item.maxCharges;
    });
  };

  const performRest = (restType: 'short' | 'long') => {
    const updatedAbilities = character.abilities.map(ability => {
      const updated = { ...ability };
      
      if (restType === 'short') {
        // Short rest: only refresh abilities marked for short rest
        if (ability.restRefresh === 'short') {
          updated.usedToday = 0;
          updated.currentCooldown = 0;
        }
        // Reduce cooldowns by 1 for all abilities
        if (ability.currentCooldown && ability.currentCooldown > 0) {
          updated.currentCooldown = Math.max(0, ability.currentCooldown - 1);
        }
      } else {
        // Long rest: refresh everything
        updated.usedToday = 0;
        updated.currentCooldown = 0;
        
        // Handle charge recharge on long rest
        if (ability.hasCharges && ability.rechargesOnLongRest && ability.maxCharges !== undefined) {
          updated.currentCharges = ability.maxCharges;
        }
      }
      
      updated.updatedAt = new Date().toISOString();
      return updated;
    });

    // Handle item charge recharge on long rest
    let updatedItems = character.inventory.items;
    if (restType === 'long') {
      updatedItems = character.inventory.items.map(item => {
        const updated = { ...item };
        
        if (item.hasCharges && item.rechargesOnLongRest && item.maxCharges !== undefined) {
          updated.currentCharges = item.maxCharges;
        }
        
        return updated;
      });
    }

    // Also restore resources and skills for long rest
    let updatedResources = character.resources;
    let updatedSkillMastery = character.skillMastery;
    
    if (restType === 'long') {
      updatedResources = {
        ...character.resources,
        hp: {
          ...character.resources.hp,
          current: character.resources.hp.max,
        },
        mp: {
          ...character.resources.mp,
          current: character.resources.mp.max,
        },
        custom: character.resources.custom.map(resource => ({
          ...resource,
          current: resource.max,
        })),
      };
      
      // Reset skill rerolls (for tier 10 mastery)
      updatedSkillMastery = resetSkillRerolls(character);
    }

    const updatedCharacter: Character = {
      ...character,
      abilities: updatedAbilities,
      resources: updatedResources,
      skillMastery: updatedSkillMastery,
      inventory: {
        ...character.inventory,
        items: updatedItems,
      },
      updatedAt: new Date().toISOString(),
    };

    onUpdateCharacter(updatedCharacter);
    
    const affectedAbilities = getAffectedAbilities(restType).length;
    const affectedItems = restType === 'long' ? getAffectedItems('long').length : 0;
    
    let message = `${restType === 'short' ? 'Repos court' : 'Repos long'} terminé. `;
    if (affectedAbilities > 0) {
      message += `${affectedAbilities} capacité${affectedAbilities !== 1 ? 's' : ''} récupérée${affectedAbilities !== 1 ? 's' : ''}`;
    }
    if (affectedItems > 0) {
      if (affectedAbilities > 0) message += ', ';
      message += `${affectedItems} objet${affectedItems !== 1 ? 's' : ''} rechargé${affectedItems !== 1 ? 's' : ''}`;
    }
    message += '.';
    
    toast.success(message);
    
    if (restType === 'short') {
      setShowShortRestDialog(false);
    } else {
      setShowLongRestDialog(false);
    }
  };

  const shortRestAffected = getAffectedAbilities('short');
  const longRestAffected = getAffectedAbilities('long');
  const longRestAffectedItems = getAffectedItems('long');

  const getAbilityRecoveryInfo = (ability: Ability, restType: 'short' | 'long') => {
    const info = [];
    
    if (restType === 'short' && ability.restRefresh === 'short') {
      info.push('Utilisations récupérées');
    }
    
    if (restType === 'long') {
      if (ability.usedToday && ability.usedToday > 0) {
        info.push(`${ability.usedToday} utilisation${ability.usedToday !== 1 ? 's' : ''} récupérée${ability.usedToday !== 1 ? 's' : ''}`);
      }
      
      if (ability.hasCharges && ability.rechargesOnLongRest && 
          ability.currentCharges !== undefined && ability.maxCharges !== undefined &&
          ability.currentCharges < ability.maxCharges) {
        info.push(`Charges récupérées (${ability.currentCharges}/${ability.maxCharges} → ${ability.maxCharges}/${ability.maxCharges})`);
      }
    }
    
    if (ability.currentCooldown && ability.currentCooldown > 0) {
      if (restType === 'short') {
        info.push(`Récupération: ${ability.currentCooldown} → ${Math.max(0, ability.currentCooldown - 1)} tours`);
      } else {
        info.push('Récupération terminée');
      }
    }
    
    return info;
  };

  const getItemRecoveryInfo = (item: InventoryItem) => {
    const info = [];
    
    if (item.hasCharges && item.rechargesOnLongRest && 
        item.currentCharges !== undefined && item.maxCharges !== undefined &&
        item.currentCharges < item.maxCharges) {
      info.push(`Charges récupérées (${item.currentCharges}/${item.maxCharges} → ${item.maxCharges}/${item.maxCharges})`);
    }
    
    return info;
  };

  return (
    <div className="flex gap-2">
      <Dialog open={showShortRestDialog} onOpenChange={setShowShortRestDialog}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm">
            <Sun className="w-4 h-4 mr-2" />
            Repos court
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sun className="w-5 h-5" />
              Repos court (1 heure)
            </DialogTitle>
            <DialogDescription>
              Récupère les capacités marquées pour le repos court et réduit les récupérations de 1 tour.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {shortRestAffected.length === 0 ? (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  Aucune capacité ne sera affectée par ce repos court.
                </AlertDescription>
              </Alert>
            ) : (
              <div>
                <h4 className="font-medium mb-2">Capacités affectées ({shortRestAffected.length}):</h4>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {shortRestAffected.map(ability => {
                    const recoveryInfo = getAbilityRecoveryInfo(ability, 'short');
                    return (
                      <div key={ability.id} className="p-2 bg-muted rounded">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-sm">{ability.name}</span>
                          <Badge variant={ability.type === 'passive' ? 'secondary' : 'default'} className="text-xs">
                            {ability.type === 'passive' ? 'Passif' : 'Actif'}
                          </Badge>
                        </div>
                        {recoveryInfo.length > 0 && (
                          <div className="text-xs text-muted-foreground">
                            {recoveryInfo.map((info, index) => (
                              <div key={index}>• {info}</div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowShortRestDialog(false)}
                className="flex-1"
              >
                Annuler
              </Button>
              <Button
                onClick={() => performRest('short')}
                className="flex-1"
              >
                <Sun className="w-4 h-4 mr-2" />
                Repos court
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showLongRestDialog} onOpenChange={setShowLongRestDialog}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm">
            <Moon className="w-4 h-4 mr-2" />
            Repos long
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Moon className="w-5 h-5" />
              Repos long (8 heures)
            </DialogTitle>
            <DialogDescription>
              Récupère toutes les ressources, réinitialise toutes les capacités et recharge les objets.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <Alert>
              <Bed className="h-4 w-4" />
              <AlertDescription>
                Le repos long restaure les PV et PM au maximum, remet à zéro toutes les utilisations quotidiennes et recharge les capacités et objets avec la case cochée.
              </AlertDescription>
            </Alert>

            {longRestAffected.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Capacités affectées ({longRestAffected.length}):</h4>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {longRestAffected.map(ability => {
                    const recoveryInfo = getAbilityRecoveryInfo(ability, 'long');
                    return (
                      <div key={ability.id} className="p-2 bg-muted rounded">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-sm">{ability.name}</span>
                          <Badge variant={ability.type === 'passive' ? 'secondary' : 'default'} className="text-xs">
                            {ability.type === 'passive' ? 'Passif' : 'Actif'}
                          </Badge>
                        </div>
                        {recoveryInfo.length > 0 && (
                          <div className="text-xs text-muted-foreground">
                            {recoveryInfo.map((info, index) => (
                              <div key={index}>• {info}</div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {longRestAffectedItems.length > 0 && (
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-1">
                  <Battery className="w-4 h-4" />
                  Objets rechargés ({longRestAffectedItems.length}):
                </h4>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {longRestAffectedItems.map(item => {
                    const recoveryInfo = getItemRecoveryInfo(item);
                    return (
                      <div key={item.id} className="p-2 bg-muted rounded">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-sm">{item.name}</span>
                          <Badge variant="outline" className="text-xs">
                            {item.category}
                          </Badge>
                        </div>
                        {recoveryInfo.length > 0 && (
                          <div className="text-xs text-muted-foreground">
                            {recoveryInfo.map((info, index) => (
                              <div key={index}>• {info}</div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <Separator />
            
            <div>
              <h4 className="font-medium mb-2">Ressources récupérées:</h4>
              <div className="space-y-1 text-sm">
                <div>• PV: {character.resources.hp.current}/{character.resources.hp.max} → {character.resources.hp.max}/{character.resources.hp.max}</div>
                <div>• PM: {character.resources.mp.current}/{character.resources.mp.max} → {character.resources.mp.max}/{character.resources.mp.max}</div>
                {character.resources.custom.map(resource => (
                  <div key={resource.id}>
                    • {resource.label}: {resource.current}/{resource.max} → {resource.max}/{resource.max}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowLongRestDialog(false)}
                className="flex-1"
              >
                Annuler
              </Button>
              <Button
                onClick={() => performRest('long')}
                className="flex-1"
              >
                <Moon className="w-4 h-4 mr-2" />
                Repos long
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}