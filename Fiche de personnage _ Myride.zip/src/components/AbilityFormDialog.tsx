import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Checkbox } from './ui/checkbox';
import type { Ability, AbilityCost } from '../types/game';
import { Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { ACTIVATION_TYPES, FREQUENCY_OPTIONS, REST_REFRESH_OPTIONS, RESOURCE_TYPES } from '../constants/abilityConstants';
import { createAbilityId, createEmptyAbility } from '../utils/abilityUtils';

interface AbilityFormDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (ability: Ability) => void;
  editingAbility?: Ability | null;
  isEditing: boolean;
}

export function AbilityFormDialog({ isOpen, onClose, onSave, editingAbility, isEditing }: AbilityFormDialogProps) {
  const [formData, setFormData] = useState<Partial<Ability>>(createEmptyAbility());

  // Prefill form when editing
  useEffect(() => {
    if (isOpen) {
      if (isEditing && editingAbility) {
        setFormData({
          ...editingAbility,
          costs: editingAbility.costs || [],
          effects: editingAbility.effects || '',
          frequency: editingAbility.frequency || 'unlimited',
          restRefresh: editingAbility.restRefresh || 'none',
          hasCharges: editingAbility.hasCharges || false,
          currentCharges: editingAbility.currentCharges || 0,
          rechargesOnLongRest: editingAbility.rechargesOnLongRest || false,
        });
      } else {
        setFormData(createEmptyAbility());
      }
    }
  }, [isOpen, isEditing, editingAbility]);

  const handleSave = () => {
    if (!formData.name || !formData.description) {
      toast.error('Le nom et la description sont obligatoires');
      return;
    }

    const ability: Ability = {
      id: isEditing ? editingAbility!.id : createAbilityId(),
      name: formData.name,
      type: formData.type || 'passive',
      description: formData.description,
      costs: formData.costs || [],
      effects: formData.effects || '',
      frequency: formData.frequency || 'unlimited',
      restRefresh: formData.restRefresh || 'none',
      
      // Charge system fields
      hasCharges: formData.hasCharges || false,
      currentCharges: formData.hasCharges ? (formData.currentCharges || 0) : undefined,
      maxCharges: formData.hasCharges ? (formData.maxCharges || 1) : undefined,
      rechargesOnLongRest: formData.hasCharges ? (formData.rechargesOnLongRest || false) : undefined,
      
      ...(formData.type === 'active' && {
        activationType: formData.activationType,
        dailyUses: formData.dailyUses,
        usedToday: isEditing ? formData.usedToday || 0 : 0,
        cooldownTurns: formData.cooldownTurns,
        currentCooldown: isEditing ? formData.currentCooldown || 0 : 0,
      }),
      prerequisites: formData.prerequisites,
      usageLog: isEditing ? formData.usageLog || [] : [],
      createdAt: isEditing ? editingAbility!.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(ability);
    onClose();
  };

  const handleClose = () => {
    onClose();
  };

  const addCost = () => {
    setFormData(prev => ({
      ...prev,
      costs: [
        ...(prev.costs || []),
        {
          context: 'Standard',
          resources: [{ type: 'PM', amount: 1 }],
        },
      ],
    }));
  };

  const removeCost = (index: number) => {
    setFormData(prev => ({
      ...prev,
      costs: (prev.costs || []).filter((_, i) => i !== index),
    }));
  };

  const updateCost = (index: number, cost: AbilityCost) => {
    setFormData(prev => ({
      ...prev,
      costs: (prev.costs || []).map((c, i) => i === index ? cost : c),
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle>
            {isEditing ? `Modifier : ${editingAbility?.name}` : 'Créer une nouvelle capacité'}
          </DialogTitle>
          <DialogDescription>
            {isEditing ? 'Modifiez les propriétés de cette capacité' : 'Ajoutez une capacité passive ou active à votre personnage'}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Nom de la capacité *</Label>
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Maîtrise du Katana"
              />
            </div>
            
            <div>
              <Label htmlFor="type">Type *</Label>
              <Select
                value={formData.type}
                onValueChange={(value: 'passive' | 'active') => 
                  setFormData(prev => ({ ...prev, type: value }))
                }
                disabled={isEditing}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="passive">Passif</SelectItem>
                  <SelectItem value="active">Actif</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Description détaillée de la capacité..."
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="effects">Effets mécaniques</Label>
            <Textarea
              id="effects"
              value={formData.effects || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, effects: e.target.value }))}
              placeholder="+10% aux jets d'attaque au mélée, +2D6 dégâts si non vu..."
              rows={2}
            />
          </div>

          {formData.type === 'active' && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="activation">Mode d'activation</Label>
                  <Select
                    value={formData.activationType}
                    onValueChange={(value: any) => 
                      setFormData(prev => ({ ...prev, activationType: value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner..." />
                    </SelectTrigger>
                    <SelectContent>
                      {ACTIVATION_TYPES.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="frequency">Fréquence</Label>
                  <Select
                    value={formData.frequency}
                    onValueChange={(value: any) => 
                      setFormData(prev => ({ ...prev, frequency: value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FREQUENCY_OPTIONS.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {formData.frequency === 'once-per-day' && (
                <div>
                  <Label htmlFor="daily-uses">Utilisations par jour</Label>
                  <Input
                    id="daily-uses"
                    type="number"
                    min="1"
                    value={formData.dailyUses || 1}
                    onChange={(e) => setFormData(prev => ({ 
                      ...prev, 
                      dailyUses: parseInt(e.target.value) || 1 
                    }))}
                  />
                </div>
              )}

              {formData.frequency === 'cooldown' && (
                <div>
                  <Label htmlFor="cooldown">Récupération (tours)</Label>
                  <Input
                    id="cooldown"
                    type="number"
                    min="1"
                    value={formData.cooldownTurns || ''}
                    onChange={(e) => setFormData(prev => ({ 
                      ...prev, 
                      cooldownTurns: parseInt(e.target.value) || 1 
                    }))}
                  />
                </div>
              )}

              <div>
                <Label htmlFor="rest-refresh">Récupération au repos</Label>
                <Select
                  value={formData.restRefresh}
                  onValueChange={(value: any) => 
                    setFormData(prev => ({ ...prev, restRefresh: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {REST_REFRESH_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          <div>
            <Label htmlFor="prerequisites">Prérequis</Label>
            <Input
              id="prerequisites"
              value={formData.prerequisites || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, prerequisites: e.target.value }))}
              placeholder="Force 15, Classe Guerrier, Niveau 5..."
            />
          </div>

          {/* Resource Costs */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Coûts en ressources</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addCost}
              >
                <Plus className="w-4 h-4 mr-2" />
                Ajouter un coût
              </Button>
            </div>
            
            {(formData.costs || []).map((cost, index) => (
              <Card key={index} className="p-3 mb-2">
                <div className="flex items-center justify-between mb-2">
                  <Input
                    value={cost.context}
                    onChange={(e) => {
                      const updatedCost = { ...cost, context: e.target.value };
                      updateCost(index, updatedCost);
                    }}
                    placeholder="Contexte (Combat, Hors combat...)"
                    className="max-w-xs"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeCost(index)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                
                {cost.resources.map((resource, resourceIndex) => (
                  <div key={resourceIndex} className="flex gap-2 items-center">
                    <Input
                      value={resource.amount}
                      onChange={(e) => {
                        const updatedResources = cost.resources.map((r, ri) =>
                          ri === resourceIndex 
                            ? { ...r, amount: parseInt(e.target.value) || 0 }
                            : r
                        );
                        updateCost(index, { ...cost, resources: updatedResources });
                      }}
                      type="number"
                      min="0"
                      className="w-20"
                    />
                    <Select
                      value={resource.type}
                      onValueChange={(value) => {
                        const updatedResources = cost.resources.map((r, ri) =>
                          ri === resourceIndex ? { ...r, type: value } : r
                        );
                        updateCost(index, { ...cost, resources: updatedResources });
                      }}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {RESOURCE_TYPES.map(type => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      value={resource.perUnit || ''}
                      onChange={(e) => {
                        const updatedResources = cost.resources.map((r, ri) =>
                          ri === resourceIndex 
                            ? { ...r, perUnit: e.target.value }
                            : r
                        );
                        updateCost(index, { ...cost, resources: updatedResources });
                      }}
                      placeholder="par unité supplémentaire..."
                      className="flex-1"
                    />
                  </div>
                ))}
              </Card>
            ))}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button
              variant="outline"
              onClick={handleClose}
            >
              Annuler
            </Button>
            <Button onClick={handleSave}>
              {isEditing ? 'Enregistrer' : 'Créer la capacité'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}