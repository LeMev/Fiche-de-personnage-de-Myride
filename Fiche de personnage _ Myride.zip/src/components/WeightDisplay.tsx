import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import type { Character, EncumbranceLevel } from '../types/game';
import { Weight, AlertTriangle } from 'lucide-react';
import { ENCUMBRANCE_COLORS, ENCUMBRANCE_LABELS } from '../constants/inventoryConstants';

interface WeightDisplayProps {
  totalWeight: number;
  encumbranceLevel: EncumbranceLevel;
  encumbranceThreshold?: Character['inventory']['encumbranceThreshold'];
}

export function WeightDisplay({ 
  totalWeight, 
  encumbranceLevel, 
  encumbranceThreshold 
}: WeightDisplayProps) {
  const getEncumbranceColor = () => ENCUMBRANCE_COLORS[encumbranceLevel];
  const getEncumbranceLabel = () => ENCUMBRANCE_LABELS[encumbranceLevel];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Weight className="w-5 h-5" />
            <CardTitle>Poids transporté</CardTitle>
          </div>
          {encumbranceLevel === 'overloaded' && (
            <Badge variant="destructive">
              <AlertTriangle className="w-3 h-3 mr-1" />
              Surchargé
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm">Poids total:</span>
            <span className={`font-mono text-lg ${getEncumbranceColor()}`}>
              {totalWeight.toFixed(2)} kg
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm">Niveau d'encombrement:</span>
            <Badge variant={encumbranceLevel === 'overloaded' ? 'destructive' : 'outline'}>
              {getEncumbranceLabel()}
            </Badge>
          </div>
          
          {encumbranceThreshold && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Léger: 0-{encumbranceThreshold.light}kg</span>
                <span>Moyen: {encumbranceThreshold.light}-{encumbranceThreshold.medium}kg</span>
                <span>Lourd: {encumbranceThreshold.medium}-{encumbranceThreshold.heavy}kg</span>
              </div>
              <Progress 
                value={(totalWeight / encumbranceThreshold.heavy) * 100} 
                className="h-2"
              />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}