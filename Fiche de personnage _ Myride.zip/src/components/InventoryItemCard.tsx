import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import type { InventoryItem } from '../types/game';
import { Plus, Minus, Trash2, Edit, Eye, EyeOff, Battery } from 'lucide-react';
import { CATEGORY_ICONS, CATEGORY_LABELS, RARITY_COLORS } from '../constants/inventoryConstants';

interface InventoryItemCardProps {
  item: InventoryItem;
  onEdit: (item: InventoryItem) => void;
  onDelete: (itemId: string) => void;
  onToggleEquipped: (itemId: string) => void;
  onUseCharge: (itemId: string) => void;
  onQuantityChange: (itemId: string, change: number) => void;
}

export function InventoryItemCard({
  item,
  onEdit,
  onDelete,
  onToggleEquipped,
  onUseCharge,
  onQuantityChange
}: InventoryItemCardProps) {
  const Icon = CATEGORY_ICONS[item.category];

  return (
    <Card className={item.equipped ? 'border-primary' : ''}>
      <CardContent className="pt-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3 flex-1">
            <Icon className="w-5 h-5 mt-1 text-muted-foreground" />
            
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h4 className="font-medium">
                  {item.identified ? item.name : '??? Objet non identifié'}
                </h4>
                <Badge variant={RARITY_COLORS[item.rarity || 'common']}>
                  {item.rarity || 'common'}
                </Badge>
                {item.equipped && (
                  <Badge variant="default">Équipé</Badge>
                )}
                {!item.identified && (
                  <Badge variant="secondary">
                    <EyeOff className="w-3 h-3 mr-1" />
                    Non identifié
                  </Badge>
                )}
                {item.hasCharges && item.rechargesOnLongRest && (
                  <Badge variant="outline">
                    <Battery className="w-3 h-3 mr-1" />
                    Auto-recharge
                  </Badge>
                )}
              </div>
              
              <p className="text-sm text-muted-foreground mb-2">
                {CATEGORY_LABELS[item.category]}
                {item.damage && ` • ${item.damage}`}
                {item.armorBonus && ` • +${item.armorBonus} Armure`}
                {item.weight && ` • ${item.weight}${item.weightUnit || 'kg'} chacun`}
              </p>
              
              {item.notes && item.identified && (
                <p className="text-sm text-muted-foreground italic mb-2">
                  {item.notes}
                </p>
              )}

              {item.tags && item.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-2">
                  {item.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              <div className="flex items-center gap-4 mt-2">
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onQuantityChange(item.id, -1)}
                    disabled={item.quantity <= 1}
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <span className="text-sm font-medium">
                    Qté: {item.quantity}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onQuantityChange(item.id, 1)}
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>

                {/* New charge system */}
                {item.hasCharges && (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onUseCharge(item.id)}
                      disabled={!item.currentCharges || item.currentCharges <= 0}
                    >
                      Utiliser
                    </Button>
                    <span className="text-sm font-medium">
                      Charges: {item.currentCharges || 0}
                      {item.maxCharges && `/${item.maxCharges}`}
                    </span>
                  </div>
                )}

                {/* Legacy charge system */}
                {item.charges !== undefined && !item.hasCharges && (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onUseCharge(item.id)}
                      disabled={!item.charges || item.charges <= 0}
                    >
                      Utiliser
                    </Button>
                    <span className="text-sm font-medium">
                      Charges: {item.charges || 0}
                      {item.maxCharges && `/${item.maxCharges}`}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onToggleEquipped(item.id)}
              title={item.equipped ? 'Déséquiper' : 'Équiper'}
            >
              {item.equipped ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(item)}
            >
              <Edit className="w-4 h-4" />
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Supprimer l'objet</AlertDialogTitle>
                  <AlertDialogDescription>
                    Êtes-vous sûr de vouloir supprimer "{item.name}" de l'inventaire ?
                    Cette action est irréversible.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Annuler</AlertDialogCancel>
                  <AlertDialogAction onClick={() => onDelete(item.id)}>
                    Supprimer
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}