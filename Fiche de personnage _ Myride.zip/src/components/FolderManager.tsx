import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import type { Folder } from '../types/game';
import { Folder as FolderIcon, FolderOpen, Plus, MoreVertical, Edit, Trash2, Move, ChevronRight, ChevronDown } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface FolderManagerProps {
  folders: Folder[];
  type: 'ability' | 'inventory';
  expandedFolders: string[];
  onUpdateFolders: (folders: Folder[]) => void;
  onToggleExpanded: (folderId: string) => void;
  onSelectFolder?: (folderId: string | undefined) => void;
  selectedFolderId?: string;
}

export function FolderManager({
  folders,
  type,
  expandedFolders,
  onUpdateFolders,
  onToggleExpanded,
  onSelectFolder,
  selectedFolderId,
}: FolderManagerProps) {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingFolder, setEditingFolder] = useState<Folder | null>(null);
  const [newFolderName, setNewFolderName] = useState('');
  const [newFolderParent, setNewFolderParent] = useState<string | undefined>();

  const createFolder = () => {
    if (!newFolderName.trim()) {
      toast.error('Le nom du dossier est requis');
      return;
    }

    const newFolder: Folder = {
      id: crypto.randomUUID(),
      name: newFolderName.trim(),
      parentId: newFolderParent,
      type,
      expanded: true,
    };

    onUpdateFolders([...folders, newFolder]);
    setNewFolderName('');
    setNewFolderParent(undefined);
    setShowCreateDialog(false);
    toast.success('Dossier créé');
  };

  const updateFolder = (folder: Folder) => {
    if (!newFolderName.trim()) {
      toast.error('Le nom du dossier est requis');
      return;
    }

    const updatedFolders = folders.map(f =>
      f.id === folder.id ? { ...f, name: newFolderName.trim() } : f
    );

    onUpdateFolders(updatedFolders);
    setEditingFolder(null);
    setNewFolderName('');
    toast.success('Dossier modifié');
  };

  const deleteFolder = (folderId: string) => {
    // Check if folder has children
    const hasChildren = folders.some(f => f.parentId === folderId);
    if (hasChildren) {
      toast.error('Impossible de supprimer un dossier contenant des sous-dossiers');
      return;
    }

    const updatedFolders = folders.filter(f => f.id !== folderId);
    onUpdateFolders(updatedFolders);
    toast.success('Dossier supprimé');
  };

  const moveFolder = (folderId: string, newParentId?: string) => {
    // Prevent circular references
    const wouldCreateCircularRef = (id: string, targetParentId?: string): boolean => {
      if (!targetParentId) return false;
      if (targetParentId === id) return true;
      
      const parent = folders.find(f => f.id === targetParentId);
      if (parent?.parentId) {
        return wouldCreateCircularRef(id, parent.parentId);
      }
      return false;
    };

    if (wouldCreateCircularRef(folderId, newParentId)) {
      toast.error('Impossible de créer une référence circulaire');
      return;
    }

    const updatedFolders = folders.map(f =>
      f.id === folderId ? { ...f, parentId: newParentId } : f
    );

    onUpdateFolders(updatedFolders);
    toast.success('Dossier déplacé');
  };

  const buildFolderTree = () => {
    const rootFolders = folders.filter(f => !f.parentId);
    const buildChildren = (parentId: string): Folder[] => {
      return folders
        .filter(f => f.parentId === parentId)
        .map(folder => ({
          ...folder,
          children: buildChildren(folder.id)
        }));
    };

    return rootFolders.map(folder => ({
      ...folder,
      children: buildChildren(folder.id)
    }));
  };

  const FolderItem = ({ 
    folder, 
    level = 0 
  }: { 
    folder: Folder & { children?: Folder[] }; 
    level?: number 
  }) => {
    const isExpanded = expandedFolders.includes(folder.id);
    const hasChildren = folder.children && folder.children.length > 0;
    const isSelected = selectedFolderId === folder.id;

    return (
      <div className="select-none">
        <div 
          className={`flex items-center gap-2 p-2 rounded hover:bg-muted cursor-pointer ${
            isSelected ? 'bg-primary/10 border border-primary/20' : ''
          }`}
          style={{ marginLeft: `${level * 16}px` }}
          onClick={() => onSelectFolder?.(folder.id)}
        >
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0"
            onClick={(e) => {
              e.stopPropagation();
              if (hasChildren) {
                onToggleExpanded(folder.id);
              }
            }}
          >
            {hasChildren ? (
              isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />
            ) : (
              <div className="w-4 h-4" />
            )}
          </Button>
          
          {isExpanded ? (
            <FolderOpen className="w-4 h-4 text-primary" />
          ) : (
            <FolderIcon className="w-4 h-4 text-muted-foreground" />
          )}
          
          <span className="flex-1 text-sm">{folder.name}</span>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                <MoreVertical className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => {
                setNewFolderName('');
                setNewFolderParent(folder.id);
                setShowCreateDialog(true);
              }}>
                <Plus className="w-4 h-4 mr-2" />
                Nouveau sous-dossier
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                setEditingFolder(folder);
                setNewFolderName(folder.name);
              }}>
                <Edit className="w-4 h-4 mr-2" />
                Renommer
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                onClick={() => deleteFolder(folder.id)}
                className="text-destructive"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Supprimer
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        {isExpanded && hasChildren && (
          <div>
            {folder.children?.map(child => (
              <FolderItem key={child.id} folder={child} level={level + 1} />
            ))}
          </div>
        )}
      </div>
    );
  };

  const folderTree = buildFolderTree();
  const availableParents = folders.filter(f => f.type === type);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium">Dossiers</h4>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                setNewFolderName('');
                setNewFolderParent(undefined);
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nouveau dossier
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md" aria-describedby={undefined}>
            <DialogHeader>
              <DialogTitle>Créer un dossier</DialogTitle>
              <DialogDescription>
                Créez un nouveau dossier pour organiser vos {type === 'ability' ? 'capacités' : 'objets'}.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="folder-name">Nom du dossier</Label>
                <Input
                  id="folder-name"
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  placeholder="Mon nouveau dossier"
                  autoFocus
                />
              </div>
              
              {availableParents.length > 0 && (
                <div>
                  <Label htmlFor="parent-folder">Dossier parent (optionnel)</Label>
                  <select
                    id="parent-folder"
                    value={newFolderParent || ''}
                    onChange={(e) => setNewFolderParent(e.target.value || undefined)}
                    className="w-full p-2 border rounded"
                  >
                    <option value="">Aucun (dossier racine)</option>
                    {availableParents.map(folder => (
                      <option key={folder.id} value={folder.id}>
                        {folder.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            
            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                Annuler
              </Button>
              <Button onClick={createFolder}>
                Créer
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Root level option */}
      <div 
        className={`flex items-center gap-2 p-2 rounded hover:bg-muted cursor-pointer ${
          selectedFolderId === undefined ? 'bg-primary/10 border border-primary/20' : ''
        }`}
        onClick={() => onSelectFolder?.(undefined)}
      >
        <div className="w-6 h-6" />
        <FolderIcon className="w-4 h-4 text-muted-foreground" />
        <span className="flex-1 text-sm">Racine (sans dossier)</span>
      </div>
      
      {/* Folder tree */}
      {folderTree.map(folder => (
        <FolderItem key={folder.id} folder={folder} />
      ))}
      
      {/* Edit folder dialog */}
      <Dialog open={!!editingFolder} onOpenChange={() => setEditingFolder(null)}>
        <DialogContent className="max-w-md" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>Renommer le dossier</DialogTitle>
            <DialogDescription>
              Modifiez le nom de ce dossier.
            </DialogDescription>
          </DialogHeader>
          
          <div>
            <Label htmlFor="edit-folder-name">Nom du dossier</Label>
            <Input
              id="edit-folder-name"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              placeholder="Nom du dossier"
              autoFocus
            />
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setEditingFolder(null)}>
              Annuler
            </Button>
            <Button onClick={() => editingFolder && updateFolder(editingFolder)}>
              Enregistrer
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}