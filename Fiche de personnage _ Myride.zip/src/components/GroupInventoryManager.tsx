import { useState, useMemo } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import type { Character, InventoryItem, InventorySortField, InventoryFilterCategory, InventoryFilterEquipped, Folder, Campaign } from '../types/game';
import { CurrencyManager } from './CurrencyManager';
import { FolderManager } from './FolderManager';
import { WeightDisplay } from './WeightDisplay';
import { InventoryItemForm } from './InventoryItemForm';
import { InventoryItemCard } from './InventoryItemCard';
import { Plus, Package, Shield, FolderOpen, ArrowUpDown, Users, ArrowLeftRight, Info, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { 
  calculateTotalWeight, 
  getEncumbranceLevel, 
  getItemsInFolder, 
  sortItems
} from '../utils/inventoryUtils';

interface GroupInventoryManagerProps {
  campaign: Campaign;
  characters: Character[];
  onUpdateCampaign: (campaign: Campaign) => Promise<void> | void;
  onUpdateCharacter?: (character: Character) => void;
  onBack?: () => void;
  currentUserId?: string;
  isGM?: boolean;
}

// Create a virtual character-like structure for group inventory
interface GroupInventory {
  id: string;
  name: string;
  inventory: {
    items: InventoryItem[];
    folders: Folder[];
    currency: {
      bronze: number;
      silver: number;
      gold: number;
    };
    totalWeight: number;
    encumbranceThreshold?: {
      light: number;
      medium: number;
      heavy: number;
    };
  };
}

export function GroupInventoryManager({ 
  campaign, 
  characters, 
  onUpdateCampaign, 
  onUpdateCharacter,
  onBack,
  currentUserId,
  isGM = false 
}: GroupInventoryManagerProps) {
  const [newItemOpen, setNewItemOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [sortField, setSortField] = useState<InventorySortField>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [filterCategory, setFilterCategory] = useState<InventoryFilterCategory>('all');
  const [filterEquipped, setFilterEquipped] = useState<InventoryFilterEquipped>('all');
  const [selectedFolderId, setSelectedFolderId] = useState<string | undefined>();
  const [expandedFolders, setExpandedFolders] = useState<string[]>([]);
  const [showTransferDialog, setShowTransferDialog] = useState(false);
  const [transferItem, setTransferItem] = useState<InventoryItem | null>(null);
  const [transferDirection, setTransferDirection] = useState<'to-group' | 'from-group'>('to-group');
  const [selectedCharacter, setSelectedCharacter] = useState<string>('');

  const [formData, setFormData] = useState<Partial<InventoryItem>>({
    name: '',
    quantity: 1,
    weight: 0,
    weightUnit: 'kg',
    folderId: undefined,
    category: 'misc',
    rarity: 'common',
    notes: '',
    equipped: false,
    identified: true,
    hasCharges: false,
    currentCharges: 0,
    rechargesOnLongRest: false,
    armorBonus: 0,
    tags: [],
  });

  // Get or create group inventory from campaign data
  const getGroupInventory = (): GroupInventory => {
    const groupData = (campaign as any).groupInventory;
    if (groupData) {
      return groupData;
    }

    // Create default group inventory
    return {
      id: `${campaign.id}-group`,
      name: 'Inventaire de Groupe',
      inventory: {
        items: [],
        folders: [],
        currency: { bronze: 0, silver: 0, gold: 0 },
        totalWeight: 0,
        encumbranceThreshold: {
          light: 100,
          medium: 200,
          heavy: 300
        }
      }
    };
  };

  const groupInventory = getGroupInventory();

  const updateGroupInventory = async (updatedInventory: GroupInventory) => {
    const updatedCampaign = {
      ...campaign,
      groupInventory: updatedInventory
    } as any;
    
    try {
      await onUpdateCampaign(updatedCampaign);
    } catch (error) {
      console.error('Error updating group inventory:', error);
      toast.error('Erreur lors de la sauvegarde de l\'inventaire de groupe');
    }
  };

  const totalWeight = useMemo(() => calculateTotalWeight(groupInventory.inventory.items), [groupInventory.inventory.items]);
  const encumbranceLevel = getEncumbranceLevel(totalWeight, groupInventory.inventory.encumbranceThreshold);

  const resetForm = () => {
    setFormData({
      name: '',
      quantity: 1,
      weight: 0,
      weightUnit: 'kg',
      folderId: selectedFolderId,
      category: 'misc',
      rarity: 'common',
      notes: '',
      equipped: false,
      identified: true,
      hasCharges: false,
      currentCharges: 0,
      rechargesOnLongRest: false,
      armorBonus: 0,
      tags: [],
    });
  };

  const updateInventoryFolders = async (folders: Folder[]) => {
    const updated = {
      ...groupInventory,
      inventory: {
        ...groupInventory.inventory,
        folders
      }
    };
    await updateGroupInventory(updated);
  };

  const toggleFolderExpanded = (folderId: string) => {
    const newExpanded = expandedFolders.includes(folderId)
      ? expandedFolders.filter(id => id !== folderId)
      : [...expandedFolders, folderId];
    setExpandedFolders(newExpanded);
  };

  const handleCreateItem = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name?.trim()) {
      toast.error('Le nom de l\'objet est requis');
      return;
    }

    const newItem: InventoryItem = {
      id: crypto.randomUUID(),
      name: formData.name.trim(),
      quantity: formData.quantity || 1,
      weight: formData.weight,
      weightUnit: formData.weightUnit || 'kg',
      folderId: formData.folderId,
      category: formData.category || 'misc',
      damage: formData.damage || '',
      rarity: formData.rarity || 'common',
      notes: formData.notes || '',
      equipped: formData.equipped || false,
      identified: formData.identified !== false,
      tags: formData.tags || [],
      hasCharges: formData.hasCharges || false,
      currentCharges: formData.hasCharges ? (formData.currentCharges || 0) : undefined,
      rechargesOnLongRest: formData.hasCharges ? (formData.rechargesOnLongRest || false) : undefined,
      armorBonus: formData.category === 'armor' ? (formData.armorBonus || 0) : undefined,
    };

    const updated = {
      ...groupInventory,
      inventory: {
        ...groupInventory.inventory,
        items: [...groupInventory.inventory.items, newItem]
      }
    };

    updateGroupInventory(updated);
    resetForm();
    setNewItemOpen(false);
    toast.success('Objet ajouté à l\'inventaire de groupe');
  };

  const handleEditItem = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingItem || !formData.name?.trim()) {
      toast.error('Le nom de l\'objet est requis');
      return;
    }

    const updatedItem: InventoryItem = {
      ...editingItem,
      name: formData.name.trim(),
      quantity: formData.quantity || 1,
      weight: formData.weight,
      weightUnit: formData.weightUnit || 'kg',
      folderId: formData.folderId,
      category: formData.category || 'misc',
      damage: formData.damage || '',
      rarity: formData.rarity || 'common',
      notes: formData.notes || '',
      equipped: formData.equipped || false,
      identified: formData.identified !== false,
      tags: formData.tags || [],
      hasCharges: formData.hasCharges || false,
      currentCharges: formData.hasCharges ? (formData.currentCharges || 0) : undefined,
      rechargesOnLongRest: formData.hasCharges ? (formData.rechargesOnLongRest || false) : undefined,
      armorBonus: formData.category === 'armor' ? (formData.armorBonus || 0) : undefined,
    };

    const updated = {
      ...groupInventory,
      inventory: {
        ...groupInventory.inventory,
        items: groupInventory.inventory.items.map(item => 
          item.id === editingItem.id ? updatedItem : item
        )
      }
    };

    updateGroupInventory(updated);
    setEditingItem(null);
    resetForm();
    toast.success('Objet modifié');
  };

  const handleDeleteItem = (itemId: string) => {
    const updated = {
      ...groupInventory,
      inventory: {
        ...groupInventory.inventory,
        items: groupInventory.inventory.items.filter(item => item.id !== itemId)
      }
    };

    updateGroupInventory(updated);
    toast.success('Objet supprimé');
  };

  const handleQuantityChange = (itemId: string, change: number) => {
    const item = groupInventory.inventory.items.find(i => i.id === itemId);
    if (!item) return;

    const newQuantity = Math.max(0, item.quantity + change);
    
    if (newQuantity === 0) {
      handleDeleteItem(itemId);
      return;
    }

    const updated = {
      ...groupInventory,
      inventory: {
        ...groupInventory.inventory,
        items: groupInventory.inventory.items.map(i => 
          i.id === itemId ? { ...i, quantity: newQuantity } : i
        )
      }
    };

    updateGroupInventory(updated);
  };

  const handleUseCharge = (itemId: string) => {
    const item = groupInventory.inventory.items.find(i => i.id === itemId);
    if (!item || !item.hasCharges || !item.currentCharges || item.currentCharges <= 0) return;

    const updated = {
      ...groupInventory,
      inventory: {
        ...groupInventory.inventory,
        items: groupInventory.inventory.items.map(i => 
          i.id === itemId ? { ...i, currentCharges: (i.currentCharges || 1) - 1 } : i
        )
      }
    };

    updateGroupInventory(updated);
    toast.success('Charge utilisée');
  };

  const startEditing = (item: InventoryItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      quantity: item.quantity,
      weight: item.weight,
      weightUnit: item.weightUnit,
      folderId: item.folderId,
      category: item.category,
      damage: item.damage,
      rarity: item.rarity,
      notes: item.notes,
      equipped: item.equipped,
      identified: item.identified,
      tags: item.tags,
      hasCharges: item.hasCharges || false,
      currentCharges: item.currentCharges || 0,
      rechargesOnLongRest: item.rechargesOnLongRest || false,
      armorBonus: item.armorBonus || 0,
    });
  };

  // Handle transfer operations
  const handleTransferItem = (item: InventoryItem, direction: 'to-group' | 'from-group') => {
    setTransferItem(item);
    setTransferDirection(direction);
    setShowTransferDialog(true);
  };

  const executeTransfer = () => {
    if (!transferItem || !selectedCharacter) {
      toast.error('Sélectionnez un personnage pour le transfert');
      return;
    }

    const character = characters.find(c => c.id === selectedCharacter);
    if (!character || !onUpdateCharacter) {
      toast.error('Personnage introuvable');
      return;
    }

    if (transferDirection === 'to-group') {
      // Move item from character to group
      const updatedCharacter = {
        ...character,
        inventory: {
          ...character.inventory,
          items: character.inventory.items.filter(item => item.id !== transferItem.id)
        }
      };

      const updatedGroup = {
        ...groupInventory,
        inventory: {
          ...groupInventory.inventory,
          items: [...groupInventory.inventory.items, { ...transferItem, folderId: undefined }]
        }
      };

      onUpdateCharacter(updatedCharacter);
      updateGroupInventory(updatedGroup);
      toast.success(`${transferItem.name} transféré vers l'inventaire de groupe`);
    } else {
      // Move item from group to character
      const updatedCharacter = {
        ...character,
        inventory: {
          ...character.inventory,
          items: [...character.inventory.items, { ...transferItem, folderId: undefined }]
        }
      };

      const updatedGroup = {
        ...groupInventory,
        inventory: {
          ...groupInventory.inventory,
          items: groupInventory.inventory.items.filter(item => item.id !== transferItem.id)
        }
      };

      onUpdateCharacter(updatedCharacter);
      updateGroupInventory(updatedGroup);
      toast.success(`${transferItem.name} transféré vers ${character.name}`);
    }

    setShowTransferDialog(false);
    setTransferItem(null);
    setSelectedCharacter('');
  };

  // Handle "All Items" virtual folder
  const isAllItemsSelected = selectedFolderId === 'all-items';
  const filteredItems = isAllItemsSelected 
    ? groupInventory.inventory.items.filter(item => {
        if (filterCategory !== 'all' && item.category !== filterCategory) return false;
        if (filterEquipped === 'equipped' && !item.equipped) return false;
        if (filterEquipped === 'unequipped' && item.equipped) return false;
        return true;
      })
    : getItemsInFolder(
        groupInventory.inventory.items, 
        selectedFolderId, 
        filterCategory, 
        filterEquipped
      );
  const sortedItems = sortItems(filteredItems, sortField, sortDirection);
  const equippedItems = groupInventory.inventory.items.filter(item => item.equipped);

  const handleSort = (field: InventorySortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleUpdateGroupCurrency = (updatedGroup: GroupInventory) => {
    updateGroupInventory(updatedGroup);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {onBack && (
                <Button variant="ghost" onClick={onBack}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Retour
                </Button>
              )}
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Inventaire de Groupe - {campaign.name}
              </CardTitle>
            </div>
          </div>
          {!isGM && (
            <Alert className="mt-4">
              <Info className="h-4 w-4" />
              <AlertDescription>
                Inventaire partagé de la campagne. Tous les joueurs peuvent consulter et modifier le contenu.
              </AlertDescription>
            </Alert>
          )}
        </CardHeader>
      </Card>

      <CurrencyManager 
        character={groupInventory as any} 
        onUpdateCharacter={handleUpdateGroupCurrency as any} 
      />
      
      <WeightDisplay 
        totalWeight={totalWeight}
        encumbranceLevel={encumbranceLevel}
        encumbranceThreshold={groupInventory.inventory.encumbranceThreshold}
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="md:col-span-1">
          <CardContent className="p-4">
            <div className="space-y-2">
              {/* Virtual "All Items" root */}
              <div className="mb-4">
                <Button
                  variant={selectedFolderId === 'all-items' ? 'default' : 'ghost'}
                  size="sm"
                  className="w-full justify-start p-2 h-auto"
                  onClick={() => setSelectedFolderId('all-items')}
                >
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4" />
                    <span className="flex-1 text-left">Tous les objets</span>
                    <Badge variant="secondary" className="text-xs">
                      {groupInventory.inventory.items.length}
                    </Badge>
                  </div>
                </Button>
              </div>
              
              {/* Regular folder structure */}
              <FolderManager
                folders={groupInventory.inventory.folders || []}
                type="inventory"
                expandedFolders={expandedFolders}
                onUpdateFolders={updateInventoryFolders}
                onToggleExpanded={toggleFolderExpanded}
                onSelectFolder={setSelectedFolderId}
                selectedFolderId={selectedFolderId}
              />
            </div>
          </CardContent>
        </Card>

        <div className="md:col-span-3">
          <Tabs defaultValue="inventory" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="inventory">
                {isAllItemsSelected ? (
                  <>
                    <Package className="w-4 h-4 mr-2" />
                    Tous les objets ({filteredItems.length})
                  </>
                ) : selectedFolderId ? (
                  <>
                    <FolderOpen className="w-4 h-4 mr-2" />
                    Dossier ({filteredItems.length})
                  </>
                ) : (
                  <>Inventaire ({filteredItems.length})</>
                )}
              </TabsTrigger>
              <TabsTrigger value="equipped">Équipé ({equippedItems.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="inventory" className="space-y-4">
              {/* Controls */}
              <div className="flex flex-wrap gap-2 items-center justify-between">
                <div className="flex flex-wrap gap-2">
                  <Select value={filterCategory} onValueChange={(value: InventoryFilterCategory) => setFilterCategory(value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Catégorie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes catégories</SelectItem>
                      <SelectItem value="weapon">Armes</SelectItem>
                      <SelectItem value="armor">Armures</SelectItem>
                      <SelectItem value="consumable">Consommables</SelectItem>
                      <SelectItem value="quest">Objets de quête</SelectItem>
                      <SelectItem value="unknown">Inconnus</SelectItem>
                      <SelectItem value="container">Conteneurs</SelectItem>
                      <SelectItem value="misc">Divers</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterEquipped} onValueChange={(value: InventoryFilterEquipped) => setFilterEquipped(value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="État" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="equipped">Équipés</SelectItem>
                      <SelectItem value="unequipped">Non équipés</SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="flex gap-1">
                    <Button variant="outline" size="sm" onClick={() => handleSort('name')}>
                      <ArrowUpDown className="w-3 h-3 mr-1" />
                      Nom {sortField === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleSort('category')}>
                      <ArrowUpDown className="w-3 h-3 mr-1" />
                      Catégorie {sortField === 'category' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleSort('weight')}>
                      <ArrowUpDown className="w-3 h-3 mr-1" />
                      Poids {sortField === 'weight' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </Button>
                  </div>
                </div>

                <Dialog open={newItemOpen} onOpenChange={setNewItemOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Ajouter un objet
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto" aria-describedby={undefined}>
                    <DialogHeader>
                      <DialogTitle>Ajouter un nouvel objet</DialogTitle>
                      <DialogDescription>
                        Ajoutez un nouvel objet à l'inventaire de groupe.
                      </DialogDescription>
                    </DialogHeader>
                    <InventoryItemForm
                      formData={formData}
                      setFormData={setFormData}
                      onSubmit={handleCreateItem}
                      onCancel={() => { setNewItemOpen(false); resetForm(); }}
                      folders={groupInventory.inventory.folders || []}
                    />
                  </DialogContent>
                </Dialog>
              </div>

              {/* Items List */}
              <div className="space-y-2">
                {sortedItems.length === 0 ? (
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                      <h3>Inventaire vide</h3>
                      <p className="text-muted-foreground mb-4">
                        {filterCategory !== 'all' || filterEquipped !== 'all' 
                          ? 'Aucun objet ne correspond aux filtres sélectionnés'
                          : isAllItemsSelected
                          ? 'Aucun objet dans l\'inventaire de groupe'
                          : selectedFolderId
                          ? 'Aucun objet dans ce dossier'
                          : 'Aucun objet dans l\'inventaire de groupe'
                        }
                      </p>
                      <Button onClick={() => setNewItemOpen(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Ajouter un objet
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  sortedItems.map((item) => (
                    <div key={item.id} className="relative">
                      <InventoryItemCard
                        item={item}
                        onEdit={startEditing}
                        onDelete={handleDeleteItem}
                        onToggleEquipped={() => {}} // Group items don't need equipped status
                        onUseCharge={handleUseCharge}
                        onQuantityChange={handleQuantityChange}
                      />
                      {onUpdateCharacter && characters.length > 0 && (
                        <div className="absolute top-2 right-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleTransferItem(item, 'from-group')}
                            title="Transférer vers un personnage"
                          >
                            <ArrowLeftRight className="w-3 h-3" />
                          </Button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="equipped" className="space-y-4">
              {equippedItems.length === 0 ? (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <Shield className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <h3>Aucun objet équipé</h3>
                    <p className="text-muted-foreground">
                      Les objets équipés de l'inventaire de groupe apparaîtront ici.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-2">
                  {equippedItems.map((item) => (
                    <Card key={item.id} className="border-primary">
                      <CardContent className="pt-4">
                        <div className="flex items-center gap-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-medium">{item.name}</h4>
                              <Badge variant="default">Équipé</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {item.category}
                              {item.damage && ` • ${item.damage}`}
                              {item.armorBonus && ` • +${item.armorBonus} Armure`}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Edit Item Dialog */}
      <Dialog open={!!editingItem} onOpenChange={() => { setEditingItem(null); resetForm(); }}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>Modifier : {editingItem?.name}</DialogTitle>
            <DialogDescription>
              Modifiez les propriétés de cet objet.
            </DialogDescription>
          </DialogHeader>
          <InventoryItemForm
            formData={formData}
            setFormData={setFormData}
            onSubmit={handleEditItem}
            onCancel={() => { setEditingItem(null); resetForm(); }}
            isEditing={true}
            folders={groupInventory.inventory.folders || []}
          />
        </DialogContent>
      </Dialog>

      {/* Transfer Dialog */}
      <Dialog open={showTransferDialog} onOpenChange={setShowTransferDialog}>
        <DialogContent className="max-w-md" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>Transférer un objet</DialogTitle>
            <DialogDescription>
              {transferDirection === 'to-group' 
                ? 'Transférer cet objet vers l\'inventaire de groupe'
                : 'Transférer cet objet vers un personnage'
              }
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium">{transferItem?.name}</h4>
              <p className="text-sm text-muted-foreground">
                Quantité: {transferItem?.quantity} • {transferItem?.category}
              </p>
            </div>
            
            <div>
              <label className="text-sm font-medium">Personnage</label>
              <Select value={selectedCharacter} onValueChange={setSelectedCharacter}>
                <SelectTrigger>
                  <SelectValue placeholder="Choisir un personnage..." />
                </SelectTrigger>
                <SelectContent>
                  {characters.map(character => (
                    <SelectItem key={character.id} value={character.id}>
                      {character.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowTransferDialog(false)}>
                Annuler
              </Button>
              <Button onClick={executeTransfer} disabled={!selectedCharacter}>
                Transférer
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}