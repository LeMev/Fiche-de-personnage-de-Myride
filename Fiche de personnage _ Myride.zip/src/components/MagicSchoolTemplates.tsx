import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import type { MagicSchool } from '../types/game';
import { Sparkles, Book, Plus, Scroll } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface MagicSchoolTemplatesProps {
  onSelectTemplate: (school: MagicSchool) => void;
}

const schoolTemplates: MagicSchool[] = [
  {
    id: 'template-forge',
    name: 'École de la Forge',
    description: 'Maîtrise du métal et de la forge magique',
    type: 'standard',
    isShared: false,
    createdBy: 'template',
    spells: [
      {
        id: 'spell-fonte-metal',
        name: 'Fonte du métal',
        description: 'Permet de faire fondre et modeler des objets métalliques. En combat, peut être utilisé comme attaque mais coûte plus cher.',
        costs: [
          {
            context: 'Hors combat',
            resources: [{ type: 'PM', amount: 2 }]
          },
          {
            context: 'Combat',
            resources: [{ type: 'PM', amount: 4 }]
          }
        ],
        activationType: 'action',
        range: 'Contact',
        duration: 'Instantané',
        scaling: '+1 PM permet de traiter 5 kg de métal supplémentaires'
      },
      {
        id: 'spell-durcissement',
        name: 'Durcissement',
        description: 'Augmente la résistance d\'un objet métallique ou d\'une armure.',
        costs: [
          {
            context: 'Standard',
            resources: [{ type: 'PM', amount: 3 }]
          }
        ],
        activationType: 'action',
        range: 'Contact',
        duration: '1 heure',
        scaling: '+1 PM augmente la durée de 30 minutes'
      }
    ]
  },
  {
    id: 'template-illusion-runic',
    name: 'École d\'Illusion Runique',
    description: 'Magie runique basée sur les illusions et la manipulation de la perception',
    type: 'runic',
    isShared: false,
    createdBy: 'template',
    baseRunes: [
      {
        id: 'rune-illusio',
        code: 'Illusio',
        name: 'Rune d\'Illusion',
        description: 'Rune permettant de créer des illusions visuelles et de manipuler la perception',
        masteryPercentage: 15,
        quickPowers: [
          {
            id: 'power-mirage',
            name: 'Mirage',
            description: 'Crée une petite illusion visuelle simple (changement de couleur, forme légère)',
            costs: [
              {
                context: 'Standard',
                resources: [{ type: 'PM', amount: 1 }]
              }
            ],
            activationType: 'bonus',
            range: '5 mètres',
            duration: '1 minute'
          }
        ],
        lastingPowers: [
          {
            id: 'power-invisibilite-partielle',
            name: 'Invisibilité partielle',
            description: 'Rend une partie du corps ou un objet tenu invisible',
            costs: [
              {
                context: 'Standard',
                resources: [{ type: 'PM', amount: 3 }]
              }
            ],
            activationType: 'action',
            range: 'Personnel',
            duration: '10 minutes',
            scaling: '+1 PM augmente la durée de 5 minutes'
          }
        ]
      },
      {
        id: 'rune-verit',
        code: 'Vérit',
        name: 'Rune de Vérité',
        description: 'Rune permettant de percer les illusions et révéler la vérité',
        masteryPercentage: 8,
        quickPowers: [
          {
            id: 'power-detection-illusion',
            name: 'Détection d\'illusion',
            description: 'Permet de détecter la présence d\'illusions dans un rayon de 10 mètres',
            costs: [
              {
                context: 'Standard',
                resources: [{ type: 'PM', amount: 1 }]
              }
            ],
            activationType: 'action',
            range: '10 mètres',
            duration: 'Instantané'
          }
        ],
        lastingPowers: [
          {
            id: 'power-vision-vraie',
            name: 'Vision vraie',
            description: 'Permet de voir à travers toutes les illusions et de percevoir la réalité',
            costs: [
              {
                context: 'Standard',
                resources: [{ type: 'PM', amount: 4 }]
              }
            ],
            activationType: 'action',
            range: 'Personnel',
            duration: '5 minutes'
          }
        ]
      }
    ]
  },
  {
    id: 'template-elementaire',
    name: 'École Élémentaire',
    description: 'Maîtrise des éléments de base : feu, eau, air et terre',
    type: 'standard',
    isShared: false,
    createdBy: 'template',
    spells: [
      {
        id: 'spell-boule-feu',
        name: 'Boule de feu',
        description: 'Lance une boule de feu explosive qui inflige des dégâts de feu dans une zone.',
        costs: [
          {
            context: 'Standard',
            resources: [{ type: 'PM', amount: 3 }]
          }
        ],
        activationType: 'action',
        range: '20 mètres',
        duration: 'Instantané',
        scaling: '+1 PM augmente les dégâts de 1d6',
        prerequisites: 'Niveau 3 minimum'
      },
      {
        id: 'spell-mur-glace',
        name: 'Mur de glace',
        description: 'Crée un mur de glace solide qui bloque le passage et peut servir de protection.',
        costs: [
          {
            context: 'Standard',
            resources: [{ type: 'PM', amount: 4 }]
          }
        ],
        activationType: 'action',
        range: '15 mètres',
        duration: '10 minutes',
        scaling: '+1 PM augmente la taille du mur de 3 mètres'
      },
      {
        id: 'spell-souffle-vent',
        name: 'Souffle du vent',
        description: 'Crée une puissante bourrasque qui peut repousser les ennemis ou disperser les gaz.',
        costs: [
          {
            context: 'Standard',
            resources: [{ type: 'PM', amount: 2 }]
          }
        ],
        activationType: 'action',
        range: 'Cône de 10 mètres',
        duration: 'Instantané'
      }
    ]
  }
];

export function MagicSchoolTemplates({ onSelectTemplate }: MagicSchoolTemplatesProps) {
  const handleSelectTemplate = (template: MagicSchool) => {
    const school = {
      ...template,
      id: crypto.randomUUID(),
      createdBy: ''
    };
    onSelectTemplate(school);
    toast.success(`Template "${template.name}" ajouté`);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Scroll className="w-4 h-4 mr-2" />
          Templates d'Écoles
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Templates d'Écoles de Magie</DialogTitle>
          <DialogDescription>
            Choisissez un template pré-configuré pour commencer rapidement
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="max-h-[60vh] pr-4">
          <div className="grid gap-4">
            {schoolTemplates.map((template) => (
              <Card key={template.id} className="cursor-pointer hover:bg-muted/50 transition-colors">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {template.type === 'runic' ? <Sparkles className="w-5 h-5" /> : <Book className="w-5 h-5" />}
                      <div>
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        <CardDescription>{template.description}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={template.type === 'runic' ? 'default' : 'secondary'}>
                        {template.type === 'runic' ? 'Runique' : 'Standard'}
                      </Badge>
                      <Button
                        size="sm"
                        onClick={() => handleSelectTemplate(template)}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Ajouter
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  {template.type === 'standard' ? (
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {template.spells?.length || 0} sorts inclus
                      </p>
                      <div className="space-y-1">
                        {template.spells?.slice(0, 3).map((spell) => (
                          <div key={spell.id} className="text-xs">
                            • <span className="font-medium">{spell.name}</span>
                            {spell.costs.length > 0 && (
                              <span className="text-muted-foreground">
                                {' '}({spell.costs[0].resources.map(r => `${r.amount} ${r.type}`).join(', ')})
                              </span>
                            )}
                          </div>
                        ))}
                        {(template.spells?.length || 0) > 3 && (
                          <div className="text-xs text-muted-foreground">
                            ... et {(template.spells?.length || 0) - 3} autres sorts
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {template.baseRunes?.length || 0} runes incluses
                      </p>
                      <div className="space-y-1">
                        {template.baseRunes?.map((rune) => (
                          <div key={rune.id} className="text-xs">
                            • <span className="font-bold">{rune.code}</span> - <span className="font-medium">{rune.name}</span>
                            <span className="text-muted-foreground">
                              {' '}({rune.quickPowers.length + rune.lastingPowers.length} pouvoirs)
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}