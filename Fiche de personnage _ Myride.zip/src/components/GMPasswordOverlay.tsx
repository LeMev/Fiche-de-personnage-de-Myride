import { useState } from 'react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Alert, AlertDescription } from './ui/alert';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { Copy, X, AlertCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import type { Character, Campaign } from '../types/game';

const GM_MASTER_PASSWORD = "Myride56!?";

interface GMPasswordOverlayProps {
  campaign: Campaign;
  characters: Character[];
  open: boolean;
  onClose: () => void;
}

export function GMPasswordOverlay({ campaign, characters, open, onClose }: GMPasswordOverlayProps) {
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordError, setPasswordError] = useState('');

  // Filter only protected characters
  const protectedCharacters = characters.filter(character => character.lock?.enabled);

  console.log('GMPasswordOverlay rendu:', { open, protectedCharacters: protectedCharacters.length });

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password === GM_MASTER_PASSWORD) {
      setIsAuthenticated(true);
      setPasswordError('');
    } else {
      setPasswordError('Mot de passe incorrect');
    }
  };

  const handleClose = () => {
    setPassword('');
    setIsAuthenticated(false);
    setPasswordError('');
    onClose();
  };

  const copyCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      toast.success('Code copié dans le presse-papiers');
    } catch (error) {
      toast.error('Erreur lors de la copie');
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className={isAuthenticated ? "max-w-4xl max-h-[90vh]" : "max-w-md"}>
        {!isAuthenticated ? (
          <>
            <DialogHeader>
              <DialogTitle>Entrer le mot de passe MJ</DialogTitle>
              <DialogDescription>
                Authentification requise pour accéder aux codes de protection.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div>
                <Label htmlFor="gm-password">Mot de passe MJ</Label>
                <Input
                  id="gm-password"
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setPasswordError('');
                  }}
                  placeholder="Saisir le mot de passe"
                  className={passwordError ? 'border-destructive' : ''}
                />
                {passwordError && (
                  <p className="text-sm text-destructive mt-1">{passwordError}</p>
                )}
              </div>
              
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={handleClose}>
                  Annuler
                </Button>
                <Button type="submit">
                  Valider
                </Button>
              </div>
            </form>
          </>
        ) : (
          <>
            <DialogHeader>
              <div className="flex items-center justify-between">
                <div>
                  <DialogTitle>Codes des fiches — {campaign.name}</DialogTitle>
                  <DialogDescription>
                    Codes de protection des personnages de la campagne
                  </DialogDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={handleClose}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </DialogHeader>

            <Alert className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {protectedCharacters.length === 0 ? 
                  'Aucune fiche protégée dans cette campagne.' :
                  'Ces codes sont visibles par le MJ. Ne les partagez pas aux joueurs.'
                }
              </AlertDescription>
            </Alert>

            {protectedCharacters.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <p>Aucun personnage n'a activé la protection par code dans cette campagne.</p>
              </div>
            ) : (
              <div className="overflow-auto max-h-[60vh]">
                {/* Version Desktop - Tableau */}
                <div className="hidden md:block">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Personnage</TableHead>
                        <TableHead>Protection</TableHead>
                        <TableHead>Code</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {protectedCharacters.map((character) => (
                        <TableRow key={character.id}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              {character.name}
                              <Badge variant={character.role === 'GM' ? 'default' : 'secondary'} className="text-xs">
                                {character.role}
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="destructive">
                              Activée
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <span className="font-mono text-lg">
                              {character.lock!.code}
                            </span>
                          </TableCell>
                          <TableCell>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => copyCode(character.lock!.code)}
                                  >
                                    <Copy className="w-3 h-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Copier le code</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* Version Mobile - Cartes */}
                <div className="md:hidden space-y-3">
                  {protectedCharacters.map((character) => (
                    <Card key={character.id}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-base">{character.name}</CardTitle>
                          <Badge variant={character.role === 'GM' ? 'default' : 'secondary'} className="text-xs">
                            {character.role}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Protection:</span>
                            <Badge variant="destructive" className="text-xs">
                              Activée
                            </Badge>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Code:</span>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-lg">
                                {character.lock!.code}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyCode(character.lock!.code)}
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}