import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from './ui/alert-dialog';
import type { Character, Ability, MagicSchool, Spell, AbilityCost, SpellCost, CostResource } from '../types/game';
import { Plus, Sparkles, User, Zap, Shield, Eye, Target, Scroll, Cat } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface MiaDataSetupProps {
  character: Character;
  onUpdateCharacter: (character: Character) => void;
}

export function MiaDataSetup({ character, onUpdateCharacter }: MiaDataSetupProps) {
  const [showDialog, setShowDialog] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const createCostResource = (type: string, amount: number): CostResource => ({
    id: Math.random().toString(36).substr(2, 9),
    type,
    amount
  });

  const createAbilityCost = (context: string, costs: Array<{ type: string; amount: number }>): AbilityCost => ({
    context,
    resources: costs.map(cost => createCostResource(cost.type, cost.amount))
  });

  const createSpellCost = (context: string, costs: Array<{ type: string; amount: number }>): SpellCost => ({
    id: Math.random().toString(36).substr(2, 9),
    context,
    resources: costs.map(cost => createCostResource(cost.type, cost.amount))
  });

  const getMiaAbilities = (): Ability[] => [
    // Capacités passives
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Dégâts augmentés (Griffes)",
      type: 'passive',
      description: "Les griffes infligent 1D6 de dégâts de base.",
      costs: [],
      tags: ['CàC', 'Feline'],
      effects: "Dégâts de base des griffes : 1D6",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Œil de chat",
      type: 'passive',
      description: "Vision dans le noir 20 m ; +10 pour toucher avec armes à distance.",
      costs: [],
      tags: ['Vision', 'Distance'],
      effects: "Vision nocturne 20m, +10% précision distance",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Toujours sur ses pattes",
      type: 'passive',
      description: "Peut chuter de 6 m sans dégâts.",
      costs: [],
      tags: ['Mobilité'],
      effects: "Immunité chute jusqu'à 6m",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Maîtrise du papier runique",
      type: 'passive',
      description: "Expertise sur feuilles/papier runique.",
      costs: [],
      tags: ['Artisanat', 'Runique'],
      effects: "Expertise papier runique",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Odorat & ouïe développés",
      type: 'passive',
      description: "Sens accrus.",
      costs: [],
      tags: ['Sens'],
      effects: "Odorat et ouïe améliorés",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Peintre né",
      type: 'passive',
      description: "+10% (artistique/peinture).",
      costs: [],
      tags: ['Artisanat'],
      effects: "+10% compétences artistiques/peinture",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },

    // Capacités actives - Actions
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Tir multiple",
      type: 'active',
      activationType: 'action',
      description: "Tirer 2 fois à l'arbalète en un tour.",
      costs: [createAbilityCost('Combat', [{ type: 'PM', amount: 1 }])],
      tags: ['Distance', 'Arbalète'],
      effects: "2 tirs d'arbalète dans la même action",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Attaque combo",
      type: 'active',
      activationType: 'action',
      description: "Si plusieurs adversaires au contact, faire 1 attaque CàC sur chacun dans la même action.",
      costs: [],
      tags: ['CàC', 'Multi-cible'],
      effects: "Attaque tous les ennemis adjacents",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Attaque sournoise",
      type: 'active',
      activationType: 'action',
      description: "Si non détectée, +10% pour toucher et +2D6 dégâts.",
      costs: [],
      tags: ['Furtif', 'Avantage'],
      effects: "Conditions : non détectée. +10% précision, +2D6 dégâts",
      prerequisites: "Non détectée par la cible",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Attaque combinée",
      type: 'active',
      activationType: 'action',
      description: "Attaque en synergie avec l'équipe.",
      costs: [],
      tags: ['Synergie'],
      effects: "Voir notes pour synergies d'équipe",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Apprentissage des runes",
      type: 'active',
      activationType: 'rest',
      description: "4D8 pour apprendre des runes.",
      costs: [],
      tags: ['Runique', 'Progression'],
      effects: "Jet 4D8 apprentissage runes",
      frequency: 'once-per-day',
      restRefresh: 'long',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },

    // Capacités réactives
    {
      id: Math.random().toString(36).substr(2, 9),
      name: "Neuf vies",
      type: 'active',
      activationType: 'reaction',
      description: "Si l'attaque est vue venir, relance un jet d'attaque qui devait toucher Mia.",
      costs: [],
      tags: ['Défense'],
      effects: "Force relance attaque ennemie (si vue venir)",
      frequency: 'once-per-turn',
      prerequisites: "Attaque vue venir",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];

  const getMiaRunicSchool = (): MagicSchool => ({
    id: Math.random().toString(36).substr(2, 9),
    name: "Runique",
    description: "École de magie runique de Mia",
    type: 'elven',
    isShared: false,
    createdBy: character.id,
    spells: [
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Graverune",
        description: "Apposer 1 rune sur un objet et déclencher aussitôt.",
        costs: [createSpellCost('Standard', [{ type: 'PM', amount: 1 }])],
        activationType: 'action',
        range: "Contact",
        duration: "Instantané",
        tags: ['Runique', 'Objet'],
        scaling: "Coût minimum 1 PM"
      },
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Runes combinées",
        description: "Combiner 2 runes sur 1 objet ; en combat : pas de déplacement ce tour-ci.",
        costs: [createSpellCost('Combat', [{ type: 'PM', amount: 3 }])],
        activationType: 'action',
        range: "Contact",
        duration: "Instantané",
        tags: ['Runique', 'Combinaison'],
        limitations: "Pas de déplacement en combat"
      },
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Rune à retardement",
        description: "Peut retarder l'activation d'1 rune (1 seule active en réserve à la fois).",
        costs: [],
        activationType: 'bonus',
        range: "Personnel",
        duration: "Jusqu'à activation",
        tags: ['Runique', 'Préparation'],
        limitations: "1 seule rune en réserve"
      },
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Surcharge runique",
        description: "Sur jet de Pouvoir réussi, consomme 2 utilisations d'un même objet pour amplifier l'effet ; coût en PM variable selon effet.",
        costs: [createSpellCost('Standard', [{ type: 'PM', amount: 1 }])],
        activationType: 'action',
        range: "Contact",
        duration: "Instantané",
        tags: ['Runique', 'Amplification'],
        prerequisites: "Jet de Pouvoir réussi",
        scaling: "Coût PM variable selon effet"
      },
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Évolution du gantelet runique",
        description: "Associer 1 pierre de mana au gantelet ; peut insuffler les carreaux via la pierre sans jet de Pouvoir (le gantelet l'effectue).",
        costs: [createSpellCost('Rituel', [{ type: 'PM', amount: 3 }])],
        activationType: 'ritual',
        range: "Contact",
        duration: "Permanent",
        tags: ['Runique', 'Pierre de mana', 'Arbalète'],
        limitations: "Préparation 1h"
      },
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Combattant runique - Cible",
        description: "Après une attaque réussie : graver + activer 1 rune sur la cible.",
        costs: [createSpellCost('Après attaque', [{ type: 'PM', amount: 3 }])],
        activationType: 'bonus',
        range: "Contact",
        duration: "Instantané",
        tags: ['Runique', 'Polyvalent'],
        prerequisites: "Attaque CàC réussie"
      },
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Combattant runique - Objet",
        description: "1h de gravure : jusqu'à 2 runes actives tant qu'un autre objet n'est pas gravé. Activation : action rapide.",
        costs: [createSpellCost('Hors combat', [{ type: 'PM', amount: 3 }])],
        activationType: 'ritual',
        range: "Contact",
        duration: "Jusqu'à nouvel objet",
        tags: ['Runique', 'Polyvalent'],
        limitations: "1h de gravure, activation action rapide"
      }
    ]
  });

  const getMiaBestialSchool = (): MagicSchool => ({
    id: Math.random().toString(36).substr(2, 9),
    name: "Bestiale",
    description: "École de magie bestiale de Mia",
    type: 'elven',
    isShared: false,
    createdBy: character.id,
    spells: [
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Transformation partielle",
        description: "Choisir 1 bonus tant que la forme est maintenue : +2 Armure / Mobilité x2 / +10 Précision / +1D6 dégâts CàC.",
        costs: [createSpellCost('Standard', [{ type: 'PM', amount: 2 }])],
        activationType: 'action',
        range: "Personnel",
        duration: "Maintenue",
        tags: ['Métamorphose'],
        scaling: "Choisir 1 bonus parmi les 4 options"
      },
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Transformation totale",
        description: "Forme chat complète, très discrète (infiltration).",
        costs: [createSpellCost('Standard', [{ type: 'PM', amount: 3 }])],
        activationType: 'action',
        range: "Personnel",
        duration: "Maintenue",
        tags: ['Métamorphose', 'Furtif']
      },
      {
        id: Math.random().toString(36).substr(2, 9),
        name: "Transformation hybride",
        description: "Cumule tous les bonus de partielle ; peut attaquer 2 fois (+1 PM pour la 2e attaque).",
        costs: [
          createSpellCost('Activation', [{ type: 'PM', amount: 4 }]),
          createSpellCost('2e attaque', [{ type: 'PM', amount: 1 }])
        ],
        activationType: 'action',
        range: "Personnel",
        duration: "4 tours",
        tags: ['Métamorphose', 'Combat'],
        scaling: "2e attaque coûte +1 PM"
      }
    ]
  });

  const handleAddMiaData = () => {
    const newAbilities = getMiaAbilities();
    const runicSchool = getMiaRunicSchool();
    const bestialSchool = getMiaBestialSchool();

    const updatedCharacter: Character = {
      ...character,
      abilities: [...character.abilities, ...newAbilities],
      magic: {
        ...character.magic,
        schools: [...character.magic.schools, runicSchool, bestialSchool]
      },
      updatedAt: new Date().toISOString()
    };

    onUpdateCharacter(updatedCharacter);
    setShowDialog(false);
    setShowConfirm(false);
    
    toast.success(`Ajouté avec succès !`, {
      description: `${newAbilities.length} capacités et 2 écoles de magie (Runique, Bestiale) ajoutées pour Mia.`
    });
  };

  return (
    <>
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogTrigger asChild>
          <Button variant="outline" className="gap-2">
            <User className="w-4 h-4" />
            Données Mia
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Ajouter les données de Mia
            </DialogTitle>
            <DialogDescription>
              Ceci ajoutera toutes les capacités et magies spécifiques de Mia (rôdeuse runique bestiale).
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Capacités à ajouter (12)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="font-medium mb-1">Passives :</p>
                    <ul className="text-muted-foreground space-y-1">
                      <li>• Dégâts augmentés (Griffes)</li>
                      <li>• Œil de chat</li>
                      <li>• Toujours sur ses pattes</li>
                      <li>• Maîtrise du papier runique</li>
                      <li>• Odorat & ouïe développés</li>
                      <li>• Peintre né</li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium mb-1">Actives :</p>
                    <ul className="text-muted-foreground space-y-1">
                      <li>• Tir multiple (1 PM)</li>
                      <li>• Neuf vies (Réaction)</li>
                      <li>• Attaque combo</li>
                      <li>• Attaque sournoise</li>
                      <li>• Attaque combinée</li>
                      <li>• Apprentissage des runes</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  Écoles de magie à ajouter (2)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium mb-1">École Runique (7 sorts) :</p>
                    <ul className="text-muted-foreground space-y-1">
                      <li>• Graverune (1+ PM)</li>
                      <li>• Runes combinées (3 PM)</li>
                      <li>• Rune à retardement</li>
                      <li>• Surcharge runique (variable)</li>
                      <li>• Évolution du gantelet (3 PM)</li>
                      <li>• Combattant runique - Cible (3 PM)</li>
                      <li>• Combattant runique - Objet (3 PM)</li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium mb-1">École Bestiale (3 sorts) :</p>
                    <ul className="text-muted-foreground space-y-1">
                      <li>• Transformation partielle (2 PM)</li>
                      <li>• Transformation totale (3 PM)</li>
                      <li>• Transformation hybride (4 PM)</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="bg-blue-50 dark:bg-blue-950/20 p-3 rounded-lg">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                ℹ️ Le système Focus est automatiquement pris en compte et réduira les coûts PM de 1 (minimum 0) lors de l'utilisation.
              </p>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Annuler
            </Button>
            <Button onClick={() => setShowConfirm(true)}>
              Ajouter tout
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer l'ajout</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir ajouter toutes les capacités et magies de Mia ? 
              Cela ajoutera 12 capacités et 2 écoles de magie (10 sorts au total) à la fiche de {character.name}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleAddMiaData}>
              Confirmer l'ajout
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}