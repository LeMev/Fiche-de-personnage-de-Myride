import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Slider } from './ui/slider';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Plus, Minus, Info, Trophy, Star, HelpCircle, ChevronRight } from 'lucide-react';
import { RestManager } from './RestManager';
import { cn } from './ui/utils';
import type { Character } from '../types/game';
import {
  CHARACTERISTICS,
  MASTERY_TIERS,
  validateAttributes,
  calculateSkillAllocation,
  getMasteryTier,
  getSkillBonus,
  getCharacterSkillMastery,
  updateSkillMastery,
  MIN_ATTRIBUTE_VALUE,
  MAX_ATTRIBUTE_VALUE
} from '../utils/characterUtils';

interface CharacteristicsSkillsManagerProps {
  character: Character;
  onUpdateCharacter: (character: Character) => void;
}

export function CharacteristicsSkillsManager({ character, onUpdateCharacter }: CharacteristicsSkillsManagerProps) {
  const [showHelp, setShowHelp] = useState(false);
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({});

  const validation = validateAttributes(character.attributes);
  const skillAllocation = calculateSkillAllocation(character);
  const skillMastery = getCharacterSkillMastery(character);

  const handleAttributeChange = (characteristic: keyof Character['attributes'], value: number) => {
    const clampedValue = Math.max(MIN_ATTRIBUTE_VALUE, Math.min(MAX_ATTRIBUTE_VALUE, value));
    const newAttributes = {
      ...character.attributes,
      [characteristic]: clampedValue
    };

    const updatedCharacter = {
      ...character,
      attributes: newAttributes,
      skillMastery: updateSkillMastery({
        ...character,
        attributes: newAttributes
      })
    };

    onUpdateCharacter(updatedCharacter);
  };

  const handleSkillChange = (
    characteristic: keyof Character['skills'],
    skill: string,
    value: number
  ) => {
    const newSkills = {
      ...character.skills,
      [characteristic]: {
        ...character.skills[characteristic],
        [skill]: Math.max(0, value)
      }
    };

    const updatedCharacter = {
      ...character,
      skills: newSkills,
      skillMastery: updateSkillMastery({
        ...character,
        skills: newSkills
      })
    };

    onUpdateCharacter(updatedCharacter);
  };

  const getMasteryIcon = (tier: number) => {
    switch (tier) {
      case 5: return <Star className="h-4 w-4 text-blue-500" />;
      case 10: return <Trophy className="h-4 w-4 text-purple-500" />;
      case 15: return <Star className="h-4 w-4 text-orange-500" />;
      case 20: return <Trophy className="h-4 w-4 text-yellow-500" />;
      default: return null;
    }
  };

  const getMasteryColor = (tier: number) => {
    switch (tier) {
      case 5: return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 10: return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 15: return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      case 20: return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };



  // Render collapsed summary grid for a characteristic
  const renderCollapsedSummary = (characteristic: any) => {
    const skills = characteristic.skills;
    const skillValues = character.skills[characteristic.name];
    
    return (
      <div className="grid grid-cols-3 sm:grid-cols-3 gap-x-3 gap-y-1 text-xs sm:text-xs leading-tight max-w-full m-[0px]">
        {skills.map((skill: any) => {
          const value = skillValues[skill.key] || 0;
          return (
            <div key={skill.key} className="min-w-28">
              <div className="truncate text-center text-[14px] not-italic" title={skill.label}>
                {skill.label}
              </div>
              <div className="font-semibold tabular-nums text-center text-[14px] no-underline font-bold mt-[9px] mr-[0px] mb-[0px] ml-[0px]">
                {value}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <TooltipProvider>
      <div className="relative">
        {/* Desktop Layout: 2 columns */}
        <div className="hidden lg:grid lg:grid-cols-2 lg:gap-8">
          {/* Left Column - Characteristics */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    Caractéristiques
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setShowHelp(!showHelp)}
                        >
                          <HelpCircle className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <div className="max-w-xs">
                          <p className="font-medium mb-2">Règles des caractéristiques :</p>
                          <ul className="text-sm space-y-1">
                            <li>• Minimum 10, Maximum 70</li>
                            <li>• Budget total : 280 points</li>
                            <li>• Les dizaines arrondies donnent le budget de compétences</li>
                          </ul>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </CardTitle>
                  <div className="flex items-center gap-4 text-sm">
                    <Badge variant={validation.remainingPoints >= 0 ? "default" : "destructive"}>
                      {validation.remainingPoints} points restants
                    </Badge>
                    <span className="text-muted-foreground">
                      Total : {validation.totalPoints} / 280
                    </span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {CHARACTERISTICS.map((char) => (
                <div key={char.name} className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor={`${char.name}-slider`} className="text-base font-medium">
                      {char.label}
                    </Label>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAttributeChange(char.name, character.attributes[char.name] - 1)}
                        disabled={character.attributes[char.name] <= MIN_ATTRIBUTE_VALUE}
                        aria-label={`Réduire ${char.label}`}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <Input
                        id={`${char.name}-input`}
                        type="number"
                        value={character.attributes[char.name]}
                        onChange={(e) => handleAttributeChange(char.name, parseInt(e.target.value) || MIN_ATTRIBUTE_VALUE)}
                        className="w-16 text-center"
                        min={MIN_ATTRIBUTE_VALUE}
                        max={MAX_ATTRIBUTE_VALUE}
                        aria-label={`Valeur de ${char.label}`}
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAttributeChange(char.name, character.attributes[char.name] + 1)}
                        disabled={character.attributes[char.name] >= MAX_ATTRIBUTE_VALUE}
                        aria-label={`Augmenter ${char.label}`}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  <Slider
                    id={`${char.name}-slider`}
                    min={MIN_ATTRIBUTE_VALUE}
                    max={MAX_ATTRIBUTE_VALUE}
                    step={1}
                    value={[character.attributes[char.name]]}
                    onValueChange={(value) => handleAttributeChange(char.name, value[0])}
                    className="w-full"
                    aria-label={`Curseur pour ${char.label}`}
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Right Column - Collapsible Skills */}
          <div className="space-y-2">
            {CHARACTERISTICS.map((char) => {
              const allocation = skillAllocation[char.name];
              const isOpen = openSections[char.name] || false;
              
              return (
                <Collapsible 
                  key={char.name} 
                  open={isOpen}
                  onOpenChange={(open) => setOpenSections(prev => ({ ...prev, [char.name]: open }))}
                >
                  <Card>
                    <CollapsibleTrigger asChild>
                      <CardHeader 
                        className="cursor-pointer hover:bg-muted/50 transition-colors py-[8px] py-[9px] px-[21px] py-[10px]"
                        role="button"
                        aria-expanded={isOpen}
                        aria-controls={`skills-${char.name}`}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            setOpenSections(prev => ({ ...prev, [char.name]: !isOpen }));
                          }
                        }}
                        tabIndex={0}
                      >
                        <div className="flex flex-row justify-between py-[8px] py-[3px] px-[0px]">
                          {/* Left side - characteristic name and chevron */}
                          <div className="inline-flex items-center gap-2 m-[0px] w-fit">
                            <ChevronRight className={cn(
                              "h-4 w-4 transition-transform duration-200",
                              isOpen && "rotate-90"
                            )} />
                            <CardTitle className="text-lg font-normal font-bold text-[16px] text-left text-center">{char.label}</CardTitle>
                          </div>
                          
                          {/* Right side - collapsed summary grid */}
                          {!isOpen && renderCollapsedSummary(char)}
                        </div>
                      </CardHeader>
                    </CollapsibleTrigger>
                    
                    {/* Expanded content - full UI */}
                    <CollapsibleContent id={`skills-${char.name}`}>
                      <div className="px-6">
                        <div className="flex items-center justify-between pb-3">
                          <div className="flex items-center gap-2">
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div>
                                  <Badge variant="outline" className="flex items-center gap-1">
                                    <HelpCircle className="h-3 w-3" />
                                    {allocation.used} / {allocation.canSpend}
                                  </Badge>
                                </div>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Budget compétence = dizaine arrondie de {char.label} ({character.attributes[char.name]} → {allocation.canSpend} pts)</p>
                              </TooltipContent>
                            </Tooltip>
                            {allocation.used > allocation.available && (
                              <Badge variant="secondary" className="text-xs">
                                +{allocation.used - allocation.available} bonus
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <CardContent className="space-y-4">
                        {char.skills.map((skill) => {
                          const skillPoints = character.skills[char.name][skill.key as keyof typeof character.skills[typeof char.name]];
                          const fullSkillName = `${char.name}.${skill.key}`;
                          const mastery = skillMastery[fullSkillName];
                          const tier = mastery.tier;
                          
                          return (
                            <div key={skill.key} className="flex items-center justify-between p-3 border rounded-lg">
                              <div className="flex items-center gap-3 flex-1">
                                <Label className="font-medium min-w-0 flex-1">{skill.label}</Label>
                                {tier.level > 0 && (
                                  <div className="flex items-center gap-1 flex-shrink-0">
                                    {getMasteryIcon(tier.level)}
                                    <Badge 
                                      variant="secondary" 
                                      className={`text-xs ${getMasteryColor(tier.level)}`}
                                    >
                                      {tier.name}
                                    </Badge>
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex items-center gap-2 flex-shrink-0">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleSkillChange(char.name, skill.key, skillPoints - 1)}
                                  disabled={skillPoints <= 0}
                                  aria-label={`Réduire ${skill.label}`}
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <Input
                                  type="number"
                                  value={skillPoints}
                                  onChange={(e) => handleSkillChange(char.name, skill.key, parseInt(e.target.value) || 0)}
                                  className="w-16 text-center"
                                  min="0"
                                  aria-label={`Points de compétence pour ${skill.label}`}
                                />
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleSkillChange(char.name, skill.key, skillPoints + 1)}
                                  aria-label={`Augmenter ${skill.label}`}
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          );
                        })}
                      </CardContent>
                    </CollapsibleContent>
                  </Card>
                </Collapsible>
              );
            })}
          </div>
        </div>

        {/* Mobile Layout: Vertical Stack */}
        <div className="lg:hidden space-y-6 pb-24">
          {/* Characteristics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Caractéristiques
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setShowHelp(!showHelp)}
                    >
                      <HelpCircle className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="max-w-xs">
                      <p className="font-medium mb-2">Règles des caractéristiques :</p>
                      <ul className="text-sm space-y-1">
                        <li>• Minimum 10, Maximum 70</li>
                        <li>• Budget total : 280 points</li>
                        <li>• Les dizaines arrondies donnent le budget de compétences</li>
                      </ul>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {CHARACTERISTICS.map((char) => (
                <div key={char.name} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor={`${char.name}-mobile`} className="font-medium">
                      {char.label}
                    </Label>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAttributeChange(char.name, character.attributes[char.name] - 1)}
                        disabled={character.attributes[char.name] <= MIN_ATTRIBUTE_VALUE}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <Input
                        id={`${char.name}-mobile`}
                        type="number"
                        value={character.attributes[char.name]}
                        onChange={(e) => handleAttributeChange(char.name, parseInt(e.target.value) || MIN_ATTRIBUTE_VALUE)}
                        className="w-16 text-center"
                        min={MIN_ATTRIBUTE_VALUE}
                        max={MAX_ATTRIBUTE_VALUE}
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAttributeChange(char.name, character.attributes[char.name] + 1)}
                        disabled={character.attributes[char.name] >= MAX_ATTRIBUTE_VALUE}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  <Slider
                    min={MIN_ATTRIBUTE_VALUE}
                    max={MAX_ATTRIBUTE_VALUE}
                    step={1}
                    value={[character.attributes[char.name]]}
                    onValueChange={(value) => handleAttributeChange(char.name, value[0])}
                    className="w-full"
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Skills */}
          {CHARACTERISTICS.map((char) => {
            const allocation = skillAllocation[char.name];
            return (
              <Card key={char.name}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{char.label}</CardTitle>
                    <Badge variant="outline">
                      {allocation.used} / {allocation.canSpend} pts
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {char.skills.map((skill) => {
                    const skillPoints = character.skills[char.name][skill.key as keyof typeof character.skills[typeof char.name]];
                    const fullSkillName = `${char.name}.${skill.key}`;
                    const mastery = skillMastery[fullSkillName];
                    const tier = mastery.tier;
                    
                    return (
                      <div key={skill.key} className="flex items-center justify-between p-2 border rounded">
                        <div className="flex items-center gap-2 flex-1">
                          <span className="font-medium text-sm">{skill.label}</span>
                          {tier.level > 0 && getMasteryIcon(tier.level)}
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleSkillChange(char.name, skill.key, skillPoints - 1)}
                            disabled={skillPoints <= 0}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center text-sm">{skillPoints}</span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleSkillChange(char.name, skill.key, skillPoints + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            );
          })}

          {/* Mastery Overview Mobile */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Aperçu des Maîtrises</CardTitle>
                  <CardDescription>Compétences avec paliers atteints</CardDescription>
                </div>
                <RestManager
                  character={character}
                  onUpdateCharacter={onUpdateCharacter}
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-2">
                {Object.entries(skillMastery)
                  .filter(([_, mastery]) => mastery.tier.level > 0)
                  .map(([skillName, mastery]) => {
                    const [charName, skillKey] = skillName.split('.');
                    const char = CHARACTERISTICS.find(c => c.name === charName);
                    const skill = char?.skills.find(s => s.key === skillKey);
                    
                    return (
                      <div key={skillName} className="flex items-center gap-2 p-2 bg-muted rounded-lg">
                        {getMasteryIcon(mastery.tier.level)}
                        <div className="flex-1">
                          <div className="font-medium text-sm">{skill?.label}</div>
                          <div className="text-xs text-muted-foreground">
                            {mastery.tier.name} • +{mastery.bonus}%
                          </div>
                        </div>
                      </div>
                    );
                  })}
                
                {Object.entries(skillMastery).filter(([_, mastery]) => mastery.tier.level > 0).length === 0 && (
                  <div className="text-center text-muted-foreground py-4 text-sm">
                    Aucune maîtrise atteinte pour le moment
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Mobile Sticky Footer */}
        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-background border-t p-4 z-10">
          <div className="flex items-center justify-between max-w-md mx-auto">
            <div className="flex flex-col">
              <span className="text-sm font-medium">
                Points restants : {validation.remainingPoints} / 220
              </span>
              <span className="text-xs text-muted-foreground">
                Total : {validation.totalPoints} / 280
              </span>
            </div>
            <Button 
              variant={validation.isValid ? "default" : "secondary"}
              className="ml-4"
            >
              {validation.isValid ? "✓ Valide" : "Valider"}
            </Button>
          </div>
        </div>

        {/* Desktop Mastery Overview */}
        <div className="hidden lg:block mt-8">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Aperçu des Maîtrises</CardTitle>
                  <CardDescription>Compétences avec paliers atteints</CardDescription>
                </div>
                <RestManager
                  character={character}
                  onUpdateCharacter={onUpdateCharacter}
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                {Object.entries(skillMastery)
                  .filter(([_, mastery]) => mastery.tier.level > 0)
                  .map(([skillName, mastery]) => {
                    const [charName, skillKey] = skillName.split('.');
                    const char = CHARACTERISTICS.find(c => c.name === charName);
                    const skill = char?.skills.find(s => s.key === skillKey);
                    
                    return (
                      <div key={skillName} className="flex items-center gap-2 p-2 bg-muted rounded-lg">
                        {getMasteryIcon(mastery.tier.level)}
                        <div className="flex-1">
                          <div className="font-medium text-sm">{skill?.label}</div>
                          <div className="text-xs text-muted-foreground">
                            {mastery.tier.name} • +{mastery.bonus}%
                          </div>
                        </div>
                      </div>
                    );
                  })}
                
                {Object.entries(skillMastery).filter(([_, mastery]) => mastery.tier.level > 0).length === 0 && (
                  <div className="col-span-full text-center text-muted-foreground py-4">
                    Aucune maîtrise atteinte pour le moment
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </TooltipProvider>
  );
}