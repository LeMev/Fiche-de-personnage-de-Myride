import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import type { Ability } from '../types/game';
import { Edit, Trash2, Play, Shield, Swords, Clock, Zap, RotateCcw, Copy } from 'lucide-react';
import { getActivationTypeLabel, getFrequencyLabel } from '../constants/abilityConstants';
import { copyToClipboard } from '../utils/clipboardUtils';
import { toCanonicalAbility, serializeCanonical, type CanonicalAbilityPayload } from '../utils/abilitySchema';
import { toast } from 'sonner@2.0.3';

interface AbilityCardProps {
  ability: Ability;
  editMode: boolean;
  onUse: (ability: Ability) => void;
  onEdit: (ability: Ability) => void;
  onDelete: (abilityId: string) => void;
  canUse: boolean;
  useDisabledReason?: string;
}

export function AbilityCard({ 
  ability, 
  editMode, 
  onUse, 
  onEdit, 
  onDelete, 
  canUse, 
  useDisabledReason 
}: AbilityCardProps) {
  const handleCopyAbility = async () => {
    try {
      // Sérialiser au format canonique
      const canonical = toCanonicalAbility(ability);
      const payload: CanonicalAbilityPayload = {
        abilities: [canonical]
      };
      
      await copyToClipboard(payload);
      toast.success('Capacité copiée au format Myride (abilities).');
    } catch (error) {
      console.error('Erreur lors de la copie de la capacité:', error);
      toast.error('Erreur lors de la copie');
    }
  };
  return (
    <Card className="relative">
      <CardContent className="pt-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <h4 className="font-medium text-lg">{ability.name}</h4>
            <Badge variant={ability.type === 'passive' ? 'secondary' : 'default'}>
              {ability.type === 'passive' ? (
                <>
                  <Shield className="w-3 h-3 mr-1" />
                  Passif
                </>
              ) : (
                <>
                  <Zap className="w-3 h-3 mr-1" />
                  Actif
                </>
              )}
            </Badge>
            
            {ability.type === 'active' && ability.activationType && (
              <Badge variant="outline">
                {getActivationTypeLabel(ability.activationType)}
              </Badge>
            )}
          </div>
          
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={handleCopyAbility}
              title="Copier cette capacité"
            >
              <Copy className="w-4 h-4" />
            </Button>

            {ability.type === 'active' && !editMode && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => onUse(ability)}
                disabled={!canUse}
                title={useDisabledReason}
              >
                <Play className="w-4 h-4 mr-2" />
                Utiliser
              </Button>
            )}
            
            {editMode && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onEdit(ability)}
                >
                  <Edit className="w-4 h-4" />
                </Button>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="outline">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Supprimer la capacité</AlertDialogTitle>
                      <AlertDialogDescription>
                        Êtes-vous sûr de vouloir supprimer "{ability.name}" ? 
                        Cette action est irréversible et supprimera aussi l'historique d'utilisation.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Annuler</AlertDialogCancel>
                      <AlertDialogAction onClick={() => onDelete(ability.id)}>
                        Supprimer
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </>
            )}
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <h5 className="text-sm font-medium text-muted-foreground mb-1">Description</h5>
            <p className="text-sm leading-relaxed">{ability.description}</p>
          </div>

          {ability.effects && (
            <div>
              <h5 className="text-sm font-medium text-muted-foreground mb-1">Effets mécaniques</h5>
              <p className="text-sm leading-relaxed font-mono text-green-700 dark:text-green-400">
                {ability.effects}
              </p>
            </div>
          )}

          {ability.costs.length > 0 && (
            <div>
              <h5 className="text-sm font-medium text-muted-foreground mb-1">Coûts</h5>
              <div className="flex flex-wrap gap-2">
                {ability.costs.map((cost, index) => (
                  <Badge key={index} variant="outline">
                    {cost.context}: {cost.resources.map(r => 
                      `${r.amount} ${r.type}${r.perUnit ? ` ${r.perUnit}` : ''}`
                    ).join(', ')}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {ability.type === 'active' && (
            <div className="flex flex-wrap gap-4 text-sm">
              {ability.frequency && ability.frequency !== 'unlimited' && (
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Fréquence:</span>
                  <span>{getFrequencyLabel(ability.frequency, ability)}</span>
                </div>
              )}

              {ability.usedToday && ability.usedToday > 0 && (
                <div className="flex items-center gap-1">
                  <RotateCcw className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Utilisé:</span>
                  <span>{ability.usedToday} fois aujourd'hui</span>
                </div>
              )}

              {ability.currentCooldown && ability.currentCooldown > 0 && (
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-orange-500" />
                  <span className="text-orange-500">
                    Récupération: {ability.currentCooldown} tours
                  </span>
                </div>
              )}
            </div>
          )}

          {ability.prerequisites && (
            <div>
              <h5 className="text-sm font-medium text-muted-foreground mb-1">Prérequis</h5>
              <p className="text-sm text-amber-700 dark:text-amber-400">{ability.prerequisites}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}