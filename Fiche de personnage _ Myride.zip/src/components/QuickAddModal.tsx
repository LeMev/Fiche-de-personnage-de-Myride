import { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Search, Plus, X, Sparkles } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { PRESET_GLOSSARY_ITEMS } from '../constants/glossaryConstants';
import type { GlossaryItem, GlossaryFilterType, GlossarySortField, Character, Ability, Spell } from '../types/game';

interface QuickAddModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preFilterType?: 'capacité' | 'magie';
  character: Character;
  onAddItems: (items: GlossaryItem[]) => void;
}

export function QuickAddModal({ 
  open, 
  onOpenChange, 
  preFilterType, 
  character,
  onAddItems 
}: QuickAddModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<GlossaryFilterType>(preFilterType || 'all');
  const [filterSchool, setFilterSchool] = useState<string>('all');
  const [filterFolder, setFilterFolder] = useState<string>('all');
  const [filterTag, setFilterTag] = useState<string>('all');
  const [sortField, setSortField] = useState<GlossarySortField>('name');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [focusedIndex, setFocusedIndex] = useState<number>(0);
  
  // Mock glossary items - in real implementation, this would come from backend/storage
  const [glossaryItems] = useState<GlossaryItem[]>(PRESET_GLOSSARY_ITEMS);
  
  // Reset filter type when preFilterType changes
  useEffect(() => {
    if (preFilterType) {
      setFilterType(preFilterType);
    }
  }, [preFilterType]);

  // Get unique values for filters
  const { schools, folders, tags } = useMemo(() => {
    const schoolsSet = new Set<string>();
    const foldersSet = new Set<string>();
    const tagsSet = new Set<string>();
    
    glossaryItems.forEach(item => {
      if (item.school) schoolsSet.add(item.school);
      if (item.folderId) foldersSet.add(item.folderId);
      item.tags.forEach(tag => tagsSet.add(tag));
    });
    
    return {
      schools: Array.from(schoolsSet).sort(),
      folders: Array.from(foldersSet).sort(),
      tags: Array.from(tagsSet).sort(),
    };
  }, [glossaryItems]);

  // Filter and sort items
  const filteredItems = useMemo(() => {
    let items = [...glossaryItems];
    
    // Apply type filter
    if (filterType !== 'all') {
      items = items.filter(item => item.type === filterType);
    }
    
    // Apply school filter
    if (filterSchool !== 'all') {
      items = items.filter(item => item.school === filterSchool);
    }
    
    // Apply folder filter
    if (filterFolder !== 'all') {
      items = items.filter(item => item.folderId === filterFolder);
    }
    
    // Apply tag filter
    if (filterTag !== 'all') {
      items = items.filter(item => item.tags.includes(filterTag));
    }
    
    // Apply search
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      items = items.filter(item => 
        item.name.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        item.tags.some(tag => tag.toLowerCase().includes(query)) ||
        (item.school && item.school.toLowerCase().includes(query))
      );
    }
    
    // Sort
    items.sort((a, b) => {
      switch (sortField) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'school':
          return (a.school || '').localeCompare(b.school || '');
        case 'type':
          return a.type.localeCompare(b.type);
        case 'createdAt':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        default:
          return 0;
      }
    });
    
    return items;
  }, [glossaryItems, filterType, filterSchool, filterFolder, filterTag, searchQuery, sortField]);

  const handleToggleSelection = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setFocusedIndex(prev => Math.min(prev + 1, filteredItems.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setFocusedIndex(prev => Math.max(prev - 1, 0));
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      if (filteredItems[focusedIndex]) {
        handleToggleSelection(filteredItems[focusedIndex].id);
      }
    } else if (e.key === 'Escape') {
      onOpenChange(false);
    }
  };

  const handleAdd = () => {
    const itemsToAdd = filteredItems.filter(item => selectedIds.has(item.id));
    onAddItems(itemsToAdd);
    setSelectedIds(new Set());
    onOpenChange(false);
    toast.success(`${itemsToAdd.length} élément${itemsToAdd.length !== 1 ? 's' : ''} ajouté${itemsToAdd.length !== 1 ? 's' : ''}`);
  };

  const selectedItem = filteredItems[focusedIndex];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] flex flex-col" onKeyDown={handleKeyDown}>
        <DialogHeader>
          <DialogTitle>Ajout rapide {preFilterType === 'capacité' ? 'de capacité' : preFilterType === 'magie' ? 'de magie' : ''}</DialogTitle>
          <DialogDescription>
            Sélectionnez des éléments depuis le glossaire pour les ajouter à ce personnage
          </DialogDescription>
        </DialogHeader>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher (⌘K ou Ctrl+K)..."
            className="pl-9"
            autoFocus
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2">
          {!preFilterType && (
            <Select value={filterType} onValueChange={(v) => setFilterType(v as GlossaryFilterType)}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous types</SelectItem>
                <SelectItem value="capacité">Capacités</SelectItem>
                <SelectItem value="magie">Magie</SelectItem>
              </SelectContent>
            </Select>
          )}
          
          {schools.length > 0 && (
            <Select value={filterSchool} onValueChange={setFilterSchool}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="École" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes écoles</SelectItem>
                {schools.map(school => (
                  <SelectItem key={school} value={school}>{school}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          
          {tags.length > 0 && (
            <Select value={filterTag} onValueChange={setFilterTag}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Tag" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous tags</SelectItem>
                {tags.map(tag => (
                  <SelectItem key={tag} value={tag}>{tag}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          
          <Select value={sortField} onValueChange={(v) => setSortField(v as GlossarySortField)}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Tri" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Nom</SelectItem>
              <SelectItem value="school">École</SelectItem>
              <SelectItem value="type">Type</SelectItem>
              <SelectItem value="createdAt">Récents</SelectItem>
            </SelectContent>
          </Select>

          {/* Clear filters */}
          {(filterSchool !== 'all' || filterFolder !== 'all' || filterTag !== 'all' || searchQuery) && (
            <Button variant="ghost" size="sm" onClick={() => {
              setSearchQuery('');
              setFilterSchool('all');
              setFilterFolder('all');
              setFilterTag('all');
            }}>
              <X className="w-4 h-4 mr-2" />
              Effacer
            </Button>
          )}
        </div>

        <Separator />

        {/* Content area with list and preview */}
        <div className="flex-1 grid grid-cols-2 gap-4 min-h-0">
          {/* List */}
          <ScrollArea className="h-full pr-4">
            {filteredItems.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Sparkles className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Aucun élément trouvé</p>
                <p className="text-sm mt-2">Le glossaire est vide pour le moment</p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredItems.map((item, index) => (
                  <div
                    key={item.id}
                    className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                      index === focusedIndex ? 'bg-accent' : 'hover:bg-accent/50'
                    }`}
                    onClick={() => {
                      setFocusedIndex(index);
                      handleToggleSelection(item.id);
                    }}
                  >
                    <Checkbox
                      checked={selectedIds.has(item.id)}
                      onCheckedChange={() => handleToggleSelection(item.id)}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">{item.name}</span>
                        <Badge variant={item.type === 'magie' ? 'default' : 'secondary'} className="text-xs">
                          {item.type}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {item.school && (
                          <Badge variant="outline" className="text-xs">{item.school}</Badge>
                        )}
                        {item.tags.slice(0, 2).map(tag => (
                          <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                        ))}
                        {item.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">+{item.tags.length - 2}</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Preview panel */}
          <div className="border rounded-lg p-4 bg-muted/30">
            {selectedItem ? (
              <div className="space-y-3">
                <div>
                  <h4 className="font-medium mb-1">{selectedItem.name}</h4>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant={selectedItem.type === 'magie' ? 'default' : 'secondary'}>
                      {selectedItem.type}
                    </Badge>
                    {selectedItem.school && (
                      <Badge variant="outline">{selectedItem.school}</Badge>
                    )}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Description</p>
                  <p className="text-sm">{selectedItem.description}</p>
                </div>
                
                {selectedItem.tags.length > 0 && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Tags</p>
                    <div className="flex flex-wrap gap-1">
                      {selectedItem.tags.map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                {selectedItem.activationType && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Type d'activation</p>
                    <p className="text-sm">{selectedItem.activationType}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center text-muted-foreground text-sm py-12">
                Sélectionnez un élément pour voir les détails
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-4 border-t">
          <p className="text-sm text-muted-foreground">
            {selectedIds.size} élément{selectedIds.size !== 1 ? 's' : ''} sélectionné{selectedIds.size !== 1 ? 's' : ''}
          </p>
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Annuler
            </Button>
            <Button onClick={handleAdd} disabled={selectedIds.size === 0}>
              <Plus className="w-4 h-4 mr-2" />
              Ajouter {selectedIds.size > 0 ? `${selectedIds.size} élément${selectedIds.size !== 1 ? 's' : ''}` : ''}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}