import { useState, useEffect, useMemo } from 'react';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { ScrollArea } from './ui/scroll-area';
import type { Character, SearchResult } from '../types/game';
import { Search, Scroll, Swords, Package, Sparkles, Book } from 'lucide-react';

interface GlobalSearchProps {
  character: Character;
  onNavigate?: (result: SearchResult) => void;
  placeholder?: string;
  compact?: boolean;
}

export function GlobalSearch({ 
  character, 
  onNavigate, 
  placeholder = "Rechercher sorts, capacités, objets...",
  compact = false 
}: GlobalSearchProps) {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  // Build search index
  const searchResults = useMemo(() => {
    if (!query.trim() || query.length < 2) return [];

    const results: SearchResult[] = [];
    const lowerQuery = query.toLowerCase();

    // Search in magic schools and spells
    character.magic.schools.forEach(school => {
      // Search school names
      if (school.name.toLowerCase().includes(lowerQuery) || 
          school.description?.toLowerCase().includes(lowerQuery)) {
        results.push({
          id: school.id,
          name: school.name,
          type: 'school',
          description: school.description,
          location: 'Magie',
          tags: [school.type === 'elven' ? 'elven' : 'runic']
        });
      }

      // Search spells in elven schools
      if (school.type === 'elven' && school.spells) {
        school.spells.forEach(spell => {
          if (spell.name.toLowerCase().includes(lowerQuery) ||
              spell.description.toLowerCase().includes(lowerQuery) ||
              spell.tags?.some(tag => tag.toLowerCase().includes(lowerQuery))) {
            results.push({
              id: spell.id,
              name: spell.name,
              type: 'spell',
              description: spell.description,
              location: `Magie > ${school.name}`,
              tags: spell.tags || []
            });
          }
        });
      }

      // Search runes and powers in runic schools
      if (school.type === 'runic' && school.baseRunes) {
        school.baseRunes.forEach(rune => {
          if (rune.name.toLowerCase().includes(lowerQuery) ||
              rune.description.toLowerCase().includes(lowerQuery) ||
              rune.code.toLowerCase().includes(lowerQuery)) {
            results.push({
              id: rune.id,
              name: `${rune.name} (${rune.code})`,
              type: 'rune',
              description: rune.description,
              location: `Magie > ${school.name}`,
              tags: ['rune']
            });
          }

          // Search powers within runes
          [...rune.quickPowers, ...rune.lastingPowers].forEach(power => {
            if (power.name.toLowerCase().includes(lowerQuery) ||
                power.description.toLowerCase().includes(lowerQuery)) {
              results.push({
                id: power.id,
                name: power.name,
                type: 'spell', // Powers are similar to spells
                description: power.description,
                location: `Magie > ${school.name} > ${rune.name}`,
                tags: ['power', 'rune']
              });
            }
          });
        });
      }
    });

    // Search abilities
    character.abilities.forEach(ability => {
      if (ability.name.toLowerCase().includes(lowerQuery) ||
          ability.description.toLowerCase().includes(lowerQuery) ||
          ability.effects.toLowerCase().includes(lowerQuery) ||
          ability.tags?.some(tag => tag.toLowerCase().includes(lowerQuery))) {
        
        let location = 'Capacités';
        if (ability.folderId) {
          const folder = character.abilityFolders?.find(f => f.id === ability.folderId);
          if (folder) {
            location = `Capacités > ${folder.name}`;
          }
        }

        results.push({
          id: ability.id,
          name: ability.name,
          type: 'ability',
          description: ability.description,
          location,
          tags: ability.tags || []
        });
      }
    });

    // Search inventory items
    character.inventory.items.forEach(item => {
      if (item.name.toLowerCase().includes(lowerQuery) ||
          item.notes.toLowerCase().includes(lowerQuery) ||
          item.tags?.some(tag => tag.toLowerCase().includes(lowerQuery))) {
        
        let location = 'Inventaire';
        if (item.folderId) {
          const folder = character.inventory.folders?.find(f => f.id === item.folderId);
          if (folder) {
            location = `Inventaire > ${folder.name}`;
          }
        }

        results.push({
          id: item.id,
          name: item.name,
          type: 'item',
          description: item.notes,
          location,
          tags: [item.category, ...(item.tags || [])]
        });
      }
    });

    return results.slice(0, 20); // Limit results
  }, [query, character]);

  const getResultIcon = (type: SearchResult['type']) => {
    switch (type) {
      case 'school': return <Book className="w-4 h-4" />;
      case 'spell': return <Scroll className="w-4 h-4" />;
      case 'ability': return <Swords className="w-4 h-4" />;
      case 'item': return <Package className="w-4 h-4" />;
      case 'rune': return <Sparkles className="w-4 h-4" />;
      default: return <Search className="w-4 h-4" />;
    }
  };

  const getResultTypeLabel = (type: SearchResult['type']) => {
    switch (type) {
      case 'school': return 'École';
      case 'spell': return 'Sort';
      case 'ability': return 'Capacité';
      case 'item': return 'Objet';
      case 'rune': return 'Rune';
      default: return 'Résultat';
    }
  };

  const handleResultClick = (result: SearchResult) => {
    onNavigate?.(result);
    setIsOpen(false);
    setQuery('');
  };

  if (compact) {
    return (
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={placeholder}
              className="pl-8 cursor-pointer"
              readOnly
            />
          </div>
        </DialogTrigger>
        <DialogContent className="max-w-2xl max-h-[80vh]" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>Recherche globale</DialogTitle>
            <DialogDescription>
              Recherchez parmi vos sorts, capacités, objets et écoles de magie
            </DialogDescription>
          </DialogHeader>
          <GlobalSearchContent
            query={query}
            setQuery={setQuery}
            searchResults={searchResults}
            getResultIcon={getResultIcon}
            getResultTypeLabel={getResultTypeLabel}
            handleResultClick={handleResultClick}
            placeholder={placeholder}
          />
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={placeholder}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-8"
          onFocus={() => setIsOpen(true)}
        />
      </div>
      
      {isOpen && query.length >= 2 && (
        <Card className="absolute top-full left-0 right-0 mt-1 z-50 shadow-lg">
          <CardContent className="p-0">
            <ScrollArea className="max-h-80">
              {searchResults.length === 0 ? (
                <div className="p-4 text-center text-muted-foreground">
                  Aucun résultat trouvé
                </div>
              ) : (
                <div className="space-y-1">
                  {searchResults.map((result, index) => (
                    <div
                      key={`${result.type}-${result.id}-${index}`}
                      className="flex items-start gap-3 p-3 hover:bg-muted cursor-pointer"
                      onClick={() => handleResultClick(result)}
                    >
                      {getResultIcon(result.type)}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{result.name}</span>
                          <Badge variant="outline" className="text-xs">
                            {getResultTypeLabel(result.type)}
                          </Badge>
                        </div>
                        {result.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {result.description}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">
                          {result.location}
                        </p>
                        {result.tags && result.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {result.tags.slice(0, 3).map((tag, tagIndex) => (
                              <Badge key={tagIndex} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      )}
      
      {/* Overlay to close search */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setIsOpen(false)}
        />
      )}
    </div>
  );
}

// Extracted content component for reuse
function GlobalSearchContent({
  query,
  setQuery,
  searchResults,
  getResultIcon,
  getResultTypeLabel,
  handleResultClick,
  placeholder
}: {
  query: string;
  setQuery: (query: string) => void;
  searchResults: SearchResult[];
  getResultIcon: (type: SearchResult['type']) => React.ReactNode;
  getResultTypeLabel: (type: SearchResult['type']) => string;
  handleResultClick: (result: SearchResult) => void;
  placeholder: string;
}) {
  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={placeholder}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-8"
          autoFocus
        />
      </div>
      
      <ScrollArea className="max-h-[50vh]">
        {query.length < 2 ? (
          <div className="text-center py-8 text-muted-foreground">
            Tapez au moins 2 caractères pour rechercher
          </div>
        ) : searchResults.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Aucun résultat trouvé pour "{query}"
          </div>
        ) : (
          <div className="space-y-2">
            {searchResults.map((result, index) => (
              <Card
                key={`${result.type}-${result.id}-${index}`}
                className="cursor-pointer hover:bg-muted/50"
                onClick={() => handleResultClick(result)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    {getResultIcon(result.type)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium truncate">{result.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {getResultTypeLabel(result.type)}
                        </Badge>
                      </div>
                      {result.description && (
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {result.description}
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">
                        {result.location}
                      </p>
                      {result.tags && result.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {result.tags.slice(0, 5).map((tag, tagIndex) => (
                            <Badge key={tagIndex} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}