import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { Badge } from './ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { useCharacters, useCampaigns } from '../hooks/useApi';
import { GMPasswordOverlay } from './GMPasswordOverlay';
import { CreateMiaCharacter } from './CreateMiaCharacter';
import type { Campaign, Character, SortField, SortDirection } from '../types/game';
import { Plus, Trash2, Edit, ArrowLeft, ArrowUpDown, Users, Crown, Sword, Package, Lock, KeyRound } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface CharacterManagerProps {
  campaign: Campaign;
  onBack: () => void;
  onSelectCharacter: (character: Character) => void;
  onSelectGroupInventory?: (campaign: Campaign, characters: Character[], updateCampaign: (campaign: Campaign) => Promise<Campaign>) => void;
}

export function CharacterManager({ campaign, onBack, onSelectCharacter, onSelectGroupInventory }: CharacterManagerProps) {
  const { characters, loading, error, createCharacter, deleteCharacter, updateCharacter } = useCharacters(campaign.id);
  const { updateCampaign } = useCampaigns();
  const [newCharacterOpen, setNewCharacterOpen] = useState(false);
  const [gmPasswordOverlayOpen, setGmPasswordOverlayOpen] = useState(false);
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [formData, setFormData] = useState({
    name: '',
    race: '',
    class: '',
    level: 1,
    age: 20,
    role: 'PC' as 'GM' | 'PC'
  });

  const handleCreateCharacter = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast.error('Le nom du personnage est requis');
      return;
    }

    try {
      await createCharacter(formData);
      setFormData({
        name: '',
        race: '',
        class: '',
        level: 1,
        age: 20,
        role: 'PC'
      });
      setNewCharacterOpen(false);
      toast.success('Personnage créé avec succès');
    } catch (error) {
      toast.error('Erreur lors de la création du personnage');
      console.error('Create character error:', error);
    }
  };

  const handleDeleteCharacter = async (character: Character) => {
    try {
      await deleteCharacter(character.id);
      toast.success('Personnage supprimé avec succès');
    } catch (error) {
      toast.error('Erreur lors de la suppression du personnage');
      console.error('Delete character error:', error);
    }
  };

  const sortedCharacters = [...characters].sort((a, b) => {
    let aValue: any = a[sortField];
    let bValue: any = b[sortField];
    
    if (typeof aValue === 'string') {
      aValue = aValue.toLowerCase();
      bValue = bValue.toLowerCase();
    }
    
    if (sortDirection === 'asc') {
      return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
    } else {
      return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
    }
  });

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  if (loading) {
    return (
      <div className="p-8 text-center">
        <p>Chargement des personnages...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 text-center">
        <p className="text-destructive">Erreur : {error}</p>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour
          </Button>
          <div>
            <h1 className="text-2xl font-bold">{campaign.name}</h1>
            <p className="text-muted-foreground">
              Gestion des personnages
            </p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => {
              console.log('Ouverture de l\'overlay MJ');
              setGmPasswordOverlayOpen(true);
            }}
          >
            <KeyRound className="w-4 h-4 mr-2" />
            Mot de passe
          </Button>
          
          {onSelectGroupInventory && (
            <Button 
              variant="outline" 
              onClick={() => onSelectGroupInventory(campaign, characters, updateCampaign)}
            >
              <Package className="w-4 h-4 mr-2" />
              Inventaire de Groupe
            </Button>
          )}
          
          <Dialog open={newCharacterOpen} onOpenChange={setNewCharacterOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Nouveau Personnage
              </Button>
            </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Créer un nouveau personnage</DialogTitle>
              <DialogDescription>
                Ajoutez un nouveau personnage à cette campagne.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateCharacter} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nom *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Nom du personnage"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="role">Rôle</Label>
                  <Select 
                    value={formData.role} 
                    onValueChange={(value: 'GM' | 'PC') => setFormData(prev => ({ ...prev, role: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PC">Joueur (PC)</SelectItem>
                      <SelectItem value="GM">Maître de Jeu (GM)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="race">Race</Label>
                  <Input
                    id="race"
                    value={formData.race}
                    onChange={(e) => setFormData(prev => ({ ...prev, race: e.target.value }))}
                    placeholder="Ex: Humain, Elfe..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="class">Classe</Label>
                  <Input
                    id="class"
                    value={formData.class}
                    onChange={(e) => setFormData(prev => ({ ...prev, class: e.target.value }))}
                    placeholder="Ex: Guerrier, Mage..."
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="level">Niveau</Label>
                  <Input
                    id="level"
                    type="number"
                    min="1"
                    value={formData.level}
                    onChange={(e) => setFormData(prev => ({ ...prev, level: parseInt(e.target.value) || 1 }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="age">Âge</Label>
                  <Input
                    id="age"
                    type="number"
                    min="1"
                    value={formData.age}
                    onChange={(e) => setFormData(prev => ({ ...prev, age: parseInt(e.target.value) || 20 }))}
                  />
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setNewCharacterOpen(false)}
                >
                  Annuler
                </Button>
                <Button type="submit">Créer</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Sort controls */}
      <div className="flex gap-2 mb-4">
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleSort('name')}
          className="gap-2"
        >
          <ArrowUpDown className="w-3 h-3" />
          Nom
          {sortField === 'name' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleSort('level')}
          className="gap-2"
        >
          <ArrowUpDown className="w-3 h-3" />
          Niveau
          {sortField === 'level' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleSort('class')}
          className="gap-2"
        >
          <ArrowUpDown className="w-3 h-3" />
          Classe
          {sortField === 'class' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleSort('role')}
          className="gap-2"
        >
          <ArrowUpDown className="w-3 h-3" />
          Rôle
          {sortField === 'role' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
        </Button>
      </div>

      {characters.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center">
            <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3>Aucun personnage</h3>
            <p className="text-muted-foreground mb-4">
              Créez votre premier personnage pour cette campagne
            </p>
            <Button onClick={() => setNewCharacterOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Créer un personnage
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {sortedCharacters.map((character) => (
            <Card key={character.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1" onClick={() => onSelectCharacter(character)}>
                    <div className="flex items-center gap-2 mb-2">
                      <CardTitle className="text-lg">{character.name}</CardTitle>
                      {character.lock?.enabled && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger>
                              <Lock className="w-4 h-4 text-muted-foreground" />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Protégée par code</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                      <Badge variant={character.role === 'GM' ? 'default' : 'secondary'}>
                        {character.role === 'GM' ? (
                          <>
                            <Crown className="w-3 h-3 mr-1" />
                            GM
                          </>
                        ) : (
                          <>
                            <Sword className="w-3 h-3 mr-1" />
                            PC
                          </>
                        )}
                      </Badge>
                    </div>
                    <CardDescription>
                      {character.race} {character.class && `• ${character.class}`}
                      {character.level && ` • Niveau ${character.level}`}
                    </CardDescription>
                  </div>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Supprimer le personnage</AlertDialogTitle>
                        <AlertDialogDescription>
                          Êtes-vous sûr de vouloir supprimer le personnage "{character.name}" ? 
                          Cette action ne peut pas être annulée.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Annuler</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={() => handleDeleteCharacter(character)}
                        >
                          Supprimer
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardHeader>
              
              <CardContent onClick={() => onSelectCharacter(character)}>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>PV:</span>
                    <span>{character.resources.hp.current}/{character.resources.hp.max}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>PM:</span>
                    <span>{character.resources.mp.current}/{character.resources.mp.max}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Objets:</span>
                    <span>{character.inventory.items.length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      <GMPasswordOverlay
        campaign={campaign}
        characters={characters}
        open={gmPasswordOverlayOpen}
        onClose={() => {
          console.log('Fermeture de l\'overlay MJ');
          setGmPasswordOverlayOpen(false);
        }}
      />
    </div>
  );
}