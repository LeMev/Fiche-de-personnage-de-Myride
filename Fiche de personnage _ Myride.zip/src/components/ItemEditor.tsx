import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Plus, X, Sparkles } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import SpellCostEditor from './SpellCostEditor';
import type { GlossaryItem, GlossaryFolder, AbilityCost, SpellCost } from '../types/game';

interface ItemEditorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: GlossaryItem | null;
  folders: GlossaryFolder[];
  onSave: (item: GlossaryItem, addToSheet?: boolean) => void;
  defaultType?: 'capacité' | 'magie';
}

export function ItemEditor({ open, onOpenChange, item, folders, onSave, defaultType }: ItemEditorProps) {
  const [formData, setFormData] = useState<Partial<GlossaryItem>>({
    type: defaultType || 'capacité',
    name: '',
    description: '',
    tags: [],
    costProfiles: [],
    effects: '',
    source: 'user',
  });
  const [tagInput, setTagInput] = useState('');
  const [errors, setErrors] = useState<string[]>([]);

  useEffect(() => {
    if (item) {
      setFormData(item);
    } else {
      setFormData({
        type: defaultType || 'capacité',
        name: '',
        description: '',
        tags: [],
        costProfiles: [],
        effects: '',
        source: 'user',
      });
    }
    setErrors([]);
  }, [item, open, defaultType]);

  const validate = (): boolean => {
    const newErrors: string[] = [];
    
    if (!formData.name?.trim()) {
      newErrors.push('Le nom est requis');
    }
    
    if (!formData.type) {
      newErrors.push('Le type est requis');
    }
    
    if (!formData.description?.trim()) {
      newErrors.push('La description est requise');
    }
    
    if (formData.type === 'magie' && !formData.school?.trim()) {
      newErrors.push('L\'école de magie est requise pour les sorts');
    }
    
    setErrors(newErrors);
    return newErrors.length === 0;
  };

  const handleSave = (addToSheet = false) => {
    if (!validate()) {
      toast.error('Veuillez corriger les erreurs avant de sauvegarder');
      return;
    }

    const savedItem: GlossaryItem = {
      id: item?.id || crypto.randomUUID(),
      type: formData.type as 'capacité' | 'magie',
      name: formData.name!,
      school: formData.school,
      tags: formData.tags || [],
      folderId: formData.folderId,
      description: formData.description!,
      costProfiles: formData.costProfiles || [],
      createdAt: item?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      source: formData.source || 'user',
      activationType: formData.activationType,
      frequency: formData.frequency,
      prerequisites: formData.prerequisites,
      effects: formData.effects,
      range: formData.range,
      duration: formData.duration,
      scaling: formData.scaling,
      limitations: formData.limitations,
    };

    onSave(savedItem, addToSheet);
    onOpenChange(false);
    toast.success(item ? 'Élément mis à jour' : 'Élément créé');
  };

  const addTag = () => {
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...(prev.tags || []), tagInput.trim()]
      }));
      setTagInput('');
    }
  };

  const removeTag = (tag: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags?.filter(t => t !== tag) || []
    }));
  };

  const updateCostProfiles = (costs: AbilityCost[] | SpellCost[]) => {
    setFormData(prev => ({
      ...prev,
      costProfiles: costs
    }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl h-[90vh] p-0 flex flex-col overflow-hidden">
        <DialogHeader className="px-6 pt-6 pb-4">
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            {item ? 'Modifier l\'élément' : 'Nouvel élément'}
          </DialogTitle>
          <DialogDescription>
            {formData.type === 'capacité' ? 'Créez ou modifiez une capacité' : 'Créez ou modifiez un sort'}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="min-h-0 flex-1 px-6">
          <div className="space-y-4 py-4">
            {errors.length > 0 && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                <p className="text-sm text-destructive font-medium mb-1">Erreurs de validation :</p>
                <ul className="text-sm text-destructive space-y-1">
                  {errors.map((error, i) => (
                    <li key={i}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="type">Type *</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, type: value as 'capacité' | 'magie' }))}
                  disabled={!!item} // Cannot change type when editing
                >
                  <SelectTrigger id="type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="capacité">Capacité</SelectItem>
                    <SelectItem value="magie">Magie</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Nom *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Nom de l'élément"
                />
              </div>
            </div>

            {formData.type === 'magie' && (
              <div className="space-y-2">
                <Label htmlFor="school">École de magie *</Label>
                <Input
                  id="school"
                  value={formData.school || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, school: e.target.value }))}
                  placeholder="Ex: Pyromagie, Aquamancie..."
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Description détaillée de l'élément"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="effects">Effets</Label>
              <Textarea
                id="effects"
                value={formData.effects || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, effects: e.target.value }))}
                placeholder="Effets mécaniques détaillés"
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="activationType">Type d'activation</Label>
                <Select
                  value={formData.activationType || 'action'}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, activationType: value as any }))}
                >
                  <SelectTrigger id="activationType">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="action">Action</SelectItem>
                    <SelectItem value="bonus">Bonus</SelectItem>
                    <SelectItem value="reaction">Réaction</SelectItem>
                    <SelectItem value="free">Gratuite</SelectItem>
                    {formData.type === 'magie' && <SelectItem value="ritual">Rituel</SelectItem>}
                    {formData.type === 'capacité' && <SelectItem value="rest">Repos</SelectItem>}
                  </SelectContent>
                </Select>
              </div>

              {formData.type === 'capacité' && (
                <div className="space-y-2">
                  <Label htmlFor="frequency">Fréquence</Label>
                  <Select
                    value={formData.frequency || 'unlimited'}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, frequency: value as any }))}
                  >
                    <SelectTrigger id="frequency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unlimited">Illimité</SelectItem>
                      <SelectItem value="once-per-turn">1/tour</SelectItem>
                      <SelectItem value="once-per-day">1/jour</SelectItem>
                      <SelectItem value="charges">Charges</SelectItem>
                      <SelectItem value="cooldown">Cooldown</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              {formData.type === 'magie' && (
                <div className="space-y-2">
                  <Label htmlFor="range">Portée</Label>
                  <Input
                    id="range"
                    value={formData.range || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, range: e.target.value }))}
                    placeholder="Ex: 10m, Contact, Vue"
                  />
                </div>
              )}
            </div>

            {formData.type === 'magie' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="duration">Durée</Label>
                  <Input
                    id="duration"
                    value={formData.duration || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, duration: e.target.value }))}
                    placeholder="Ex: Instantané, 1 heure, Concentration"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="scaling">Montée en puissance</Label>
                  <Input
                    id="scaling"
                    value={formData.scaling || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, scaling: e.target.value }))}
                    placeholder="Ex: +1d6/niveau"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="prerequisites">Prérequis</Label>
              <Input
                id="prerequisites"
                value={formData.prerequisites || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, prerequisites: e.target.value }))}
                placeholder="Conditions requises pour utiliser cet élément"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="folder">Dossier</Label>
              <Select
                value={formData.folderId || 'none'}
                onValueChange={(value) => setFormData(prev => ({ ...prev, folderId: value === 'none' ? undefined : value }))}
              >
                <SelectTrigger id="folder">
                  <SelectValue placeholder="Aucun dossier" />
                </SelectTrigger>
                <SelectContent className="z-[100]" position="popper" sideOffset={4}>
                  <SelectItem value="none">Aucun dossier</SelectItem>
                  {folders.map(folder => (
                    <SelectItem key={folder.id} value={folder.id}>{folder.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Tags</Label>
              <div className="flex gap-2">
                <Input
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addTag();
                    }
                  }}
                  placeholder="Ajouter un tag"
                />
                <Button type="button" variant="outline" size="sm" onClick={addTag}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              {formData.tags && formData.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-2">
                  {formData.tags.map(tag => (
                    <Badge key={tag} variant="outline" className="gap-1">
                      {tag}
                      <button
                        type="button"
                        onClick={() => removeTag(tag)}
                        className="ml-1 hover:text-destructive"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Coûts en ressources</Label>
              <SpellCostEditor
                costs={formData.costProfiles as any || []}
                onChange={updateCostProfiles}
              />
            </div>
          </div>
        </ScrollArea>

        <DialogFooter className="gap-2 px-6 py-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuler
          </Button>
          <Button variant="outline" onClick={() => handleSave(true)}>
            Enregistrer et ajouter à la fiche
          </Button>
          <Button onClick={() => handleSave(false)}>
            Enregistrer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
