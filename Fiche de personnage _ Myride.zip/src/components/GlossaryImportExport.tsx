import { useState } from "react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Alert, AlertDescription } from "./ui/alert";
import type { GlossaryItem, GlossaryFolder } from "../types/game";
import {
  Download,
  Upload,
  FileText,
  AlertCircle,
  Copy,
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { copyToClipboard } from "../utils/clipboardUtils";

interface GlossaryImportExportProps {
  items: GlossaryItem[];
  folders: GlossaryFolder[];
  onImport: (data: { items: GlossaryItem[]; folders: GlossaryFolder[] }) => void;
}

interface GlossaryExportData {
  items: GlossaryItem[];
  folders: GlossaryFolder[];
}

export function GlossaryImportExport({
  items,
  folders,
  onImport,
}: GlossaryImportExportProps) {
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importData, setImportData] = useState("");
  const [importError, setImportError] = useState("");

  const exportGlossary = (): string => {
    const payload: GlossaryExportData = {
      items,
      folders,
    };

    // JSON pretty-print avec 2 espaces
    return JSON.stringify(payload, null, 2);
  };

  const handleCopyToClipboard = async () => {
    const data = exportGlossary();
    try {
      await copyToClipboard(JSON.parse(data));
      toast.success("Glossaire copié dans le presse-papiers");
    } catch (error) {
      toast.error("Erreur lors de la copie");
    }
  };

  const handleDownloadFile = () => {
    const data = exportGlossary();
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `glossaire-${new Date().toISOString().split("T")[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Fichier téléchargé");
  };

  const handleImport = () => {
    setImportError("");

    try {
      const parsed = JSON.parse(importData);

      // Validate structure
      if (!parsed || typeof parsed !== "object") {
        throw new Error("Format invalide : l'objet JSON est requis");
      }

      const validItems: GlossaryItem[] = [];
      const validFolders: GlossaryFolder[] = [];

      // Import items
      if (parsed.items && Array.isArray(parsed.items)) {
        for (const item of parsed.items) {
          if (
            !item ||
            typeof item !== "object" ||
            typeof item.name !== "string" ||
            typeof item.type !== "string"
          ) {
            console.warn("Élément invalide ignoré:", item);
            continue;
          }

          // Ensure required fields
          validItems.push({
            ...item,
            id: item.id || crypto.randomUUID(),
            tags: Array.isArray(item.tags) ? item.tags : [],
            costProfiles: Array.isArray(item.costProfiles)
              ? item.costProfiles
              : [],
            description: item.description || "",
            createdAt: item.createdAt || new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            source: item.source || "user",
          });
        }
      }

      // Import folders
      if (parsed.folders && Array.isArray(parsed.folders)) {
        for (const folder of parsed.folders) {
          if (
            !folder ||
            typeof folder !== "object" ||
            typeof folder.name !== "string"
          ) {
            console.warn("Dossier invalide ignoré:", folder);
            continue;
          }

          validFolders.push({
            ...folder,
            id: folder.id || crypto.randomUUID(),
            order: folder.order || 0,
            createdAt: folder.createdAt || new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        }
      }

      if (validItems.length === 0 && validFolders.length === 0) {
        throw new Error(
          "Aucun élément ou dossier valide trouvé dans les données",
        );
      }

      onImport({ items: validItems, folders: validFolders });
      setShowImportDialog(false);
      setImportData("");
      
      const itemsMsg = validItems.length > 0 
        ? `${validItems.length} élément${validItems.length !== 1 ? "s" : ""}` 
        : "";
      const foldersMsg = validFolders.length > 0 
        ? `${validFolders.length} dossier${validFolders.length !== 1 ? "s" : ""}` 
        : "";
      const separator = itemsMsg && foldersMsg ? " et " : "";
      
      toast.success(`Importé ${itemsMsg}${separator}${foldersMsg}`);
    } catch (error) {
      const errorMsg =
        error instanceof Error
          ? error.message
          : "Erreur inconnue lors de l'import";
      setImportError(errorMsg);
    }
  };

  const getExampleData = (): string => {
    const example: GlossaryExportData = {
      folders: [
        {
          id: "folder-1",
          name: "Sorts de combat",
          order: 0,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ],
      items: [
        {
          id: "item-1",
          type: "magie",
          name: "Boule de feu",
          school: "Pyromagie",
          tags: ["Dégâts", "Zone"],
          folderId: "folder-1",
          description: "Lance une boule de feu explosive",
          costProfiles: [
            {
              context: "Standard",
              resources: [
                {
                  type: "PM",
                  amount: 3,
                },
              ],
            },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          source: "user",
          activationType: "action",
          range: "30m",
          duration: "Instantané",
          effects: "3d6 dégâts de feu",
        },
        {
          id: "item-2",
          type: "capacité",
          name: "Attaque puissante",
          tags: ["Combat", "Mêlée"],
          description: "Frappe avec force",
          costProfiles: [
            {
              context: "Standard",
              resources: [
                {
                  type: "PdE",
                  amount: 2,
                },
              ],
            },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          source: "user",
          activationType: "action",
          frequency: "unlimited",
          effects: "+2 aux dégâts",
        },
      ],
    };

    return JSON.stringify(example, null, 2);
  };

  const handleLoadExample = () => {
    setImportData(getExampleData());
    setImportError("");
  };

  const handleCopyExample = async () => {
    const example = getExampleData();
    try {
      await copyToClipboard(JSON.parse(example));
      toast.success("Exemple copié dans le presse-papiers");
    } catch (error) {
      toast.error("Erreur lors de la copie de l'exemple");
    }
  };

  return (
    <>
      <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
        <DialogContent className="max-w-2xl" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>Exporter le glossaire</DialogTitle>
            <DialogDescription>
              Exportez tous les éléments et dossiers du glossaire au format
              JSON
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="export-data">Données d'export (JSON)</Label>
              <Textarea
                id="export-data"
                value={exportGlossary()}
                readOnly
                rows={12}
                className="font-mono text-sm"
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCopyToClipboard} className="flex-1">
                <FileText className="w-4 h-4 mr-2" />
                Copier dans le presse-papiers
              </Button>
              <Button
                onClick={handleDownloadFile}
                variant="outline"
                className="flex-1"
              >
                <Download className="w-4 h-4 mr-2" />
                Télécharger en tant que fichier
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="max-w-2xl" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>Importer dans le glossaire</DialogTitle>
            <DialogDescription>
              Importez des éléments et dossiers au format JSON. Les éléments
              seront ajoutés au glossaire existant.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="import-data">Données JSON à importer</Label>
              <Textarea
                id="import-data"
                value={importData}
                onChange={(e) => {
                  setImportData(e.target.value);
                  setImportError("");
                }}
                placeholder='Collez ici les données JSON exportées...'
                rows={8}
                className="font-mono text-sm"
              />
            </div>

            {importError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <div>{importError}</div>
                    <div className="text-sm">
                      Format attendu: {`{ "items": [...], "folders": [...] }`}
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-2">
              <Button onClick={handleImport} disabled={!importData.trim()}>
                <Upload className="w-4 h-4 mr-2" />
                Importer
              </Button>
              <Button variant="outline" onClick={handleLoadExample}>
                <FileText className="w-4 h-4 mr-2" />
                Charger un exemple
              </Button>
              <Button
                variant="outline"
                onClick={handleCopyExample}
                title="Copie un exemple de format dans le presse-papiers"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copier l'exemple
              </Button>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                L'import ajoutera les nouveaux éléments et dossiers au glossaire
                existant. Les doublons (même nom et type) seront ignorés.
              </AlertDescription>
            </Alert>
          </div>
        </DialogContent>
      </Dialog>

      <Button
        size="sm"
        variant="outline"
        onClick={() => setShowExportDialog(true)}
      >
        <Download className="w-4 h-4 mr-2" />
        Export
      </Button>

      <Button
        size="sm"
        variant="outline"
        onClick={() => setShowImportDialog(true)}
      >
        <Upload className="w-4 h-4 mr-2" />
        Import
      </Button>
    </>
  );
}
