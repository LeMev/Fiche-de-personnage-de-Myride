import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { InventoryManager } from './InventoryManager';
import { MagicSchoolManager } from './MagicSchoolManager';
import { AbilityManager } from './AbilityManager';
import { TotalArmorManager } from './TotalArmorManager';
import { CharacteristicsSkillsManager } from './CharacteristicsSkillsManager';
import { useCharacters } from '../hooks/useApi';
import { 
  createDefaultAttributes, 
  createDefaultSkills, 
  createDefaultSkillMastery 
} from '../utils/characterUtils';
import type { Character } from '../types/game';
import { ArrowLeft, User, Zap, Scroll, Swords, Backpack, BookOpen, Edit, Save, X } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface CharacterSheetProps {
  character: Character;
  onBack: () => void;
}

export function CharacterSheet({ character, onBack }: CharacterSheetProps) {
  const { updateCharacter } = useCharacters(character.campaignId);
  const [editMode, setEditMode] = useState(false);
  const [editedCharacter, setEditedCharacter] = useState<Character>(() => {
    // Migrate old attribute system to new system if needed
    const migratedAttributes = character.attributes && 
      ('corps' in character.attributes) ? 
      character.attributes : 
      createDefaultAttributes();

    return {
      ...character,
      // Migrate attributes to new system
      attributes: migratedAttributes,
      // Initialize skills if not present
      skills: character.skills || createDefaultSkills(),
      // Initialize skill mastery if not present
      skillMastery: character.skillMastery || createDefaultSkillMastery(),
      // Initialize progression if not present
      progression: character.progression || { availableSkillPoints: 0 },
      resources: {
        hp: character.resources?.hp || { current: 100, max: 100 },
        mp: character.resources?.mp || { current: 50, max: 50 },
        totalArmor: character.resources?.totalArmor || 0,
        armorAutocalcEnabled: character.resources?.armorAutocalcEnabled ?? true,
        armorManualValue: character.resources?.armorManualValue || 0,
        custom: character.resources?.custom || [],
      },
      abilities: character.abilities?.map(ability => ({
        ...ability,
        hasCharges: ability.hasCharges || false,
        currentCharges: ability.currentCharges || 0,
        rechargesOnLongRest: ability.rechargesOnLongRest || false,
      })) || [],
      inventory: {
        ...character.inventory,
        items: character.inventory?.items?.map(item => ({
          ...item,
          hasCharges: item.hasCharges || false,
          currentCharges: item.currentCharges || 0,
          rechargesOnLongRest: item.rechargesOnLongRest || false,
          armorBonus: item.armorBonus || 0,
        })) || [],
      },
    };
  });

  const handleSave = async () => {
    try {
      await updateCharacter(editedCharacter);
      setEditMode(false);
      toast.success('Personnage sauvegardé avec succès');
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde');
      console.error('Save character error:', error);
    }
  };

  const handleCancel = () => {
    setEditedCharacter(character);
    setEditMode(false);
  };

  const handleInventoryUpdate = async (updatedCharacter: Character) => {
    try {
      await updateCharacter(updatedCharacter);
      setEditedCharacter(updatedCharacter);
    } catch (error) {
      toast.error('Erreur lors de la mise à jour de l\'inventaire');
      console.error('Update inventory error:', error);
    }
  };

  const updateField = (field: string, value: any) => {
    setEditedCharacter(prev => {
      const keys = field.split('.');
      const updated = { ...prev };
      let current: any = updated;
      
      for (let i = 0; i < keys.length - 1; i++) {
        current[keys[i]] = { ...current[keys[i]] };
        current = current[keys[i]];
      }
      
      current[keys[keys.length - 1]] = value;
      return updated;
    });
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour
          </Button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">{character.name}</h1>
              <Badge variant={character.role === 'GM' ? 'default' : 'secondary'}>
                {character.role}
              </Badge>
            </div>
            <p className="text-muted-foreground">
              {character.race} {character.class && `• ${character.class}`} • Niveau {character.level}
            </p>
          </div>
        </div>
        
        <div className="flex gap-2">
          {editMode ? (
            <>
              <Button variant="outline" onClick={handleCancel}>
                <X className="w-4 h-4 mr-2" />
                Annuler
              </Button>
              <Button onClick={handleSave}>
                <Save className="w-4 h-4 mr-2" />
                Sauvegarder
              </Button>
            </>
          ) : (
            <Button onClick={() => setEditMode(true)}>
              <Edit className="w-4 h-4 mr-2" />
              Modifier
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="inventory" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="inventory">
            <Backpack className="w-4 h-4 mr-2" />
            Inventaire
          </TabsTrigger>
          <TabsTrigger value="identity">
            <User className="w-4 h-4 mr-2" />
            Identité
          </TabsTrigger>
          <TabsTrigger value="attributes">
            <Zap className="w-4 h-4 mr-2" />
            Caractéristiques
          </TabsTrigger>
          <TabsTrigger value="magic">
            <Scroll className="w-4 h-4 mr-2" />
            Magie
          </TabsTrigger>
          <TabsTrigger value="abilities">
            <Swords className="w-4 h-4 mr-2" />
            Capacités
          </TabsTrigger>
          <TabsTrigger value="background">
            <BookOpen className="w-4 h-4 mr-2" />
            Histoire
          </TabsTrigger>
        </TabsList>

        <TabsContent value="inventory" className="mt-6">
          <InventoryManager 
            character={editedCharacter} 
            onUpdateCharacter={handleInventoryUpdate}
          />
        </TabsContent>

        <TabsContent value="identity" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Identité</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nom principal</Label>
                  {editMode ? (
                    <Input
                      id="name"
                      value={editedCharacter.name}
                      onChange={(e) => updateField('name', e.target.value)}
                    />
                  ) : (
                    <p className="p-2 bg-muted rounded">{character.name}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="aliases">Alias (séparés par des virgules)</Label>
                  {editMode ? (
                    <Input
                      id="aliases"
                      value={editedCharacter.aliases.join(', ')}
                      onChange={(e) => updateField('aliases', e.target.value.split(',').map(s => s.trim()).filter(s => s))}
                      placeholder="Alias 1, Alias 2..."
                    />
                  ) : (
                    <p className="p-2 bg-muted rounded">{character.aliases.join(', ') || 'Aucun'}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="race">Race</Label>
                  {editMode ? (
                    <Input
                      id="race"
                      value={editedCharacter.race}
                      onChange={(e) => updateField('race', e.target.value)}
                    />
                  ) : (
                    <p className="p-2 bg-muted rounded">{character.race}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="class">Classe/Spécialisation</Label>
                  {editMode ? (
                    <Input
                      id="class"
                      value={editedCharacter.class}
                      onChange={(e) => updateField('class', e.target.value)}
                    />
                  ) : (
                    <p className="p-2 bg-muted rounded">{character.class}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="level">Niveau</Label>
                  {editMode ? (
                    <Input
                      id="level"
                      type="number"
                      min="1"
                      value={editedCharacter.level}
                      onChange={(e) => updateField('level', parseInt(e.target.value) || 1)}
                    />
                  ) : (
                    <p className="p-2 bg-muted rounded">{character.level}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="age">Âge</Label>
                  {editMode ? (
                    <Input
                      id="age"
                      type="number"
                      min="1"
                      value={editedCharacter.age}
                      onChange={(e) => updateField('age', parseInt(e.target.value) || 20)}
                    />
                  ) : (
                    <p className="p-2 bg-muted rounded">{character.age}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="alignment">Alignement</Label>
                  {editMode ? (
                    <Input
                      id="alignment"
                      value={editedCharacter.alignment}
                      onChange={(e) => updateField('alignment', e.target.value)}
                    />
                  ) : (
                    <p className="p-2 bg-muted rounded">{character.alignment}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="combatStance">Posture de combat</Label>
                  {editMode ? (
                    <Input
                      id="combatStance"
                      value={editedCharacter.combatStance}
                      onChange={(e) => updateField('combatStance', e.target.value)}
                    />
                  ) : (
                    <p className="p-2 bg-muted rounded">{character.combatStance}</p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="appearance">Apparence</Label>
                {editMode ? (
                  <Textarea
                    id="appearance"
                    value={editedCharacter.appearance || ''}
                    onChange={(e) => updateField('appearance', e.target.value)}
                    placeholder="Description physique du personnage..."
                    rows={3}
                  />
                ) : (
                  <p className="p-2 bg-muted rounded min-h-[80px]">{character.appearance || 'Non renseigné'}</p>
                )}
              </div>

              <div>
                <Label htmlFor="distinctiveSign">Signe distinctif</Label>
                {editMode ? (
                  <Textarea
                    id="distinctiveSign"
                    value={editedCharacter.distinctiveSign || ''}
                    onChange={(e) => updateField('distinctiveSign', e.target.value)}
                    placeholder="Cicatrices, tatouages, bijoux particuliers..."
                    rows={2}
                  />
                ) : (
                  <p className="p-2 bg-muted rounded min-h-[60px]">{character.distinctiveSign || 'Non renseigné'}</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attributes" className="mt-6">
          <CharacteristicsSkillsManager
            character={editedCharacter}
            onUpdateCharacter={(updatedCharacter) => {
              setEditedCharacter(updatedCharacter);
              if (!editMode) {
                handleInventoryUpdate(updatedCharacter);
              }
            }}
          />
          
          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Ressources</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <Label>Points de Vie (PV)</Label>
                    <div className="flex gap-2 items-center">
                      {editMode ? (
                        <>
                          <Input
                            type="number"
                            min="0"
                            value={editedCharacter.resources.hp.current}
                            onChange={(e) => updateField('resources.hp.current', parseInt(e.target.value) || 0)}
                            className="text-center"
                          />
                          <span>/</span>
                          <Input
                            type="number"
                            min="1"
                            value={editedCharacter.resources.hp.max}
                            onChange={(e) => updateField('resources.hp.max', parseInt(e.target.value) || 1)}
                            className="text-center"
                          />
                        </>
                      ) : (
                        <p className="p-2 bg-muted rounded text-center w-full">
                          {character.resources.hp.current} / {character.resources.hp.max}
                        </p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label>Points de Mana (PM)</Label>
                    <div className="flex gap-2 items-center">
                      {editMode ? (
                        <>
                          <Input
                            type="number"
                            min="0"
                            value={editedCharacter.resources.mp.current}
                            onChange={(e) => updateField('resources.mp.current', parseInt(e.target.value) || 0)}
                            className="text-center"
                          />
                          <span>/</span>
                          <Input
                            type="number"
                            min="1"
                            value={editedCharacter.resources.mp.max}
                            onChange={(e) => updateField('resources.mp.max', parseInt(e.target.value) || 1)}
                            className="text-center"
                          />
                        </>
                      ) : (
                        <p className="p-2 bg-muted rounded text-center w-full">
                          {character.resources.mp.current} / {character.resources.mp.max}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Total Armor Section */}
                <TotalArmorManager
                  character={editedCharacter}
                  editMode={editMode}
                  onUpdateCharacter={(updatedCharacter) => {
                    setEditedCharacter(updatedCharacter);
                    if (!editMode) {
                      handleInventoryUpdate(updatedCharacter);
                    }
                  }}
                />

                {character.resources.custom.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <Label>Ressources personnalisées</Label>
                      <div className="space-y-2 mt-2">
                        {character.resources.custom.map((resource) => (
                          <div key={resource.id} className="flex items-center gap-2">
                            <span className="font-medium">{resource.label}:</span>
                            <span>{resource.current} / {resource.max}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="magic" className="mt-6">
          <MagicSchoolManager 
            character={editedCharacter}
            editMode={editMode}
            onUpdateCharacter={(updatedCharacter) => {
              setEditedCharacter(updatedCharacter);
              if (!editMode) {
                handleInventoryUpdate(updatedCharacter);
              }
            }}
          />
        </TabsContent>

        <TabsContent value="abilities" className="mt-6">
          <AbilityManager
            character={editedCharacter}
            editMode={editMode}
            onUpdateCharacter={(updatedCharacter) => {
              setEditedCharacter(updatedCharacter);
              if (!editMode) {
                handleInventoryUpdate(updatedCharacter);
              }
            }}
          />
        </TabsContent>

        <TabsContent value="background" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Histoire et Background</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="origin">Origine/Lieu de naissance</Label>
                {editMode ? (
                  <Textarea
                    id="origin"
                    value={editedCharacter.background.origin}
                    onChange={(e) => updateField('background.origin', e.target.value)}
                    placeholder="Ville, région, monde..."
                    rows={2}
                  />
                ) : (
                  <p className="p-2 bg-muted rounded min-h-[60px]">{character.background.origin || 'Non renseigné'}</p>
                )}
              </div>

              <div>
                <Label htmlFor="family">Histoire familiale</Label>
                {editMode ? (
                  <Textarea
                    id="family"
                    value={editedCharacter.background.family}
                    onChange={(e) => updateField('background.family', e.target.value)}
                    placeholder="Parents, fratrie, événements familiaux..."
                    rows={3}
                  />
                ) : (
                  <p className="p-2 bg-muted rounded min-h-[80px]">{character.background.family || 'Non renseigné'}</p>
                )}
              </div>

              <div>
                <Label htmlFor="personality">Personnalité</Label>
                {editMode ? (
                  <Textarea
                    id="personality"
                    value={editedCharacter.background.personality}
                    onChange={(e) => updateField('background.personality', e.target.value)}
                    placeholder="Traits de caractère, habitudes, peurs..."
                    rows={3}
                  />
                ) : (
                  <p className="p-2 bg-muted rounded min-h-[80px]">{character.background.personality || 'Non renseigné'}</p>
                )}
              </div>

              <div>
                <Label htmlFor="objectives">Objectifs/Quête personnelle</Label>
                {editMode ? (
                  <Textarea
                    id="objectives"
                    value={editedCharacter.background.objectives}
                    onChange={(e) => updateField('background.objectives', e.target.value)}
                    placeholder="Buts, motivations, quête personnelle..."
                    rows={3}
                  />
                ) : (
                  <p className="p-2 bg-muted rounded min-h-[80px]">{character.background.objectives || 'Non renseigné'}</p>
                )}
              </div>

              <div>
                <Label htmlFor="languages">Langues parlées</Label>
                {editMode ? (
                  <Input
                    id="languages"
                    value={editedCharacter.background.languages.join(', ')}
                    onChange={(e) => updateField('background.languages', e.target.value.split(',').map(s => s.trim()).filter(s => s))}
                    placeholder="Commun, Elfique, Draconique..."
                  />
                ) : (
                  <p className="p-2 bg-muted rounded">{character.background.languages.join(', ') || 'Aucune'}</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}