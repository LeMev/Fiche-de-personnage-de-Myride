import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { useCampaigns } from '../hooks/useApi';
import type { Campaign } from '../types/game';
import { Plus, Trash2, Users } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface CampaignManagerProps {
  onSelectCampaign: (campaign: Campaign) => void;
}

export function CampaignManager({ onSelectCampaign }: CampaignManagerProps) {
  const { campaigns, loading, error, createCampaign, deleteCampaign } = useCampaigns();
  const [newCampaignOpen, setNewCampaignOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', description: '' });

  const handleCreateCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast.error('Le nom de la campagne est requis');
      return;
    }

    try {
      await createCampaign(formData.name.trim(), formData.description.trim() || undefined);
      setFormData({ name: '', description: '' });
      setNewCampaignOpen(false);
      toast.success('Campagne créée avec succès');
    } catch (error) {
      toast.error('Erreur lors de la création de la campagne');
      console.error('Create campaign error:', error);
    }
  };

  const handleDeleteCampaign = async (campaign: Campaign) => {
    try {
      await deleteCampaign(campaign.id);
      toast.success('Campagne supprimée avec succès');
    } catch (error) {
      toast.error('Erreur lors de la suppression de la campagne');
      console.error('Delete campaign error:', error);
    }
  };

  if (loading) {
    return (
      <div className="p-8 text-center">
        <p>Chargement des campagnes...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 text-center">
        <p className="text-destructive">Erreur : {error}</p>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Gestionnaire de Campagnes Myride</h1>
          <p className="text-muted-foreground">
            Gérez vos campagnes et personnages RPG
          </p>
        </div>
        
        <Dialog open={newCampaignOpen} onOpenChange={setNewCampaignOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Nouvelle Campagne
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Créer une nouvelle campagne</DialogTitle>
              <DialogDescription>
                Créez une nouvelle campagne pour organiser vos personnages RPG Myride.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateCampaign} className="space-y-4">
              <div>
                <Label htmlFor="name">Nom de la campagne *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Ex: Les Chroniques de l'Ombre"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="description">Description (optionnel)</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Description de la campagne..."
                  rows={3}
                />
              </div>
              
              <div className="flex justify-end gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setNewCampaignOpen(false)}
                >
                  Annuler
                </Button>
                <Button type="submit">Créer</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {campaigns.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center">
            <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3>Aucune campagne</h3>
            <p className="text-muted-foreground mb-4">
              Créez votre première campagne pour commencer
            </p>
            <Button onClick={() => setNewCampaignOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Créer une campagne
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {campaigns.map((campaign) => (
            <Card key={campaign.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1" onClick={() => onSelectCampaign(campaign)}>
                    <CardTitle className="text-lg">{campaign.name}</CardTitle>
                    {campaign.description && (
                      <CardDescription className="mt-2">
                        {campaign.description}
                      </CardDescription>
                    )}
                  </div>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Supprimer la campagne</AlertDialogTitle>
                        <AlertDialogDescription>
                          Êtes-vous sûr de vouloir supprimer la campagne "{campaign.name}" ? 
                          Cette action supprimera également tous les personnages associés et ne peut pas être annulée.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Annuler</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={() => handleDeleteCampaign(campaign)}
                        >
                          Supprimer
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardHeader>
              
              <CardContent onClick={() => onSelectCampaign(campaign)}>
                <p className="text-sm text-muted-foreground">
                  Créée le {new Date(campaign.createdAt).toLocaleDateString('fr-FR')}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}