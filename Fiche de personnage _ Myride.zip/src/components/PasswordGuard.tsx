import { useState, useEffect } from 'react';
import { Lock, X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import type { Character } from '../types/game';

interface PasswordGuardProps {
  character: Character | null;
  open: boolean;
  onSuccess: () => void;
  onCancel: () => void;
}

export const PasswordGuard = ({ character, open, onSuccess, onCancel }: PasswordGuardProps) => {
  const [enteredCode, setEnteredCode] = useState(['', '', '', '']);
  const [error, setError] = useState('');
  const [currentInput, setCurrentInput] = useState(0);

  // Reset state when dialog opens/closes
  useEffect(() => {
    if (open) {
      setEnteredCode(['', '', '', '']);
      setError('');
      setCurrentInput(0);
      // Auto-focus first input when dialog opens
      setTimeout(() => {
        const firstInput = document.getElementById('pin-0');
        firstInput?.focus();
      }, 100);
    }
  }, [open]);

  const handleInputChange = (index: number, value: string) => {
    // Only allow single digits
    const digit = value.replace(/\D/g, '').slice(-1);
    
    const newCode = [...enteredCode];
    newCode[index] = digit;
    setEnteredCode(newCode);
    setError('');

    // Auto-focus next input if digit was entered
    if (digit && index < 3) {
      setCurrentInput(index + 1);
      const nextInput = document.getElementById(`pin-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !enteredCode[index] && index > 0) {
      // If current input is empty and backspace is pressed, focus previous input
      setCurrentInput(index - 1);
      const prevInput = document.getElementById(`pin-${index - 1}`);
      prevInput?.focus();
    } else if (e.key === 'Enter') {
      handleValidate();
    }
  };

  const handleValidate = () => {
    const code = enteredCode.join('');
    
    if (code.length !== 4) {
      setError('Veuillez entrer les 4 chiffres');
      return;
    }

    if (!character?.lock?.code || code !== character.lock.code) {
      setError('Code incorrect');
      setEnteredCode(['', '', '', '']);
      setCurrentInput(0);
      // Focus first input after error
      setTimeout(() => {
        const firstInput = document.getElementById('pin-0');
        firstInput?.focus();
      }, 100);
      return;
    }

    // Success - code is correct
    onSuccess();
  };

  const handleCancel = () => {
    setEnteredCode(['', '', '', '']);
    setError('');
    setCurrentInput(0);
    onCancel();
  };

  if (!character?.lock?.enabled) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent 
        className="max-w-sm" 
        aria-describedby={undefined}
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5" />
            Code requis
          </DialogTitle>
          <DialogDescription>
            Cette fiche est protégée. Entrez le code à 4 chiffres pour y accéder.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label>Code PIN</Label>
            <div className="flex gap-2 mt-2">
              {enteredCode.map((digit, index) => (
                <Input
                  key={index}
                  id={`pin-${index}`}
                  type="password"
                  inputMode="numeric"
                  value={digit}
                  onChange={(e) => handleInputChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  onFocus={() => setCurrentInput(index)}
                  maxLength={1}
                  className="w-12 h-12 text-center text-lg tracking-wider"
                  autoFocus={index === 0}
                />
              ))}
            </div>
            {error && (
              <p className="text-sm text-destructive mt-2">{error}</p>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button variant="outline" onClick={handleCancel}>
            <X className="w-4 h-4 mr-2" />
            Annuler
          </Button>
          <Button 
            onClick={handleValidate}
            disabled={enteredCode.some(digit => !digit)}
          >
            Valider
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};