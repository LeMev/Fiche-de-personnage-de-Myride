import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from './ui/alert-dialog';
import { useState } from 'react';
import type { Character, Campaign } from '../types/game';
import { Cat, Plus } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface CreateMiaCharacterProps {
  campaign: Campaign;
  onCreateCharacter: (character: Character) => void;
}

export function CreateMiaCharacter({ campaign, onCreateCharacter }: CreateMiaCharacterProps) {
  const [showDialog, setShowDialog] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const createMiaCharacter = (): Character => {
    const now = new Date().toISOString();
    
    return {
      id: Math.random().toString(36).substr(2, 9),
      campaignId: campaign.id,
      role: 'PC',
      
      // Identity
      name: 'Mia',
      aliases: ['La rôdeuse runique', 'Chat des ombres'],
      race: 'Bestiale (Chat)',
      class: 'Rôdeuse runique',
      level: 5,
      age: 22,
      alignment: 'Chaotique Neutre',
      combatStance: 'Furtive',
      appearance: 'Silhouette féline, traits de chat discrets, oreilles pointues, yeux verts perçants',
      distinctiveSign: 'Griffes rétractiles et queue de chat',
      
      // Attributes (optimisés pour rôdeuse runique)
      attributes: {
        corps: 12,
        vitalité: 14,
        esprit: 15,
        habilité: 18,
        sociale: 10,
        pouvoir: 16
      },
      
      // Skills (focus distance, discrétion, runique)
      skills: {
        corps: { mouvement: 12, mêlée: 11, puissance: 10 },
        vitalité: { endurance: 14, résistance: 13, récupération: 15 },
        esprit: { perception: 17, analyse: 14, volonté: 13 },
        habilité: { distance: 20, discrétion: 19, talent: 16 },
        sociale: { persuasion: 9, intimidation: 8, représentation: 12 },
        pouvoir: { incantation: 15, canalisation: 17, rituel: 16 }
      },
      
      // Skill mastery (quelques maîtrises)
      skillMastery: {
        distance: { tier: 10, rerollsUsed: 0, rerollsAvailable: 1 },
        discrétion: { tier: 5, rerollsUsed: 0, rerollsAvailable: 0 },
        canalisation: { tier: 5, rerollsUsed: 0, rerollsAvailable: 0 },
        perception: { tier: 5, rerollsUsed: 0, rerollsAvailable: 0 }
      },
      
      // Progression
      progression: {
        availableSkillPoints: 3
      },
      
      // Resources
      resources: {
        hp: { current: 85, max: 85 },
        mp: { current: 42, max: 42 },
        totalArmor: 8,
        armorAutocalcEnabled: false,
        armorManualValue: 8,
        custom: [
          { id: 'luck', label: 'Chance', current: 3, max: 3 },
          { id: 'inspiration', label: 'Inspiration', current: 2, max: 2 }
        ]
      },
      
      // Magic (empty initially - will be added via MiaDataSetup)
      magic: {
        schools: [],
        expandedSchools: []
      },
      
      // Abilities (empty initially - will be added via MiaDataSetup)
      abilities: [],
      abilityFolders: [
        {
          id: 'combat-folder',
          name: 'Combat',
          type: 'ability',
          expanded: true,
          color: '#ef4444',
          icon: 'sword'
        },
        {
          id: 'stealth-folder', 
          name: 'Discrétion',
          type: 'ability',
          expanded: true,
          color: '#6366f1',
          icon: 'eye-off'
        },
        {
          id: 'runic-folder',
          name: 'Runique',
          type: 'ability', 
          expanded: true,
          color: '#8b5cf6',
          icon: 'scroll'
        }
      ],
      
      // Background
      background: {
        origin: 'Ville portuaire, quartier des voleurs',
        family: 'Orpheline élevée par une guilde de voleurs, a découvert ses origines bestialisées adolescente',
        personality: 'Curieuse et indépendante, méfie des autorités, loyale envers ses proches. Adore grimper et observer.',
        objectives: 'Maîtriser parfaitement la magie runique, découvrir l\'origine de sa lignée bestiale',
        languages: ['Commun', 'Argot des voleurs', 'Dialecte bestial', 'Ancien runique']
      },
      
      // Inventory (équipement de base)
      inventory: {
        items: [
          {
            id: 'crossbow-main',
            name: 'Arbalète de précision',
            quantity: 1,
            weight: 3.5,
            weightUnit: 'kg',
            category: 'weapon',
            damage: '1d8+3',
            rarity: 'uncommon',
            notes: 'Arbalète spécialement modifiée pour Mia, bonus +2 précision',
            equipped: true,
            identified: true,
            tags: ['Distance', 'Précision'],
            armorBonus: 0
          },
          {
            id: 'runic-gauntlet',
            name: 'Gantelet runique évolué',
            quantity: 1,
            weight: 0.5,
            weightUnit: 'kg',
            category: 'misc',
            rarity: 'rare',
            notes: 'Gantelet permettant de graver et canaliser les runes, accepte les pierres de mana',
            equipped: true,
            identified: true,
            tags: ['Runique', 'Artisanat'],
            hasCharges: true,
            currentCharges: 3,
            maxCharges: 3,
            rechargesOnLongRest: true
          },
          {
            id: 'leather-armor',
            name: 'Armure de cuir renforcé',
            quantity: 1,
            weight: 5,
            weightUnit: 'kg',
            category: 'armor',
            rarity: 'common',
            notes: 'Armure légère, modifiée pour ne pas gêner les mouvements félins',
            equipped: true,
            identified: true,
            tags: ['Armure légère'],
            armorBonus: 5
          },
          {
            id: 'runic-papers',
            name: 'Papiers runiques (pile)',
            quantity: 20,
            weight: 0.1,
            weightUnit: 'kg',
            category: 'consumable',
            rarity: 'common',
            notes: 'Papiers spéciaux pour tracer des runes temporaires',
            equipped: false,
            identified: true,
            tags: ['Runique', 'Consommable']
          },
          {
            id: 'crossbow-bolts',
            name: 'Carreaux d\'arbalète',
            quantity: 50,
            weight: 2,
            weightUnit: 'kg',
            category: 'consumable',
            rarity: 'common',
            notes: 'Carreaux standards, peuvent être imprégnés de runes',
            equipped: false,
            identified: true,
            tags: ['Munitions', 'Distance']
          }
        ],
        folders: [
          {
            id: 'weapons-folder',
            name: 'Armes',
            type: 'inventory',
            expanded: true,
            color: '#dc2626'
          },
          {
            id: 'runic-supplies',
            name: 'Matériel runique',
            type: 'inventory',
            expanded: true,
            color: '#7c3aed'
          }
        ],
        currency: {
          bronze: 45,
          silver: 12,
          gold: 8
        },
        totalWeight: 11.6,
        encumbranceThreshold: {
          light: 15,
          medium: 25,
          heavy: 35
        }
      },
      
      // Focus system
      focus: {
        active: false
      },
      
      createdAt: now,
      updatedAt: now
    };
  };

  const handleCreateMia = () => {
    const miaCharacter = createMiaCharacter();
    onCreateCharacter(miaCharacter);
    setShowDialog(false);
    setShowConfirm(false);
    toast.success('Mia créée !', {
      description: 'Personnage Mia créé avec équipement de base. Utilisez le bouton "Données Mia" en mode édition pour ajouter ses capacités et magies.'
    });
  };

  return (
    <>
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogTrigger asChild>
          <Button variant="outline" className="gap-2">
            <Cat className="w-4 h-4" />
            Créer Mia
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Cat className="w-5 h-5" />
              Créer le personnage Mia
            </DialogTitle>
            <DialogDescription>
              Cela créera automatiquement Mia avec ses caractéristiques de base, son équipement et son background.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Caractéristiques de Mia :</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• <strong>Race :</strong> Bestiale (Chat)</li>
                <li>• <strong>Classe :</strong> Rôdeuse runique</li>
                <li>• <strong>Niveau :</strong> 5</li>
                <li>• <strong>Focus :</strong> Distance, Discrétion, Magie runique</li>
                <li>• <strong>Équipement :</strong> Arbalète, Gantelet runique, Armure cuir</li>
              </ul>
            </div>
            
            <div className="bg-orange-50 dark:bg-orange-950/20 p-3 rounded-lg">
              <p className="text-sm text-orange-800 dark:text-orange-200">
                ⚠️ <strong>Après création :</strong> Passez en mode édition et utilisez le bouton "Données Mia" dans les onglets Capacités et Magie pour ajouter ses capacités spéciales et sorts.
              </p>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Annuler
            </Button>
            <Button onClick={() => setShowConfirm(true)}>
              Créer Mia
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la création</AlertDialogTitle>
            <AlertDialogDescription>
              Créer automatiquement le personnage Mia dans la campagne "{campaign.name}" ?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleCreateMia}>
              Créer Mia
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}