import { memo, useCallback } from 'react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Plus, Trash2 } from 'lucide-react';
import type { SpellCost } from '../types/game';

// Un élément "Coût" (contexte + liste de ressources)
const CostItem = memo(function CostItem({
  cost,
  onUpdate,
  onRemove,
}: {
  cost: SpellCost;
  onUpdate: (updated: SpellCost) => void;
  onRemove: (id: string) => void;
}) {
  const handleContextChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      onUpdate({ ...cost, context: e.target.value });
    },
    [cost, onUpdate]
  );

  const handleResourceTypeChange = useCallback(
    (idx: number, value: string) => {
      const resources = [...cost.resources];
      resources[idx] = { ...resources[idx], type: value };
      onUpdate({ ...cost, resources });
    },
    [cost, onUpdate]
  );

  const handleResourceAmountChange = useCallback(
    (idx: number, value: string) => {
      const amount = parseInt(value, 10);
      const resources = [...cost.resources];
      resources[idx] = { ...resources[idx], amount: isNaN(amount) ? 0 : amount };
      onUpdate({ ...cost, resources });
    },
    [cost, onUpdate]
  );

  const handleResourcePerUnitChange = useCallback(
    (idx: number, value: string) => {
      const resources = [...cost.resources];
      resources[idx] = { ...resources[idx], perUnit: value };
      onUpdate({ ...cost, resources });
    },
    [cost, onUpdate]
  );

  const handleRemoveResource = useCallback(
    (idx: number) => {
      const resources = cost.resources.filter((_, i) => i !== idx);
      onUpdate({ ...cost, resources });
    },
    [cost, onUpdate]
  );

  const handleAddResource = useCallback(() => {
    const resources = [...cost.resources, { id: crypto.randomUUID(), type: 'PM', amount: 1 }];
    onUpdate({ ...cost, resources });
  }, [cost, onUpdate]);

  return (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Input
            placeholder="Contexte (Combat, Hors combat...)"
            value={cost.context}
            onChange={handleContextChange}
            className="flex-1 mr-2"
          />
          <Button variant="ghost" size="sm" onClick={() => onRemove(cost.id)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>

        {cost.resources.map((resource, idx) => (
          <div key={`resource-${idx}`} className="flex items-center gap-2">
            <Input
              placeholder="Type (PM, PV...)"
              value={resource.type}
              onChange={(e) => handleResourceTypeChange(idx, e.target.value)}
              className="w-20"
            />
            <Input
              type="number"
              placeholder="Quantité"
              value={resource.amount}
              onChange={(e) => handleResourceAmountChange(idx, e.target.value)}
              className="w-24"
            />
            <Input
              placeholder="Par unité (optionnel)"
              value={resource.perUnit || ''}
              onChange={(e) => handleResourcePerUnitChange(idx, e.target.value)}
              className="flex-1"
            />
            <Button variant="ghost" size="sm" onClick={() => handleRemoveResource(idx)}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        ))}

        <Button variant="outline" size="sm" onClick={handleAddResource}>
          <Plus className="w-4 h-4 mr-2" />
          Ajouter une ressource
        </Button>
      </div>
    </Card>
  );
});

// L’éditeur de la liste des "Coûts"
function SpellCostEditorBase({
  costs,
  onChange,
}: {
  costs: SpellCost[];
  onChange: (costs: SpellCost[]) => void;
}) {
  const addCost = useCallback(() => {
    onChange([
      ...costs,
      {
        id: crypto.randomUUID(),
        context: 'Standard',
        resources: [{ type: 'PM', amount: 1 }],
      },
    ]);
  }, [costs, onChange]);

  const updateCost = useCallback(
    (id: string, updated: SpellCost) => {
      onChange(costs.map((c) => (c.id === id ? updated : c)));
    },
    [costs, onChange]
  );

  const removeCost = useCallback(
    (id: string) => {
      onChange(costs.filter((c) => c.id !== id));
    },
    [costs, onChange]
  );

  return (
    <div className="space-y-4">
      <Label>Coûts</Label>

      {costs.map((cost) => (
        <CostItem
          key={cost.id}
          cost={cost}
          onUpdate={(updated) => updateCost(cost.id, updated)}
          onRemove={removeCost}
        />
      ))}

      <Button variant="outline" onClick={addCost}>
        <Plus className="w-4 h-4 mr-2" />
        Ajouter un profil de coût
      </Button>
    </div>
  );
}

// Mémoïse pour éviter des rerenders inutiles
const SpellCostEditor = memo(SpellCostEditorBase);
export default SpellCostEditor;
