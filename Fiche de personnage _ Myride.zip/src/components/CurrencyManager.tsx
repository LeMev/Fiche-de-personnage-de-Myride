import { useState, useRef, useCallback } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu';
import { Plus, Minus, Settings, Coins } from 'lucide-react';
import type { Character, CurrencyAdjustment } from '../types/game';
import { toast } from 'sonner@2.0.3';

interface CurrencyManagerProps {
  character: Character;
  onUpdateCharacter: (character: Character) => void;
}

// Settings for currency adjustments
interface CurrencySettings {
  allowNegative: boolean;
  autoConvert: boolean;
  stepSizes: {
    normal: number;
    shift: number;
    ctrl: number;
  };
}

const DEFAULT_SETTINGS: CurrencySettings = {
  allowNegative: false,
  autoConvert: true,
  stepSizes: {
    normal: 1,
    shift: 5,
    ctrl: 10
  }
};

export function CurrencyManager({ character, onUpdateCharacter }: CurrencyManagerProps) {
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editType, setEditType] = useState<'bronze' | 'silver' | 'gold'>('bronze');
  const [editValue, setEditValue] = useState('');
  const [settings, setSettings] = useState<CurrencySettings>(() => {
    try {
      const saved = localStorage.getItem('currency_settings');
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Auto-repeat refs
  const repeatTimeoutRef = useRef<NodeJS.Timeout>();
  const repeatIntervalRef = useRef<NodeJS.Timeout>();

  const saveSettings = useCallback((newSettings: CurrencySettings) => {
    setSettings(newSettings);
    localStorage.setItem('currency_settings', JSON.stringify(newSettings));
  }, []);

  // Auto-conversion logic
  const applyAutoConversion = (currency: { bronze: number; silver: number; gold: number }) => {
    if (!settings.autoConvert) return currency;

    let { bronze, silver, gold } = currency;

    // Convert bronze to silver (10 bronze = 1 silver)
    if (bronze >= 10) {
      const newSilver = Math.floor(bronze / 10);
      silver += newSilver;
      bronze = bronze % 10;
    }

    // Convert silver to gold (10 silver = 1 gold)  
    if (silver >= 10) {
      const newGold = Math.floor(silver / 10);
      gold += newGold;
      silver = silver % 10;
    }

    return { bronze, silver, gold };
  };

  // Log currency change
  const logCurrencyChange = (
    type: 'bronze' | 'silver' | 'gold',
    delta: number,
    newValue: number,
    reason?: string
  ) => {
    const adjustment: CurrencyAdjustment = {
      type,
      amount: Math.abs(delta),
      operation: delta > 0 ? 'add' : 'subtract',
      timestamp: new Date().toISOString(),
      reason: reason || `Ajustement ${delta > 0 ? '+' : '-'}${Math.abs(delta)}`
    };

    // In a real app, this would be sent to the backend
    console.log('Currency adjustment logged:', adjustment);
  };

  // Instant currency adjustment
  const adjustCurrency = (
    type: 'bronze' | 'silver' | 'gold',
    delta: number,
    event?: React.MouseEvent
  ) => {
    const currentCurrency = character.inventory.currency;
    const currentValue = currentCurrency[type];
    let newValue = currentValue + delta;

    // Check for negative values
    if (!settings.allowNegative && newValue < 0) {
      newValue = 0;
      if (delta < 0) {
        toast.error('Montant invalide - valeur négative non autorisée');
        return;
      }
    }

    // Create new currency object
    const newCurrency = {
      ...currentCurrency,
      [type]: newValue
    };

    // Apply auto-conversion
    const convertedCurrency = applyAutoConversion(newCurrency);

    // Check if conversion occurred
    const conversionOccurred = 
      convertedCurrency.bronze !== newCurrency.bronze ||
      convertedCurrency.silver !== newCurrency.silver ||
      convertedCurrency.gold !== newCurrency.gold;

    // Update character
    const updatedCharacter = {
      ...character,
      inventory: {
        ...character.inventory,
        currency: convertedCurrency
      }
    };

    onUpdateCharacter(updatedCharacter);

    // Log the change
    logCurrencyChange(type, delta, newValue);

    // Show conversion toast if applicable
    if (conversionOccurred && settings.autoConvert) {
      const conversions = [];
      if (newCurrency.bronze !== convertedCurrency.bronze) {
        const convertedBronze = newCurrency.bronze - convertedCurrency.bronze;
        const silverGained = Math.floor(convertedBronze / 10);
        conversions.push(`${convertedBronze} Bronze → ${silverGained} Argent`);
      }
      if (newCurrency.silver !== convertedCurrency.silver && newCurrency.bronze === convertedCurrency.bronze) {
        const convertedSilver = newCurrency.silver - convertedCurrency.silver;
        const goldGained = Math.floor(convertedSilver / 10);
        if (goldGained > 0) {
          conversions.push(`${convertedSilver} Argent → ${goldGained} Or`);
        }
      }
      if (conversions.length > 0) {
        toast.success(`Conversion automatique: ${conversions.join(', ')}`);
      }
    }
  };

  // Get step size based on modifier keys
  const getStepSize = (event?: React.MouseEvent) => {
    if (!event) return settings.stepSizes.normal;
    
    if (event.shiftKey) return settings.stepSizes.shift;
    if (event.ctrlKey || event.metaKey) return settings.stepSizes.ctrl;
    return settings.stepSizes.normal;
  };

  // Handle button press (single click)
  const handleAdjustClick = (
    type: 'bronze' | 'silver' | 'gold',
    direction: 1 | -1,
    event: React.MouseEvent
  ) => {
    event.preventDefault();
    const stepSize = getStepSize(event);
    adjustCurrency(type, direction * stepSize, event);
  };

  // Handle button press start (for hold behavior)
  const handleAdjustStart = (
    type: 'bronze' | 'silver' | 'gold',
    direction: 1 | -1,
    event: React.MouseEvent
  ) => {
    // Clear any existing timeouts
    if (repeatTimeoutRef.current) clearTimeout(repeatTimeoutRef.current);
    if (repeatIntervalRef.current) clearInterval(repeatIntervalRef.current);

    const stepSize = getStepSize(event);

    // Initial adjustment
    adjustCurrency(type, direction * stepSize, event);

    // Start auto-repeat after 500ms
    repeatTimeoutRef.current = setTimeout(() => {
      repeatIntervalRef.current = setInterval(() => {
        adjustCurrency(type, direction * stepSize, event);
      }, 100); // ~10 per second
    }, 500);
  };

  // Handle button press end
  const handleAdjustEnd = () => {
    if (repeatTimeoutRef.current) clearTimeout(repeatTimeoutRef.current);
    if (repeatIntervalRef.current) clearInterval(repeatIntervalRef.current);
  };

  // Handle direct edit
  const handleDirectEdit = () => {
    const value = parseInt(editValue);
    if (isNaN(value)) {
      toast.error('Valeur invalide');
      return;
    }

    if (!settings.allowNegative && value < 0) {
      toast.error('Montant invalide - valeur négative non autorisée');
      return;
    }

    const currentValue = character.inventory.currency[editType];
    const delta = value - currentValue;

    const newCurrency = applyAutoConversion({
      ...character.inventory.currency,
      [editType]: value
    });

    const updatedCharacter = {
      ...character,
      inventory: {
        ...character.inventory,
        currency: newCurrency
      }
    };

    onUpdateCharacter(updatedCharacter);
    logCurrencyChange(editType, delta, value, 'Modification directe');
    
    setShowEditDialog(false);
    setEditValue('');
    toast.success(`${editType === 'gold' ? 'Or' : editType === 'silver' ? 'Argent' : 'Bronze'} mis à jour`);
  };

  const openEditDialog = (type: 'bronze' | 'silver' | 'gold') => {
    setEditType(type);
    setEditValue(character.inventory.currency[type].toString());
    setShowEditDialog(true);
  };

  const getTotalValue = () => {
    const { bronze, silver, gold } = character.inventory.currency;
    return gold * 100 + silver * 10 + bronze; // In bronze equivalent
  };

  const formatTotalValue = (totalBronze: number) => {
    const gold = Math.floor(totalBronze / 100);
    const silver = Math.floor((totalBronze % 100) / 10);
    const bronze = totalBronze % 10;
    
    const parts = [];
    if (gold > 0) parts.push(`${gold} Or`);
    if (silver > 0) parts.push(`${silver} Argent`);
    if (bronze > 0) parts.push(`${bronze} Bronze`);
    
    return parts.length > 0 ? parts.join(', ') : '0 Bronze';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Coins className="w-5 h-5" />
            Monnaie
          </CardTitle>
          
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">
              Total: {formatTotalValue(getTotalValue())}
            </Badge>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <div className="space-y-4 p-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="auto-convert"
                      checked={settings.autoConvert}
                      onCheckedChange={(checked) => 
                        saveSettings({ ...settings, autoConvert: checked })
                      }
                    />
                    <Label htmlFor="auto-convert" className="text-sm">
                      Conversion automatique
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="allow-negative"
                      checked={settings.allowNegative}
                      onCheckedChange={(checked) => 
                        saveSettings({ ...settings, allowNegative: checked })
                      }
                    />
                    <Label htmlFor="allow-negative" className="text-sm">
                      Autoriser le solde négatif (MJ)
                    </Label>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <Label className="text-sm">Taille des pas</Label>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <Label htmlFor="step-normal">Normal</Label>
                        <Input
                          id="step-normal"
                          type="number"
                          min="1"
                          value={settings.stepSizes.normal}
                          onChange={(e) => 
                            saveSettings({
                              ...settings,
                              stepSizes: {
                                ...settings.stepSizes,
                                normal: parseInt(e.target.value) || 1
                              }
                            })
                          }
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label htmlFor="step-shift">Shift</Label>
                        <Input
                          id="step-shift"
                          type="number"
                          min="1"
                          value={settings.stepSizes.shift}
                          onChange={(e) => 
                            saveSettings({
                              ...settings,
                              stepSizes: {
                                ...settings.stepSizes,
                                shift: parseInt(e.target.value) || 5
                              }
                            })
                          }
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label htmlFor="step-ctrl">Ctrl</Label>
                        <Input
                          id="step-ctrl"
                          type="number"
                          min="1"
                          value={settings.stepSizes.ctrl}
                          onChange={(e) => 
                            saveSettings({
                              ...settings,
                              stepSizes: {
                                ...settings.stepSizes,
                                ctrl: parseInt(e.target.value) || 10
                              }
                            })
                          }
                          className="h-8"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Gold */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Or</Label>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onMouseDown={(e) => handleAdjustStart('gold', -1, e)}
                onMouseUp={handleAdjustEnd}
                onMouseLeave={handleAdjustEnd}
                onClick={(e) => e.preventDefault()}
              >
                <Minus className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                className="flex-1 h-8 px-2 text-center font-mono"
                onClick={() => openEditDialog('gold')}
              >
                {character.inventory.currency.gold}
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onMouseDown={(e) => handleAdjustStart('gold', 1, e)}
                onMouseUp={handleAdjustEnd}
                onMouseLeave={handleAdjustEnd}
                onClick={(e) => e.preventDefault()}
              >
                <Plus className="h-3 w-3" />
              </Button>
            </div>
          </div>

          {/* Silver */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Argent</Label>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onMouseDown={(e) => handleAdjustStart('silver', -1, e)}
                onMouseUp={handleAdjustEnd}
                onMouseLeave={handleAdjustEnd}
                onClick={(e) => e.preventDefault()}
              >
                <Minus className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                className="flex-1 h-8 px-2 text-center font-mono"
                onClick={() => openEditDialog('silver')}
              >
                {character.inventory.currency.silver}
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onMouseDown={(e) => handleAdjustStart('silver', 1, e)}
                onMouseUp={handleAdjustEnd}
                onMouseLeave={handleAdjustEnd}
                onClick={(e) => e.preventDefault()}
              >
                <Plus className="h-3 w-3" />
              </Button>
            </div>
          </div>

          {/* Bronze */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Bronze</Label>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onMouseDown={(e) => handleAdjustStart('bronze', -1, e)}
                onMouseUp={handleAdjustEnd}
                onMouseLeave={handleAdjustEnd}
                onClick={(e) => e.preventDefault()}
              >
                <Minus className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                className="flex-1 h-8 px-2 text-center font-mono"
                onClick={() => openEditDialog('bronze')}
              >
                {character.inventory.currency.bronze}
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onMouseDown={(e) => handleAdjustStart('bronze', 1, e)}
                onMouseUp={handleAdjustEnd}
                onMouseLeave={handleAdjustEnd}
                onClick={(e) => e.preventDefault()}
              >
                <Plus className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Helper text */}
        <div className="mt-4 text-xs text-muted-foreground">
          <p>Clic: ±{settings.stepSizes.normal} • Shift+clic: ±{settings.stepSizes.shift} • Ctrl+clic: ±{settings.stepSizes.ctrl}</p>
          <p>Maintenir enfoncé pour répétition automatique • Cliquer sur le nombre pour édition directe</p>
        </div>
      </CardContent>

      {/* Direct Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>
              Modifier {editType === 'gold' ? 'Or' : editType === 'silver' ? 'Argent' : 'Bronze'}
            </DialogTitle>
            <DialogDescription>
              Entrez une nouvelle valeur précise
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-value">Nouvelle valeur</Label>
              <Input
                id="edit-value"
                type="number"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                placeholder="0"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleDirectEdit();
                  } else if (e.key === 'Escape') {
                    setShowEditDialog(false);
                  }
                }}
              />
            </div>
            
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                Annuler
              </Button>
              <Button onClick={handleDirectEdit}>
                Confirmer
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}