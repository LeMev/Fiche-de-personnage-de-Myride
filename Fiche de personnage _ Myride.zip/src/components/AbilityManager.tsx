import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tooltip, TooltipContent, TooltipTrigger } from './ui/tooltip';
import { AbilityImportExport } from './AbilityImportExport';
import { RestManager } from './RestManager';
import { AbilityCard } from './AbilityCard';
import { AbilityFormDialog } from './AbilityFormDialog';
import { QuickAddModal } from './QuickAddModal';
import { Glossary } from './Glossary';
import type { Character, Ability, AbilitySortField, AbilityFilterType, AbilityFilterCost, AbilityFilterUsage, GlossaryItem } from '../types/game';
import { Plus, Filter, Swords, Copy, Clipboard, FileText, Sparkles, Library } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { filterAndSortAbilities, canUseAbility, validateResourceCosts, deductResourceCosts } from '../utils/abilityUtils';
import { TYPE_FILTER_OPTIONS, COST_FILTER_OPTIONS, SORT_OPTIONS } from '../constants/abilityConstants';
import { glossaryItemToAbility } from '../utils/glossaryUtils';
import { 
  copyToClipboard, 
  pasteFromClipboard, 
  generateUniqueName 
} from '../utils/clipboardUtils';
import {
  toCanonicalAbility,
  normalizeInput,
  serializeCanonical,
  getExampleCanonical,
  type CanonicalAbilityPayload
} from '../utils/abilitySchema';

interface AbilityManagerProps {
  character: Character;
  editMode: boolean;
  onUpdateCharacter: (character: Character) => void;
}

export function AbilityManager({ character, editMode, onUpdateCharacter }: AbilityManagerProps) {
  const [showNewAbilityDialog, setShowNewAbilityDialog] = useState(false);
  const [editingAbility, setEditingAbility] = useState<Ability | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [showPasteDialog, setShowPasteDialog] = useState(false);
  const [pastedData, setPastedData] = useState<CanonicalAbilityPayload | null>(null);
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [showGlossary, setShowGlossary] = useState(false);
  
  // Filtering and sorting
  const [sortField, setSortField] = useState<AbilitySortField>('name');
  const [filterType, setFilterType] = useState<AbilityFilterType>('all');
  const [filterCost, setFilterCost] = useState<AbilityFilterCost>('all');
  const [filterUsage, setFilterUsage] = useState<AbilityFilterUsage>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredAbilities = filterAndSortAbilities(character.abilities, {
    searchTerm,
    filterType,
    filterCost,
    filterUsage,
    sortField,
  });

  const handleSaveAbility = (ability: Ability) => {
    const isEditing = editingAbility !== null;
    
    const updatedCharacter = {
      ...character,
      abilities: isEditing 
        ? character.abilities.map(a => a.id === ability.id ? ability : a)
        : [...character.abilities, ability],
      updatedAt: new Date().toISOString(),
    };

    onUpdateCharacter(updatedCharacter);
    setEditingAbility(null);
    toast.success(isEditing ? 'Capacité mise à jour' : 'Capacité créée avec succès');
  };

  const handleDeleteAbility = (abilityId: string) => {
    const updatedCharacter = {
      ...character,
      abilities: character.abilities.filter(a => a.id !== abilityId),
      updatedAt: new Date().toISOString(),
    };

    onUpdateCharacter(updatedCharacter);
    toast.success('Capacité supprimée');
  };

  const handleUseAbility = (ability: Ability) => {
    const { canUse, reason } = canUseAbility(ability);
    if (!canUse) {
      toast.error(reason);
      return;
    }

    const focusActive = character.focus?.active || false;
    const { valid, reason: costReason } = validateResourceCosts(ability, character.resources, focusActive);
    if (!valid) {
      toast.error(costReason);
      return;
    }

    const { updatedResources, pmReduction } = deductResourceCosts(ability, character.resources, focusActive);
    
    const updatedAbility = {
      ...ability,
      usedToday: (ability.usedToday || 0) + 1,
      currentCooldown: ability.cooldownTurns || 0,
      usageLog: [
        ...(ability.usageLog || []),
        { timestamp: new Date().toISOString(), context: 'Manuel' }
      ],
      updatedAt: new Date().toISOString(),
    };

    const updatedCharacter = {
      ...character,
      resources: updatedResources,
      abilities: character.abilities.map(a => a.id === ability.id ? updatedAbility : a),
      updatedAt: new Date().toISOString(),
    };

    onUpdateCharacter(updatedCharacter);
    
    // Calculate total PM cost and show appropriate message
    const totalPMCost = ability.costs.reduce((total, cost) => {
      return total + cost.resources.filter(r => r.type === 'PM').reduce((sum, r) => sum + r.amount, 0);
    }, 0);
    const actualPMCost = totalPMCost - pmReduction;
    
    let message = `${ability.name} utilisé`;
    if (totalPMCost > 0) {
      if (pmReduction > 0) {
        message += ` (-${actualPMCost} PM, Focus : -${pmReduction})`;
      } else {
        message += ` (-${actualPMCost} PM)`;
      }
    }
    
    toast.success(message);
  };

  const handleCopyAllAbilities = async () => {
    try {
      // Sérialiser au format canonique avec ordre déterministe
      const canonicalAbilities = character.abilities.map(ability => toCanonicalAbility(ability));
      
      const payload: CanonicalAbilityPayload = {
        abilities: canonicalAbilities
      };
      
      await copyToClipboard(payload);
      toast.success('Capacités copiées au format Myride (abilities).');
    } catch (error) {
      console.error('Erreur lors de la copie des capacités:', error);
      toast.error('Erreur lors de la copie');
    }
  };

  const handlePasteFromClipboard = async () => {
    try {
      const data = await pasteFromClipboard();
      
      // Parser robuste et normalisation
      try {
        const normalized = normalizeInput(data);
        setPastedData(normalized);
        setShowPasteDialog(true);
      } catch (normalizeError) {
        console.error('Erreur de normalisation:', normalizeError);
        toast.error(
          normalizeError instanceof Error 
            ? normalizeError.message 
            : 'Format invalide. Attendu: { "abilities": [ { ... } ] }'
        );
      }
    } catch (error) {
      // Don't show error if user cancelled
      if (error instanceof Error && error.message === 'CANCELLED') {
        return;
      }
      console.error('Erreur lors du collage:', error);
      toast.error('Erreur lors de la lecture du presse-papiers');
    }
  };

  const handleConfirmPasteAbility = () => {
    if (!pastedData || !pastedData.abilities || pastedData.abilities.length === 0) return;
    
    const existingNames = character.abilities.map(a => a.name);
    const newAbilities: Ability[] = [];
    
    pastedData.abilities.forEach(canonical => {
      const uniqueName = generateUniqueName(canonical.name, [...existingNames, ...newAbilities.map(a => a.name)]);
      
      const newAbility: Ability = {
        id: crypto.randomUUID(),
        name: uniqueName,
        type: canonical.type,
        description: canonical.description,
        effects: canonical.effects,
        costs: canonical.costs.map(cost => ({
          context: cost.context,
          resources: cost.resources.map(r => ({
            id: crypto.randomUUID(),
            type: r.type,
            amount: r.amount,
            perUnit: r.perUnit
          }))
        })),
        frequency: canonical.frequency,
        restRefresh: canonical.restRefresh,
        prerequisites: canonical.prerequisites,
        tags: [],
        usedToday: 0,
        currentCooldown: 0,
        usageLog: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      // Ajouter les champs optionnels s'ils sont présents
      if (canonical.activationType) {
        newAbility.activationType = canonical.activationType;
      }
      if (canonical.charges !== undefined) {
        newAbility.charges = canonical.charges;
      }
      if (canonical.maxCharges !== undefined) {
        newAbility.maxCharges = canonical.maxCharges;
      }
      if (canonical.dailyUses !== undefined) {
        newAbility.dailyUses = canonical.dailyUses;
      }
      if (canonical.cooldownTurns !== undefined) {
        newAbility.cooldownTurns = canonical.cooldownTurns;
      }
      if (canonical.hasCharges !== undefined) {
        newAbility.hasCharges = canonical.hasCharges;
      }
      if (canonical.rechargesOnLongRest !== undefined) {
        newAbility.rechargesOnLongRest = canonical.rechargesOnLongRest;
      }
      if (canonical.hasCharges && canonical.maxCharges !== undefined) {
        newAbility.currentCharges = canonical.maxCharges; // Initialize current charges to max
      }
      
      newAbilities.push(newAbility);
    });
    
    const updatedCharacter = {
      ...character,
      abilities: [...character.abilities, ...newAbilities],
      updatedAt: new Date().toISOString(),
    };
    
    onUpdateCharacter(updatedCharacter);
    setShowPasteDialog(false);
    setPastedData(null);
    toast.success(`Importé ${newAbilities.length} capacité${newAbilities.length !== 1 ? 's' : ''}.`);
  };

  const handleImportMultipleAbilities = (abilities: any[]) => {
    // This function is no longer needed as we use handleConfirmPasteAbility
    // But we keep it for backward compatibility
    try {
      const normalized = normalizeInput({ abilities });
      setPastedData(normalized);
      handleConfirmPasteAbility();
    } catch (error) {
      console.error('Erreur lors de l\'import:', error);
      toast.error('Erreur lors de l\'import des capacités');
    }
  };

  const handleAddFromGlossary = (items: GlossaryItem[]) => {
    const existingNames = character.abilities.map(a => a.name);
    const newAbilities: Ability[] = [];
    
    items.forEach(item => {
      const ability = glossaryItemToAbility(item, [...existingNames, ...newAbilities.map(a => a.name)]);
      if (ability) {
        newAbilities.push(ability);
      }
    });
    
    const updatedCharacter = {
      ...character,
      abilities: [...character.abilities, ...newAbilities],
      updatedAt: new Date().toISOString(),
    };
    
    onUpdateCharacter(updatedCharacter);
    toast.success(`${newAbilities.length} capacité${newAbilities.length !== 1 ? 's' : ''} ajoutée${newAbilities.length !== 1 ? 's' : ''}`);
  };
  
  return (
    <div className="space-y-6">
      {/* Header with controls */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Capacités et Compétences</h3>
          <p className="text-sm text-muted-foreground">
            {filteredAbilities.length} capacité{filteredAbilities.length !== 1 ? 's' : ''} trouvée{filteredAbilities.length !== 1 ? 's' : ''}
          </p>
        </div>
        
        <div className="flex gap-2">
          <RestManager character={character} onUpdateCharacter={onUpdateCharacter} />
          
          {editMode && (
            <AbilityImportExport character={character} onUpdateCharacter={onUpdateCharacter} />
          )}
          
          {editMode && (
            <>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowGlossary(true)}
                title="Ouvrir le glossaire"
              >
                <Library className="w-4 h-4 mr-2" />
                Glossaire
              </Button>
            </>
          )}

          <Tooltip>
            <TooltipTrigger asChild>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs">
              <p>Accepte {`{abilities:[...]}`}, une liste, ou un objet unique — tout est normalisé</p>
            </TooltipContent>
          </Tooltip>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="w-4 h-4 mr-2" />
            Filtres
          </Button>
          
          <Button size="sm" onClick={() => setShowNewAbilityDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Ajouter une capacité
          </Button>
        </div>
      </div>

      {/* Filters */}
      {showFilters && (
        <Card>
          <CardContent className="pt-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="search">Rechercher</Label>
                <Input
                  id="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Nom ou description..."
                />
              </div>
              
              <div>
                <Label htmlFor="filter-type">Type</Label>
                <Select value={filterType} onValueChange={(value: AbilityFilterType) => setFilterType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TYPE_FILTER_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="filter-cost">Coût</Label>
                <Select value={filterCost} onValueChange={(value: AbilityFilterCost) => setFilterCost(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {COST_FILTER_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="sort-field">Trier par</Label>
                <Select value={sortField} onValueChange={(value: AbilitySortField) => setSortField(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SORT_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Abilities list */}
      {filteredAbilities.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Swords className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Aucune capacité</h3>
            <p className="text-muted-foreground mb-4">
              {character.abilities.length === 0 
                ? "Ce personnage n'a pas encore de capacités."
                : "Aucune capacité ne correspond aux filtres actifs."
              }
            </p>
            {character.abilities.length === 0 && (
              <Button onClick={() => setShowNewAbilityDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Ajouter une capacité
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredAbilities.map((ability) => {
            const { canUse, reason } = canUseAbility(ability);
            return (
              <AbilityCard
                key={ability.id}
                ability={ability}
                editMode={editMode}
                onUse={handleUseAbility}
                onEdit={setEditingAbility}
                onDelete={handleDeleteAbility}
                canUse={canUse}
                useDisabledReason={reason}
              />
            );
          })}
        </div>
      )}

      {/* Form Dialogs */}
      <AbilityFormDialog
        isOpen={showNewAbilityDialog}
        onClose={() => setShowNewAbilityDialog(false)}
        onSave={handleSaveAbility}
        isEditing={false}
      />
      
      <AbilityFormDialog
        isOpen={!!editingAbility}
        onClose={() => setEditingAbility(null)}
        onSave={handleSaveAbility}
        editingAbility={editingAbility}
        isEditing={true}
      />

      {/* Paste Confirmation Dialog */}
      <Dialog open={showPasteDialog} onOpenChange={setShowPasteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer l'import de capacité(s)</DialogTitle>
            <DialogDescription>
              {pastedData && pastedData.abilities.length === 1 
                ? "Êtes-vous sûr de vouloir ajouter cette capacité ?"
                : `Êtes-vous sûr de vouloir ajouter ces ${pastedData?.abilities.length || 0} capacités ?`
              }
            </DialogDescription>
          </DialogHeader>
          
          {pastedData && (
            <div className="bg-muted p-4 rounded-lg space-y-3 max-h-[400px] overflow-y-auto">
              {pastedData.abilities.map((ability, index) => (
                <div key={index} className="bg-background p-3 rounded border">
                  <div className="grid grid-cols-[120px_1fr] gap-2 text-sm">
                    <span className="font-medium">Nom :</span>
                    <span>{ability.name}</span>
                    
                    <span className="font-medium">Type :</span>
                    <span>{ability.type === 'passive' ? 'Passif' : 'Actif'}</span>
                    
                    <span className="font-medium">Description :</span>
                    <span className="text-xs">{ability.description}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowPasteDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleConfirmPasteAbility}>
              <FileText className="w-4 h-4 mr-2" />
              {pastedData && pastedData.abilities.length === 1 
                ? 'Créer la capacité'
                : `Créer les ${pastedData?.abilities.length || 0} capacités`
              }
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* QuickAdd Modal */}
      <QuickAddModal
        open={showQuickAdd}
        onOpenChange={setShowQuickAdd}
        preFilterType="capacité"
        character={character}
        onAddItems={handleAddFromGlossary}
      />

      {/* Glossary Modal */}
      <Glossary
        open={showGlossary}
        onOpenChange={setShowGlossary}
        preFilterType="capacité"
        character={character}
        onAddToSheet={(item) => {
          if (item.type === 'capacité') {
            handleAddFromGlossary([item]);
          }
        }}
      />
    </div>
  );
}