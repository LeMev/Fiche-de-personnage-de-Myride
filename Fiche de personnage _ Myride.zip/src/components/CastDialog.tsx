// Ce fichier a été remplacé par un système de lancement simple
// intégré directement dans MagicSchoolManager, comme le système
// des capacités avec un simple bouton "Utiliser"

export const CastDialog = () => null;