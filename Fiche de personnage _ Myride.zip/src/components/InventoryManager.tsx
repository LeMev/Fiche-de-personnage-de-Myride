import { useState, useMemo } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import type { Character, InventoryItem, InventorySortField, InventoryFilterCategory, InventoryFilterEquipped, Folder } from '../types/game';
import { CurrencyManager } from './CurrencyManager';
import { FolderManager } from './FolderManager';
import { WeightDisplay } from './WeightDisplay';
import { InventoryItemForm } from './InventoryItemForm';
import { InventoryItemCard } from './InventoryItemCard';
import { Plus, Package, Shield, FolderOpen, ArrowUpDown } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { 
  calculateTotalWeight, 
  getEncumbranceLevel, 
  getItemsInFolder, 
  sortItems,
  updateCharacterInventory,
  addCharacterItem,
  updateCharacterItem,
  removeCharacterItem
} from '../utils/inventoryUtils';

interface InventoryManagerProps {
  character: Character;
  onUpdateCharacter: (character: Character) => void;
}

export function InventoryManager({ character, onUpdateCharacter }: InventoryManagerProps) {
  const [newItemOpen, setNewItemOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [sortField, setSortField] = useState<InventorySortField>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [filterCategory, setFilterCategory] = useState<InventoryFilterCategory>('all');
  const [filterEquipped, setFilterEquipped] = useState<InventoryFilterEquipped>('all');
  const [selectedFolderId, setSelectedFolderId] = useState<string | undefined>();
  const [expandedFolders, setExpandedFolders] = useState<string[]>([]);

  const [formData, setFormData] = useState<Partial<InventoryItem>>({
    name: '',
    quantity: 1,
    weight: 0,
    weightUnit: 'kg',
    folderId: undefined,
    category: 'misc',
    rarity: 'common',
    notes: '',
    equipped: false,
    identified: true,
    hasCharges: false,
    currentCharges: 0,
    rechargesOnLongRest: false,
    armorBonus: 0,
    tags: [],
  });

  const totalWeight = useMemo(() => calculateTotalWeight(character.inventory.items), [character.inventory.items]);
  const encumbranceLevel = getEncumbranceLevel(totalWeight, character.inventory.encumbranceThreshold);

  const resetForm = () => {
    setFormData({
      name: '',
      quantity: 1,
      weight: 0,
      weightUnit: 'kg',
      folderId: selectedFolderId,
      category: 'misc',
      rarity: 'common',
      notes: '',
      equipped: false,
      identified: true,
      hasCharges: false,
      currentCharges: 0,
      rechargesOnLongRest: false,
      armorBonus: 0,
      tags: [],
    });
  };

  const updateInventoryFolders = (folders: Folder[]) => {
    onUpdateCharacter(updateCharacterInventory(character, { folders }));
  };

  const toggleFolderExpanded = (folderId: string) => {
    const newExpanded = expandedFolders.includes(folderId)
      ? expandedFolders.filter(id => id !== folderId)
      : [...expandedFolders, folderId];
    setExpandedFolders(newExpanded);
  };

  const handleCreateItem = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name?.trim()) {
      toast.error('Le nom de l\'objet est requis');
      return;
    }

    const newItem: InventoryItem = {
      id: crypto.randomUUID(),
      name: formData.name.trim(),
      quantity: formData.quantity || 1,
      weight: formData.weight,
      weightUnit: formData.weightUnit || 'kg',
      folderId: formData.folderId,
      category: formData.category || 'misc',
      damage: formData.damage || '',
      rarity: formData.rarity || 'common',
      notes: formData.notes || '',
      equipped: formData.equipped || false,
      identified: formData.identified !== false,
      tags: formData.tags || [],
      hasCharges: formData.hasCharges || false,
      currentCharges: formData.hasCharges ? (formData.currentCharges || 0) : undefined,
      rechargesOnLongRest: formData.hasCharges ? (formData.rechargesOnLongRest || false) : undefined,
      armorBonus: formData.category === 'armor' ? (formData.armorBonus || 0) : undefined,
    };

    onUpdateCharacter(addCharacterItem(character, newItem));
    resetForm();
    setNewItemOpen(false);
    toast.success('Objet ajouté à l\'inventaire');
  };

  const handleEditItem = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingItem || !formData.name?.trim()) {
      toast.error('Le nom de l\'objet est requis');
      return;
    }

    const updatedItem: InventoryItem = {
      ...editingItem,
      name: formData.name.trim(),
      quantity: formData.quantity || 1,
      weight: formData.weight,
      weightUnit: formData.weightUnit || 'kg',
      folderId: formData.folderId,
      category: formData.category || 'misc',
      damage: formData.damage || '',
      rarity: formData.rarity || 'common',
      notes: formData.notes || '',
      equipped: formData.equipped || false,
      identified: formData.identified !== false,
      tags: formData.tags || [],
      hasCharges: formData.hasCharges || false,
      currentCharges: formData.hasCharges ? (formData.currentCharges || 0) : undefined,
      rechargesOnLongRest: formData.hasCharges ? (formData.rechargesOnLongRest || false) : undefined,
      armorBonus: formData.category === 'armor' ? (formData.armorBonus || 0) : undefined,
    };

    onUpdateCharacter(updateCharacterItem(character, editingItem.id, updatedItem));
    setEditingItem(null);
    resetForm();
    toast.success('Objet modifié');
  };

  const handleDeleteItem = (itemId: string) => {
    onUpdateCharacter(removeCharacterItem(character, itemId));
    toast.success('Objet supprimé');
  };

  const handleToggleEquipped = (itemId: string) => {
    const item = character.inventory.items.find(i => i.id === itemId);
    if (item) {
      onUpdateCharacter(updateCharacterItem(character, itemId, { equipped: !item.equipped }));
    }
  };

  const handleUseCharge = (itemId: string) => {
    const item = character.inventory.items.find(i => i.id === itemId);
    if (!item || !item.hasCharges || !item.currentCharges || item.currentCharges <= 0) return;

    onUpdateCharacter(updateCharacterItem(character, itemId, { 
      currentCharges: item.currentCharges - 1 
    }));
    toast.success('Charge utilisée');
  };

  const handleQuantityChange = (itemId: string, change: number) => {
    const item = character.inventory.items.find(i => i.id === itemId);
    if (!item) return;

    const newQuantity = Math.max(0, item.quantity + change);
    
    if (newQuantity === 0) {
      handleDeleteItem(itemId);
      return;
    }

    onUpdateCharacter(updateCharacterItem(character, itemId, { quantity: newQuantity }));
  };

  const startEditing = (item: InventoryItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      quantity: item.quantity,
      weight: item.weight,
      weightUnit: item.weightUnit,
      folderId: item.folderId,
      category: item.category,
      damage: item.damage,
      rarity: item.rarity,
      notes: item.notes,
      equipped: item.equipped,
      identified: item.identified,
      tags: item.tags,
      hasCharges: item.hasCharges || false,
      currentCharges: item.currentCharges || 0,
      rechargesOnLongRest: item.rechargesOnLongRest || false,
      armorBonus: item.armorBonus || 0,
    });
  };

  // Handle "All Items" virtual folder
  const isAllItemsSelected = selectedFolderId === 'all-items';
  const filteredItems = isAllItemsSelected 
    ? character.inventory.items.filter(item => {
        // Apply category and equipped filters but not folder filter
        if (filterCategory !== 'all' && item.category !== filterCategory) return false;
        if (filterEquipped === 'equipped' && !item.equipped) return false;
        if (filterEquipped === 'unequipped' && item.equipped) return false;
        return true;
      })
    : getItemsInFolder(
        character.inventory.items, 
        selectedFolderId, 
        filterCategory, 
        filterEquipped
      );
  const sortedItems = sortItems(filteredItems, sortField, sortDirection);
  const equippedItems = character.inventory.items.filter(item => item.equipped);

  const handleSort = (field: InventorySortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  return (
    <div className="space-y-6">
      <CurrencyManager character={character} onUpdateCharacter={onUpdateCharacter} />
      
      <WeightDisplay 
        totalWeight={totalWeight}
        encumbranceLevel={encumbranceLevel}
        encumbranceThreshold={character.inventory.encumbranceThreshold}
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="md:col-span-1">
          <CardContent className="p-4">
            <div className="space-y-2">
              {/* Virtual "All Items" root */}
              <div className="mb-4">
                <Button
                  variant={selectedFolderId === 'all-items' ? 'default' : 'ghost'}
                  size="sm"
                  className="w-full justify-start p-2 h-auto"
                  onClick={() => setSelectedFolderId('all-items')}
                >
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4" />
                    <span className="flex-1 text-left">Tous les objets</span>
                    <Badge variant="secondary" className="text-xs">
                      {character.inventory.items.length}
                    </Badge>
                  </div>
                </Button>
              </div>
              
              {/* Regular folder structure */}
              <FolderManager
                folders={character.inventory.folders || []}
                type="inventory"
                expandedFolders={expandedFolders}
                onUpdateFolders={updateInventoryFolders}
                onToggleExpanded={toggleFolderExpanded}
                onSelectFolder={setSelectedFolderId}
                selectedFolderId={selectedFolderId}
              />
            </div>
          </CardContent>
        </Card>

        <div className="md:col-span-3">
          <Tabs defaultValue="inventory" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="inventory">
                {isAllItemsSelected ? (
                  <>
                    <Package className="w-4 h-4 mr-2" />
                    Tous les objets ({filteredItems.length})
                  </>
                ) : selectedFolderId ? (
                  <>
                    <FolderOpen className="w-4 h-4 mr-2" />
                    Dossier ({filteredItems.length})
                  </>
                ) : (
                  <>Inventaire ({filteredItems.length})</>
                )}
              </TabsTrigger>
              <TabsTrigger value="equipped">Équipé ({equippedItems.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="inventory" className="space-y-4">
              {/* Controls */}
              <div className="flex flex-wrap gap-2 items-center justify-between">
                <div className="flex flex-wrap gap-2">
                  <Select value={filterCategory} onValueChange={(value: InventoryFilterCategory) => setFilterCategory(value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Catégorie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes catégories</SelectItem>
                      <SelectItem value="weapon">Armes</SelectItem>
                      <SelectItem value="armor">Armures</SelectItem>
                      <SelectItem value="consumable">Consommables</SelectItem>
                      <SelectItem value="quest">Objets de quête</SelectItem>
                      <SelectItem value="unknown">Inconnus</SelectItem>
                      <SelectItem value="container">Conteneurs</SelectItem>
                      <SelectItem value="misc">Divers</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterEquipped} onValueChange={(value: InventoryFilterEquipped) => setFilterEquipped(value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="État" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="equipped">Équipés</SelectItem>
                      <SelectItem value="unequipped">Non équipés</SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="flex gap-1">
                    <Button variant="outline" size="sm" onClick={() => handleSort('name')}>
                      <ArrowUpDown className="w-3 h-3 mr-1" />
                      Nom {sortField === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleSort('category')}>
                      <ArrowUpDown className="w-3 h-3 mr-1" />
                      Catégorie {sortField === 'category' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleSort('weight')}>
                      <ArrowUpDown className="w-3 h-3 mr-1" />
                      Poids {sortField === 'weight' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </Button>
                  </div>
                </div>

                <Dialog open={newItemOpen} onOpenChange={setNewItemOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Ajouter un objet
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto" aria-describedby={undefined}>
                    <DialogHeader>
                      <DialogTitle>Ajouter un nouvel objet</DialogTitle>
                      <DialogDescription>
                        Ajoutez un nouvel objet à l'inventaire de votre personnage.
                      </DialogDescription>
                    </DialogHeader>
                    <InventoryItemForm
                      formData={formData}
                      setFormData={setFormData}
                      onSubmit={handleCreateItem}
                      onCancel={() => { setNewItemOpen(false); resetForm(); }}
                      folders={character.inventory.folders || []}
                    />
                  </DialogContent>
                </Dialog>
              </div>

              {/* Items List */}
              <div className="space-y-2">
                {sortedItems.length === 0 ? (
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                      <h3>Inventaire vide</h3>
                      <p className="text-muted-foreground mb-4">
                        {filterCategory !== 'all' || filterEquipped !== 'all' 
                          ? 'Aucun objet ne correspond aux filtres sélectionnés'
                          : 'Aucun objet dans l\'inventaire'
                        }
                      </p>
                      <Button onClick={() => setNewItemOpen(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Ajouter un objet
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  sortedItems.map((item) => (
                    <InventoryItemCard
                      key={item.id}
                      item={item}
                      onEdit={startEditing}
                      onDelete={handleDeleteItem}
                      onToggleEquipped={handleToggleEquipped}
                      onUseCharge={handleUseCharge}
                      onQuantityChange={handleQuantityChange}
                    />
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="equipped" className="space-y-4">
              {equippedItems.length === 0 ? (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <Shield className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <h3>Aucun objet équipé</h3>
                    <p className="text-muted-foreground">
                      Équipez des objets depuis l'inventaire pour les voir apparaître ici.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-2">
                  {equippedItems.map((item) => (
                    <Card key={item.id} className="border-primary">
                      <CardContent className="pt-4">
                        <div className="flex items-center gap-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-medium">{item.name}</h4>
                              <Badge variant="default">Équipé</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {item.category}
                              {item.damage && ` • ${item.damage}`}
                              {item.armorBonus && ` • +${item.armorBonus} Armure`}
                            </p>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleToggleEquipped(item.id)}
                          >
                            Déséquiper
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Edit Item Dialog */}
      <Dialog open={!!editingItem} onOpenChange={() => { setEditingItem(null); resetForm(); }}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>Modifier : {editingItem?.name}</DialogTitle>
            <DialogDescription>
              Modifiez les propriétés de cet objet.
            </DialogDescription>
          </DialogHeader>
          <InventoryItemForm
            formData={formData}
            setFormData={setFormData}
            onSubmit={handleEditItem}
            onCancel={() => { setEditingItem(null); resetForm(); }}
            isEditing={true}
            folders={character.inventory.folders || []}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}