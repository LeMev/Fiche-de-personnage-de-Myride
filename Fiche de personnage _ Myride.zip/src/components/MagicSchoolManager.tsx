import { useState, useMemo, useEffect, useCallback } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';

import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { ScrollArea } from './ui/scroll-area';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import type { Character, MagicSchool, BaseRune, Spell, RunePower, SpellCost } from '../types/game';
import { MagicImportExport } from './MagicImportExport';
import { MagicSchoolTemplates } from './MagicSchoolTemplates';
import SpellCostEditor from './SpellCostEditor';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Scroll, 
  Sparkles, 
  ChevronDown,
  ChevronRight,
  Download,
  Upload,
  Copy,
  Book,
  Zap,
  Clock,
  Target,
  Focus,
  MoreVertical,
  Search,
  FileText,
  List,
  Type,
  Play,
  Clipboard
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { 
  serializeSpell, 
  serializeRunePower,
  copyToClipboard, 
  pasteFromClipboard,
  generateUniqueName,
  isValidSerializedSpell,
  isValidSerializedSpellArray,
  deserializeSpell,
  type SerializedSpell
} from '../utils/clipboardUtils';
import { 
  canUseMagic,
  validateMagicCosts,
  deductMagicCosts,
  getSpellDisplayFields, 
  getPowerDisplayFields
} from '../utils/magicUtils';

interface MagicSchoolManagerProps {
  character: Character;
  editMode: boolean;
  onUpdateCharacter: (character: Character) => void;
}

type NavigationItem = 
  | { type: 'school'; school: MagicSchool }
  | { type: 'spell'; school: MagicSchool; spell: Spell }
  | { type: 'rune'; school: MagicSchool; rune: BaseRune }
  | { type: 'power'; school: MagicSchool; rune: BaseRune; power: RunePower; powerType: 'quick' | 'lasting' };

export function MagicSchoolManager({ character, editMode, onUpdateCharacter }: MagicSchoolManagerProps) {
  const [editingSchool, setEditingSchool] = useState<MagicSchool | null>(null);
  const [editingSpell, setEditingSpell] = useState<Spell | null>(null);
  const [editingRune, setEditingRune] = useState<BaseRune | null>(null);
  const [editingPower, setEditingPower] = useState<RunePower | null>(null);
  const [selectedSchoolId, setSelectedSchoolId] = useState<string | null>(null);
  const [selectedRuneId, setSelectedRuneId] = useState<string | null>(null);
  const [showSchoolDialog, setShowSchoolDialog] = useState(false);
  const [showSpellDialog, setShowSpellDialog] = useState(false);
  const [showRuneDialog, setShowRuneDialog] = useState(false);
  const [showPowerDialog, setShowPowerDialog] = useState(false);
  const [showSpellImportDialog, setShowSpellImportDialog] = useState(false);
  const [showPasteSpellDialog, setShowPasteSpellDialog] = useState(false);
  const [pastedSpell, setPastedSpell] = useState<SerializedSpell | null>(null);
  const [pasteTargetSchoolId, setPasteTargetSchoolId] = useState<string | null>(null);

  const [importTargetSchoolId, setImportTargetSchoolId] = useState<string>('none');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Navigation state
  const [selectedNavItem, setSelectedNavItem] = useState<NavigationItem | null>(null);
  
  // View preferences
  const [viewMode, setViewMode] = useState<'list' | 'rich'>('rich'); // Default to rich text
  
  // Utility function to ensure costs have stable ids
  const ensureCostIds = useCallback((costs: SpellCost[]): SpellCost[] => {
    return costs.map(cost => ({
      ...cost,
      id: cost.id || crypto.randomUUID()
    }));
  }, []);

  // Utility function to migrate spells and powers to have stable cost ids
  const migrateSchoolsWithCostIds = useCallback((schools: MagicSchool[]): MagicSchool[] => {
    return schools.map(school => ({
      ...school,
      spells: school.spells?.map(spell => ({
        ...spell,
        costs: ensureCostIds(spell.costs)
      })),
      baseRunes: school.baseRunes?.map(rune => ({
        ...rune,
        quickPowers: rune.quickPowers.map(power => ({
          ...power,
          costs: ensureCostIds(power.costs)
        })),
        lastingPowers: rune.lastingPowers.map(power => ({
          ...power,
          costs: ensureCostIds(power.costs)
        }))
      }))
    }));
  }, [ensureCostIds]);

  // Ensure magic structure exists with proper defaults and stable cost ids
  const safeCharacter = useMemo(() => {
    if (!character.magic) {
      return {
        ...character,
        magic: {
          schools: [],
          expandedSchools: []
        }
      };
    }
    return {
      ...character,
      magic: {
        schools: migrateSchoolsWithCostIds(character.magic.schools || []),
        expandedSchools: character.magic.expandedSchools || []
      }
    };
  }, [character, migrateSchoolsWithCostIds]);
  
  // Track expanded state
  const [expandedSchools, setExpandedSchools] = useState<string[]>(
    safeCharacter.magic.expandedSchools || []
  );
  const [expandedRunes, setExpandedRunes] = useState<string[]>([]);
  
  // Fixed: separate power type for editing context
  const [editingPowerType, setEditingPowerType] = useState<'quick' | 'lasting'>('quick');

  // Persist view mode
  useEffect(() => {
    const savedViewMode = localStorage.getItem('magic_view_mode') as 'list' | 'rich';
    if (savedViewMode) {
      setViewMode(savedViewMode);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('magic_view_mode', viewMode);
  }, [viewMode]);

  const updateCharacterMagic = useCallback((schools: MagicSchool[], newExpandedSchools?: string[]) => {
    const updatedCharacter = {
      ...safeCharacter,
      magic: { 
        schools,
        expandedSchools: newExpandedSchools || expandedSchools
      }
    };
    onUpdateCharacter(updatedCharacter);
  }, [safeCharacter, expandedSchools, onUpdateCharacter]);

  const toggleSchoolExpanded = useCallback((schoolId: string) => {
    const newExpanded = expandedSchools.includes(schoolId)
      ? expandedSchools.filter(id => id !== schoolId)
      : [...expandedSchools, schoolId];
    
    setExpandedSchools(newExpanded);
    updateCharacterMagic(safeCharacter.magic.schools, newExpanded);
  }, [expandedSchools, updateCharacterMagic, safeCharacter.magic.schools]);

  const toggleRuneExpanded = useCallback((runeId: string) => {
    const newExpanded = expandedRunes.includes(runeId)
      ? expandedRunes.filter(id => id !== runeId)
      : [...expandedRunes, runeId];
    
    setExpandedRunes(newExpanded);
  }, [expandedRunes]);



  // Filter schools and spells based on search query
  const filteredSchoolsAndSpells = useMemo(() => {
    if (!searchQuery.trim()) {
      return safeCharacter.magic.schools;
    }

    const query = searchQuery.toLowerCase();
    return safeCharacter.magic.schools.map(school => {
      const schoolMatches = school.name.toLowerCase().includes(query) ||
                           school.description?.toLowerCase().includes(query);
      
      let filteredSpells: Spell[] = [];
      let filteredRunes: BaseRune[] = [];

      if (school.type === 'elven' && school.spells) {
        filteredSpells = school.spells.filter(spell =>
          spell.name.toLowerCase().includes(query) ||
          spell.description.toLowerCase().includes(query) ||
          spell.tags?.some(tag => tag.toLowerCase().includes(query))
        );
      }

      if (school.type === 'runic' && school.baseRunes) {
        filteredRunes = school.baseRunes.filter(rune =>
          rune.name.toLowerCase().includes(query) ||
          rune.description.toLowerCase().includes(query) ||
          rune.code.toLowerCase().includes(query) ||
          [...rune.quickPowers, ...rune.lastingPowers].some(power =>
            power.name.toLowerCase().includes(query) ||
            power.description.toLowerCase().includes(query)
          )
        );
      }

      if (schoolMatches || filteredSpells.length > 0 || filteredRunes.length > 0) {
        return {
          ...school,
          spells: school.type === 'elven' ? filteredSpells : school.spells,
          baseRunes: school.type === 'runic' ? filteredRunes : school.baseRunes
        };
      }

      return null;
    }).filter(Boolean) as MagicSchool[];
  }, [safeCharacter.magic.schools, searchQuery]);

  const createNewSchool = (): MagicSchool => ({
    id: crypto.randomUUID(),
    name: '',
    description: '',
    type: 'elven',
    isShared: false,
    createdBy: character.id,
    spells: [],
    baseRunes: []
  });

  const createNewSpell = (): Spell => ({
    id: crypto.randomUUID(),
    name: '',
    description: '',
    costs: [{ id: crypto.randomUUID(), context: 'Standard', resources: [{ type: 'PM', amount: 1 }] }],
    activationType: 'action',
    tags: []
  });

  const createNewRune = (): BaseRune => ({
    id: crypto.randomUUID(),
    code: '',
    name: '',
    description: '',
    masteryPercentage: 0,
    quickPowers: [],
    lastingPowers: []
  });

  const createNewPower = (): RunePower => ({
    id: crypto.randomUUID(),
    name: '',
    description: '',
    costs: [{ id: crypto.randomUUID(), context: 'Standard', resources: [{ type: 'PM', amount: 1 }] }],
    activationType: 'action'
  });

  // Handle magic use (simple like abilities)
  const handleUseMagic = (item: Spell | RunePower, type: 'spell' | 'power') => {
    const { canUse, reason } = canUseMagic(item, safeCharacter);
    if (!canUse) {
      toast.error(reason);
      return;
    }

    const focusActive = safeCharacter.focus?.active || false;
    const { valid, reason: costReason } = validateMagicCosts(item, safeCharacter.resources, focusActive);
    if (!valid) {
      toast.error(costReason);
      return;
    }

    const { updatedResources, pmReduction } = deductMagicCosts(item, safeCharacter.resources, focusActive);
    
    const updatedCharacter = {
      ...safeCharacter,
      resources: updatedResources,
      updatedAt: new Date().toISOString(),
    };

    onUpdateCharacter(updatedCharacter);
    
    const costProfiles = item.costs || [];
    const defaultCost = costProfiles[0];
    const basePMCost = defaultCost?.resources.find(r => r.type === 'PM')?.amount || 0;
    const actualPMCost = basePMCost - pmReduction;
    
    let pmMessage = '';
    if (basePMCost > 0) {
      if (pmReduction > 0) {
        pmMessage = ` (-${actualPMCost} PM, Focus : -${pmReduction})`;
      } else {
        pmMessage = ` (-${actualPMCost} PM)`;
      }
    }
    
    toast.success(`${item.name} utilisé${pmMessage}`);
  };

  // Handle Focus toggle
  const handleToggleFocus = () => {
    const currentFocus = safeCharacter.focus?.active || false;
    const updatedCharacter = {
      ...safeCharacter,
      focus: { active: !currentFocus },
      updatedAt: new Date().toISOString(),
    };

    onUpdateCharacter(updatedCharacter);
    
    if (!currentFocus) {
      toast.success('Focus activé : -1 PM à chaque consommation');
    } else {
      toast.success('Focus désactivé');
    }
  };

  // Save handlers
  const handleSaveSchool = () => {
    if (!editingSchool || !editingSchool.name.trim()) {
      toast.error('Le nom de l\'école est requis');
      return;
    }

    const schools = [...safeCharacter.magic.schools];
    const existingIndex = schools.findIndex(s => s.id === editingSchool.id);
    
    if (existingIndex >= 0) {
      schools[existingIndex] = editingSchool;
    } else {
      schools.push(editingSchool);
    }

    updateCharacterMagic(schools);
    setEditingSchool(null);
    setShowSchoolDialog(false);
    toast.success('École de magie sauvegardée');
  };

  const handleDeleteSchool = (schoolId: string) => {
    const schools = safeCharacter.magic.schools.filter(s => s.id !== schoolId);
    updateCharacterMagic(schools);
    toast.success('École de magie supprimée');
  };

  const handleSaveSpell = () => {
    if (!editingSpell || !editingSpell.name.trim() || !selectedSchoolId) {
      toast.error('Le nom du sort et l\'école sont requis');
      return;
    }

    const schools = [...safeCharacter.magic.schools];
    const school = schools.find(s => s.id === selectedSchoolId);
    if (!school || school.type !== 'elven') return;

    if (!school.spells) school.spells = [];
    const existingIndex = school.spells.findIndex(s => s.id === editingSpell.id);
    
    if (existingIndex >= 0) {
      school.spells[existingIndex] = editingSpell;
    } else {
      school.spells.push(editingSpell);
    }

    updateCharacterMagic(schools);
    setEditingSpell(null);
    setShowSpellDialog(false);
    toast.success('Sort sauvegardé');
  };

  const handleSaveRune = () => {
    if (!editingRune || !editingRune.name.trim()) {
      toast.error('Le nom de la rune est requis');
      return;
    }

    const schools = [...safeCharacter.magic.schools];
    let runicSchool = schools.find(s => s.type === 'runic');
    
    if (!runicSchool) {
      runicSchool = {
        id: crypto.randomUUID(),
        name: 'École runique',
        description: 'École de magie runique',
        type: 'runic',
        isShared: false,
        createdBy: character.id,
        spells: [],
        baseRunes: []
      };
      schools.push(runicSchool);
    }

    if (!runicSchool.baseRunes) runicSchool.baseRunes = [];
    const existingIndex = runicSchool.baseRunes.findIndex(r => r.id === editingRune.id);
    
    if (existingIndex >= 0) {
      runicSchool.baseRunes[existingIndex] = editingRune;
    } else {
      runicSchool.baseRunes.push(editingRune);
    }

    updateCharacterMagic(schools);
    setEditingRune(null);
    setShowRuneDialog(false);
    toast.success('Rune sauvegardée');
  };

  const handleSavePower = () => {
    if (!editingPower || !editingPower.name.trim() || !selectedRuneId) {
      toast.error('Le nom du pouvoir et la rune sont requis');
      return;
    }

    const schools = [...safeCharacter.magic.schools];
    const runicSchool = schools.find(s => s.type === 'runic');
    if (!runicSchool || !runicSchool.baseRunes) return;

    const rune = runicSchool.baseRunes.find(r => r.id === selectedRuneId);
    if (!rune) return;

    const powers = editingPowerType === 'quick' ? rune.quickPowers : rune.lastingPowers;
    const existingIndex = powers.findIndex(p => p.id === editingPower.id);
    
    if (existingIndex >= 0) {
      powers[existingIndex] = editingPower;
    } else {
      powers.push(editingPower);
    }

    updateCharacterMagic(schools);
    setEditingPower(null);
    setShowPowerDialog(false);
    toast.success(`Pouvoir ${editingPowerType === 'quick' ? 'rapide' : 'durable'} sauvegardé`);
  };

  // Delete handlers
  const handleDeleteRune = (runeId: string) => {
    const schools = [...safeCharacter.magic.schools];
    const runicSchool = schools.find(s => s.type === 'runic');
    if (!runicSchool || !runicSchool.baseRunes) return;

    runicSchool.baseRunes = runicSchool.baseRunes.filter(r => r.id !== runeId);
    updateCharacterMagic(schools);
    toast.success('Rune supprimée');
  };

  const handleDeletePower = (powerId: string, powerType: 'quick' | 'lasting') => {
    if (!selectedRuneId) return;

    const schools = [...safeCharacter.magic.schools];
    const runicSchool = schools.find(s => s.type === 'runic');
    if (!runicSchool || !runicSchool.baseRunes) return;

    const rune = runicSchool.baseRunes.find(r => r.id === selectedRuneId);
    if (!rune) return;

    const powers = powerType === 'quick' ? rune.quickPowers : rune.lastingPowers;
    const updatedPowers = powers.filter(p => p.id !== powerId);
    
    if (powerType === 'quick') {
      rune.quickPowers = updatedPowers;
    } else {
      rune.lastingPowers = updatedPowers;
    }

    updateCharacterMagic(schools);
    toast.success(`Pouvoir ${powerType === 'quick' ? 'rapide' : 'durable'} supprimé`);
  };

  const handleDeleteSpell = (spellId: string, schoolId: string) => {
    const schools = [...safeCharacter.magic.schools];
    const school = schools.find(s => s.id === schoolId);
    if (!school || !school.spells) return;

    school.spells = school.spells.filter(s => s.id !== spellId);
    updateCharacterMagic(schools);
    toast.success('Sort supprimé');
  };

  // Export individual spell
  const exportSpell = (spell: Spell, schoolName: string) => {
    const exportData = {
      spell,
      schoolName,
      exportedAt: new Date().toISOString(),
      exportedBy: character.name
    };
    
    const data = JSON.stringify(exportData, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sort-${spell.name.toLowerCase().replace(/\s+/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Sort exporté');
  };

  // Import individual spell
  const handleImportSpell = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importData = JSON.parse(e.target?.result as string);
        const spell: Spell = {
          ...importData.spell,
          id: crypto.randomUUID(),
          tags: importData.spell.tags || [],
          costs: ensureCostIds(importData.spell.costs || [])
        };

        if (!importTargetSchoolId || importTargetSchoolId === 'none') {
          toast.error('Veuillez sélectionner une école de destination');
          return;
        }

        const schools = [...safeCharacter.magic.schools];
        const school = schools.find(s => s.id === importTargetSchoolId);
        if (!school || school.type !== 'elven') {
          toast.error('École de destination invalide');
          return;
        }

        if (!school.spells) school.spells = [];
        school.spells.push(spell);

        updateCharacterMagic(schools);
        setShowSpellImportDialog(false);
        setImportTargetSchoolId('none');
        toast.success(`Sort "${spell.name}" importé dans "${school.name}"`);
      } catch (error) {
        toast.error('Erreur lors de l\'importation du sort');
        console.error('Import error:', error);
      }
    };
    reader.readAsText(file);
    
    event.target.value = '';
  };

  const exportSchool = (school: MagicSchool) => {
    const data = JSON.stringify(school, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ecole-${school.name.toLowerCase().replace(/\s+/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('École exportée');
  };

  const handleImportSchool = (school: MagicSchool) => {
    const importedSchool = {
      ...school,
      id: crypto.randomUUID(),
      createdBy: character.id,
      isShared: false,
      type: school.type === 'standard' ? 'elven' : school.type,
      spells: school.spells?.map(spell => ({
        ...spell,
        costs: ensureCostIds(spell.costs)
      })),
      baseRunes: school.baseRunes?.map(rune => ({
        ...rune,
        quickPowers: rune.quickPowers.map(power => ({
          ...power,
          costs: ensureCostIds(power.costs)
        })),
        lastingPowers: rune.lastingPowers.map(power => ({
          ...power,
          costs: ensureCostIds(power.costs)
        }))
      }))
    } as MagicSchool;
    
    const schools = [...safeCharacter.magic.schools, importedSchool];
    updateCharacterMagic(schools);
    toast.success(`École "${school.name}" importée avec succès`);
  };

  // Copy all spells to clipboard
  const handleCopyAllSpells = async () => {
    try {
      const allSpells: SerializedSpell[] = [];
      safeCharacter.magic.schools.forEach(school => {
        if (school.spells && school.spells.length > 0) {
          school.spells.forEach(spell => {
            allSpells.push(serializeSpell(spell));
          });
        }
      });
      
      if (allSpells.length === 0) {
        toast.error('Aucun sort à copier');
        return;
      }
      
      await copyToClipboard(allSpells);
      toast.success(`${allSpells.length} sort${allSpells.length !== 1 ? 's' : ''} copié${allSpells.length !== 1 ? 's' : ''} !`);
    } catch (error) {
      console.error('Erreur lors de la copie des sorts:', error);
      toast.error('Erreur lors de la copie');
    }
  };

  // Paste spell(s) from clipboard
  const handlePasteFromClipboard = async (schoolId: string) => {
    try {
      const data = await pasteFromClipboard();
      
      // Check if it's a single spell
      if (isValidSerializedSpell(data)) {
        setPastedSpell(data);
        setPasteTargetSchoolId(schoolId);
        setShowPasteSpellDialog(true);
        return;
      }
      
      // Check if it's an array of spells
      if (isValidSerializedSpellArray(data)) {
        handleImportMultipleSpells(data, schoolId);
        return;
      }
      
      toast.error('Le contenu du presse-papiers n\'est pas un sort valide');
    } catch (error) {
      // Don't show error if user cancelled
      if (error instanceof Error && error.message === 'CANCELLED') {
        return;
      }
      console.error('Erreur lors du collage:', error);
      toast.error('Erreur lors de la lecture du presse-papiers');
    }
  };

  // Confirm paste single spell
  const handleConfirmPasteSpell = () => {
    if (!pastedSpell || !pasteTargetSchoolId) return;
    
    const schools = [...safeCharacter.magic.schools];
    const school = schools.find(s => s.id === pasteTargetSchoolId);
    if (!school || school.type !== 'elven') {
      toast.error('École invalide pour coller un sort');
      return;
    }
    
    if (!school.spells) school.spells = [];
    const existingNames = school.spells.map(s => s.name);
    const uniqueName = generateUniqueName(pastedSpell.name, existingNames);
    
    const deserializedSpell = deserializeSpell(pastedSpell);
    const newSpell: Spell = {
      ...deserializedSpell,
      id: crypto.randomUUID(),
      name: uniqueName,
    };
    
    school.spells.push(newSpell);
    updateCharacterMagic(schools);
    setShowPasteSpellDialog(false);
    setPastedSpell(null);
    setPasteTargetSchoolId(null);
    toast.success(`Sort "${uniqueName}" créé avec succès`);
  };

  // Import multiple spells
  const handleImportMultipleSpells = (spells: SerializedSpell[], schoolId: string) => {
    const schools = [...safeCharacter.magic.schools];
    const school = schools.find(s => s.id === schoolId);
    if (!school || school.type !== 'elven') {
      toast.error('École invalide pour coller des sorts');
      return;
    }
    
    if (!school.spells) school.spells = [];
    const existingNames = school.spells.map(s => s.name);
    const newSpells: Spell[] = [];
    
    spells.forEach(spellData => {
      const uniqueName = generateUniqueName(spellData.name, [...existingNames, ...newSpells.map(s => s.name)]);
      const deserializedSpell = deserializeSpell(spellData);
      
      const newSpell: Spell = {
        ...deserializedSpell,
        id: crypto.randomUUID(),
        name: uniqueName,
      };
      
      newSpells.push(newSpell);
    });
    
    school.spells.push(...newSpells);
    updateCharacterMagic(schools);
    toast.success(`${newSpells.length} sort${newSpells.length !== 1 ? 's' : ''} importé${newSpells.length !== 1 ? 's' : ''} avec succès`);
  };

  // Get the runic school
  const runicSchool = safeCharacter.magic.schools.find(s => s.type === 'runic');

  // Get current PM for display (PM = Points de Mana = mp resource)
  const currentPM = character.resources?.mp?.current || 0;

  // Get elven schools for spell creation
  const elvenSchools = safeCharacter.magic.schools.filter(s => s.type === 'elven');

 const schoolDialog = (
      <Dialog open={showSchoolDialog} onOpenChange={setShowSchoolDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>
              {editingSchool?.id ? 'Modifier l\'école' : 'Nouvelle école'}
            </DialogTitle>
            <DialogDescription>
              Créez ou modifiez une école de magie
            </DialogDescription>
          </DialogHeader>
          
          {editingSchool && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="school-name">Nom de l'école</Label>
                <Input
                  id="school-name"
                  value={editingSchool.name}
                  onChange={(e) => setEditingSchool({ ...editingSchool, name: e.target.value })}
                  placeholder="Nom de l'école de magie"
                />
              </div>
              
              <div>
                <Label htmlFor="school-description">Description</Label>
                <Textarea
                  id="school-description"
                  value={editingSchool.description || ''}
                  onChange={(e) => setEditingSchool({ ...editingSchool, description: e.target.value })}
                  placeholder="Description de l'école..."
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="school-type">Type d'école</Label>
                <Select
                  value={editingSchool.type}
                  onValueChange={(value: 'elven' | 'runic') => 
                    setEditingSchool({ ...editingSchool, type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="elven">École Elfe (Sorts)</SelectItem>
                    <SelectItem value="runic">École Runique (Runes & Pouvoirs)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setShowSchoolDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleSaveSchool}>
              Sauvegarder
            </Button>
          </div>
        </DialogContent>
      </Dialog>
);
   
  if (!editMode && safeCharacter.magic.schools.length === 0) {
    return (<>
        {schoolDialog}
      <Card>
        <CardHeader>
          <CardTitle>Écoles de Magie</CardTitle>
          <CardDescription>
            Gestion des écoles de magie et des sorts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Scroll className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-[rgba(0,0,0,1)] mb-4 text-[15px]">Aucune école de magie</p>
            <div className="flex gap-2 justify-center">
              <Button onClick={() => { 
                console.log('Création nouvelle école'); 
                setEditingSchool(createNewSchool()); 
                setShowSchoolDialog(true); 
              }}>
                <Plus className="w-4 h-4 mr-2" />
                Créer une école
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </>);
  }

  return (
    <div className="space-y-6">
      {schoolDialog}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Écoles de Magie</CardTitle>
              <CardDescription>
                Gestion des écoles de magie et des sorts/runes avec système de lancement
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              {/* Focus Button - Always visible */}
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant={safeCharacter.focus?.active ? "default" : "outline"}
                      size="sm"
                      onClick={handleToggleFocus}
                      aria-pressed={safeCharacter.focus?.active || false}
                      className={safeCharacter.focus?.active ? "gap-2" : ""}
                    >
                      <Focus className="w-4 h-4" />
                      {safeCharacter.focus?.active ? "Focus (–1 PM)" : "Focus"}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Réduit de 1 PM tous les coûts en PM tant que Focus est activé</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              {/* PM Display */}
              <Badge variant={currentPM > 0 ? "default" : "destructive"} className="text-sm">
                {currentPM} PM
              </Badge>
              
              {editMode && (
                <div className="flex gap-2">
                  <MagicSchoolTemplates onSelectTemplate={handleImportSchool} />
                  <MagicImportExport onImportSchool={handleImportSchool} />
                  
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleCopyAllSpells}
                    title="Copier tous les sorts"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copier tous les sorts
                  </Button>


                  {/* Import individual spell */}
                  <Dialog open={showSpellImportDialog} onOpenChange={setShowSpellImportDialog}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <FileText className="w-4 h-4 mr-2" />
                        Importer Sort
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md" aria-describedby={undefined}>
                      <DialogHeader>
                        <DialogTitle>Importer un sort</DialogTitle>
                        <DialogDescription>
                          Importez un sort dans une école existante
                        </DialogDescription>
                      </DialogHeader>
                      
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="target-school">École de destination</Label>
                          <Select 
                            value={importTargetSchoolId} 
                            onValueChange={setImportTargetSchoolId}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Choisir une école elfe..." />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="none">Choisir une école...</SelectItem>
                              {safeCharacter.magic.schools
                                .filter(school => school.type === 'elven')
                                .map(school => (
                                  <SelectItem key={school.id} value={school.id}>
                                    {school.name}
                                  </SelectItem>
                                ))
                              }
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label htmlFor="spell-file">Fichier du sort</Label>
                          <Input
                            id="spell-file"
                            type="file"
                            accept=".json"
                            onChange={handleImportSpell}
                          />
                        </div>
                      </div>
                      
                      <div className="flex justify-end gap-2 pt-4">
                        <Button variant="outline" onClick={() => setShowSpellImportDialog(false)}>
                          Annuler
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  {/* Add School Button */}
                  <Button type="button" onClick={() => { setEditingSchool(createNewSchool()); setShowSchoolDialog(true); }}>
                    <Plus className="w-4 h-4 mr-2" />
                    École
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Quick Action Buttons - Always visible */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="flex flex-wrap gap-2">
              {/* Add Spell Button - Only show if there are elven schools */}
              {elvenSchools.length > 0 && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      <Sparkles className="w-4 h-4 mr-2" />
                      Ajouter un sort
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md" aria-describedby={undefined}>
                    <DialogHeader>
                      <DialogTitle>Sélectionner une école</DialogTitle>
                      <DialogDescription>
                        Dans quelle école souhaitez-vous ajouter ce sort ?
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4">
                      {elvenSchools.map((school) => (
                        <Button
                          key={school.id}
                          variant="outline"
                          className="w-full justify-start"
                          onClick={() => {
                            setSelectedSchoolId(school.id);
                            setEditingSpell(createNewSpell());
                            setShowSpellDialog(true);
                          }}
                        >
                          <Sparkles className="w-4 h-4 mr-2" />
                          {school.name}
                        </Button>
                      ))}
                    </div>
                  </DialogContent>
                </Dialog>
              )}

              {/* Add Rune Button - Always available */}
              <Button onClick={() => {
                setEditingRune(createNewRune());
                setShowRuneDialog(true);
              }}>
                <Plus className="w-4 h-4 mr-2" />
                <Zap className="w-4 h-4 mr-2" />
                Ajouter une rune
              </Button>

              {/* Create School Button if no schools exist or in edit mode */}
              {(safeCharacter.magic.schools.length === 0 || editMode) && (
                <Button 
                  variant="outline"
                  onClick={() => { 
                    setEditingSchool(createNewSchool()); 
                    setShowSchoolDialog(true); 
                  }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Créer une école
                </Button>
              )}
            </div>

            {/* Search Bar */}
            <div className="flex-1 max-w-sm">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher sorts, runes, écoles..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Affichage:</span>
              <div className="flex gap-1">
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                >
                  <List className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'rich' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('rich')}
                >
                  <Type className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Schools List */}
      <div className="space-y-4">
        {filteredSchoolsAndSpells.map((school) => (
          <Card key={school.id} className="border-l-4 border-l-primary">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleSchoolExpanded(school.id)}
                  >
                    {expandedSchools.includes(school.id) ? 
                      <ChevronDown className="w-4 h-4" /> : 
                      <ChevronRight className="w-4 h-4" />
                    }
                  </Button>
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {school.type === 'elven' ? 
                        <Sparkles className="w-5 h-5 text-purple-500" /> : 
                        <Zap className="w-5 h-5 text-blue-500" />
                      }
                      {school.name}
                      <Badge variant={school.type === 'elven' ? 'default' : 'secondary'}>
                        {school.type === 'elven' ? 'Elfe' : 'Runique'}
                      </Badge>
                    </CardTitle>
                    {school.description && (
                      <CardDescription>{school.description}</CardDescription>
                    )}
                  </div>
                </div>
                
                {editMode && (
                  <div className="flex items-center gap-1">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => { setEditingSchool(school); setShowSchoolDialog(true); }}>
                          <Edit className="w-4 h-4 mr-2" />
                          Modifier
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => exportSchool(school)}>
                          <Download className="w-4 h-4 mr-2" />
                          Exporter
                        </DropdownMenuItem>
                        {school.type === 'elven' && (
                          <DropdownMenuItem onClick={() => handlePasteFromClipboard(school.id)}>
                            <Clipboard className="w-4 h-4 mr-2" />
                            Coller sort(s)
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                              <Trash2 className="w-4 h-4 mr-2" />
                              Supprimer
                            </DropdownMenuItem>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Supprimer l'école</AlertDialogTitle>
                              <AlertDialogDescription>
                                Êtes-vous sûr de vouloir supprimer l'école "{school.name}" ? Cette action est irréversible.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Annuler</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteSchool(school.id)}>
                                Supprimer
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                )}
              </div>
            </CardHeader>
            
            <Collapsible open={expandedSchools.includes(school.id)}>
              <CollapsibleContent>
                <CardContent>
                  {school.type === 'elven' && (
                    <div className="space-y-4">
                      <div className="flex justify-end">
                        <Button
                          size="sm"
                          onClick={() => {
                            setSelectedSchoolId(school.id);
                            setEditingSpell(createNewSpell());
                            setShowSpellDialog(true);
                          }}
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Ajouter un sort
                        </Button>
                      </div>
                      
                      {school.spells && school.spells.length > 0 ? (
                        <div className="grid gap-3">
                          {school.spells.map((spell) => (
                            <Card key={spell.id} className="bg-muted/50">
                              <CardContent className="pt-4">
                                <div className="flex items-start justify-between">
                                  <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-2">
                                      <h4 className="font-medium">{spell.name}</h4>
                                      <Badge variant="outline" className="text-xs">
                                        {spell.activationType}
                                      </Badge>
                                      {spell.tags && spell.tags.length > 0 && (
                                        <div className="flex gap-1">
                                          {spell.tags.map((tag) => (
                                            <Badge key={tag} variant="secondary" className="text-xs">
                                              {tag}
                                            </Badge>
                                          ))}
                                        </div>
                                      )}
                                    </div>
                                    
                                    {viewMode === 'rich' && (
                                      <>
                                        <p className="text-sm text-muted-foreground mb-2">
                                          {spell.description}
                                        </p>
                                        
                                        <div className="grid grid-cols-2 gap-2 text-xs">
                                          {getSpellDisplayFields(spell).map((field, index) => (
                                            <div key={index}>
                                              <span className="font-medium">{field.label}:</span> {field.value}
                                            </div>
                                          ))}
                                        </div>
                                      </>
                                    )}
                                    
                                    <div className="flex items-center gap-2 mt-2">
                                      {spell.costs.map((cost, index) => (
                                        <Badge key={index} variant="outline" className="text-xs">
                                          {cost.context}: {cost.resources.map(r => `${r.amount} ${r.type}`).join(', ')}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                  
                                  <div className="flex items-center gap-1 ml-4">
                                    <Button
                                      size="sm"
                                      onClick={() => handleUseMagic(spell, 'spell')}
                                      disabled={!canUseMagic(spell, safeCharacter).canUse}
                                    >
                                      <Play className="w-3 h-3 mr-1" />
                                      Utiliser
                                    </Button>
                                    
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => {
                                        try {
                                          const serializedSpell = serializeSpell(spell);
                                          copyToClipboard(serializedSpell);
                                          toast.success('Sort copié !');
                                        } catch (error) {
                                          console.error('Erreur lors de la copie du sort:', error);
                                          toast.error('Erreur lors de la copie');
                                        }
                                      }}
                                      title="Copier ce sort"
                                    >
                                      <Copy className="w-3 h-3" />
                                    </Button>

                                    {editMode && (
                                      <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                          <Button variant="ghost" size="sm">
                                            <MoreVertical className="w-3 h-3" />
                                          </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent>
                                          <DropdownMenuItem onClick={() => {
                                            setSelectedSchoolId(school.id);
                                            setEditingSpell(spell);
                                            setShowSpellDialog(true);
                                          }}>
                                            <Edit className="w-3 h-3 mr-2" />
                                            Modifier
                                          </DropdownMenuItem>
                                          <DropdownMenuItem onClick={() => exportSpell(spell, school.name)}>
                                            <Download className="w-3 h-3 mr-2" />
                                            Exporter
                                          </DropdownMenuItem>
                                          <DropdownMenuItem onClick={() => {
                                            const newSpell = { ...spell, id: crypto.randomUUID() };
                                            setSelectedSchoolId(school.id);
                                            setEditingSpell(newSpell);
                                            setShowSpellDialog(true);
                                          }}>
                                            <Copy className="w-3 h-3 mr-2" />
                                            Dupliquer
                                          </DropdownMenuItem>
                                          <DropdownMenuSeparator />
                                          <AlertDialog>
                                            <AlertDialogTrigger asChild>
                                              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                                <Trash2 className="w-3 h-3 mr-2" />
                                                Supprimer
                                              </DropdownMenuItem>
                                            </AlertDialogTrigger>
                                            <AlertDialogContent>
                                              <AlertDialogHeader>
                                                <AlertDialogTitle>Supprimer le sort</AlertDialogTitle>
                                                <AlertDialogDescription>
                                                  Êtes-vous sûr de vouloir supprimer le sort "{spell.name}" ?
                                                </AlertDialogDescription>
                                              </AlertDialogHeader>
                                              <AlertDialogFooter>
                                                <AlertDialogCancel>Annuler</AlertDialogCancel>
                                                <AlertDialogAction onClick={() => handleDeleteSpell(spell.id, school.id)}>
                                                  Supprimer
                                                </AlertDialogAction>
                                              </AlertDialogFooter>
                                            </AlertDialogContent>
                                          </AlertDialog>
                                        </DropdownMenuContent>
                                      </DropdownMenu>
                                    )}
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-4">
                          <Book className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                          <p className="text-sm text-muted-foreground mb-4">Aucun sort dans cette école</p>
                          <Button 
                            variant="outline"
                            onClick={() => {
                              setSelectedSchoolId(school.id);
                              setEditingSpell(createNewSpell());
                              setShowSpellDialog(true);
                            }}
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Ajouter le premier sort
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {school.type === 'runic' && (
                    <div className="space-y-4">
                      <div className="flex justify-end">
                        <Button
                          size="sm"
                          onClick={() => {
                            setEditingRune(createNewRune());
                            setShowRuneDialog(true);
                          }}
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Ajouter une rune
                        </Button>
                      </div>
                      
                      {school.baseRunes && school.baseRunes.length > 0 ? (
                        <div className="space-y-3">
                          {school.baseRunes.map((rune) => (
                            <Card key={rune.id} className="bg-muted/50">
                              <CardHeader>
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => toggleRuneExpanded(rune.id)}
                                    >
                                      {expandedRunes.includes(rune.id) ? 
                                        <ChevronDown className="w-4 h-4" /> : 
                                        <ChevronRight className="w-4 h-4" />
                                      }
                                    </Button>
                                    <div>
                                      <h5 className="font-medium">{rune.code} - {rune.name}</h5>
                                      {viewMode === 'rich' && (
                                        <p className="text-sm text-muted-foreground">{rune.description}</p>
                                      )}
                                    </div>
                                  </div>
                                  
                                  {editMode && (
                                    <DropdownMenu>
                                      <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" size="sm">
                                          <MoreVertical className="w-4 h-4" />
                                        </Button>
                                      </DropdownMenuTrigger>
                                      <DropdownMenuContent>
                                        <DropdownMenuItem onClick={() => {
                                          setEditingRune(rune);
                                          setShowRuneDialog(true);
                                        }}>
                                          <Edit className="w-4 h-4 mr-2" />
                                          Modifier
                                        </DropdownMenuItem>
                                        <DropdownMenuSeparator />
                                        <AlertDialog>
                                          <AlertDialogTrigger asChild>
                                            <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                              <Trash2 className="w-4 h-4 mr-2" />
                                              Supprimer
                                            </DropdownMenuItem>
                                          </AlertDialogTrigger>
                                          <AlertDialogContent>
                                            <AlertDialogHeader>
                                              <AlertDialogTitle>Supprimer la rune</AlertDialogTitle>
                                              <AlertDialogDescription>
                                                Êtes-vous sûr de vouloir supprimer la rune "{rune.name}" ?
                                              </AlertDialogDescription>
                                            </AlertDialogHeader>
                                            <AlertDialogFooter>
                                              <AlertDialogCancel>Annuler</AlertDialogCancel>
                                              <AlertDialogAction onClick={() => handleDeleteRune(rune.id)}>
                                                Supprimer
                                              </AlertDialogAction>
                                            </AlertDialogFooter>
                                          </AlertDialogContent>
                                        </AlertDialog>
                                      </DropdownMenuContent>
                                    </DropdownMenu>
                                  )}
                                </div>
                              </CardHeader>
                              
                              <Collapsible open={expandedRunes.includes(rune.id)}>
                                <CollapsibleContent>
                                  <CardContent>
                                    <Tabs defaultValue="quick">
                                      <TabsList className="grid w-full grid-cols-2">
                                        <TabsTrigger value="quick">Pouvoirs Rapides ({rune.quickPowers.length})</TabsTrigger>
                                        <TabsTrigger value="lasting">Pouvoirs Durables ({rune.lastingPowers.length})</TabsTrigger>
                                      </TabsList>
                                      
                                      <TabsContent value="quick" className="space-y-3 mt-4">
                                        <div className="flex justify-end">
                                          <Button
                                            size="sm"
                                            onClick={() => {
                                              setSelectedRuneId(rune.id);
                                              setEditingPowerType('quick');
                                              setEditingPower(createNewPower());
                                              setShowPowerDialog(true);
                                            }}
                                          >
                                            <Plus className="w-4 h-4 mr-2" />
                                            Ajouter
                                          </Button>
                                        </div>
                                        
                                        {rune.quickPowers.length > 0 ? (
                                          rune.quickPowers.map((power) => (
                                            <Card key={power.id} className="bg-background/50">
                                              <CardContent className="pt-4">
                                                <div className="flex items-start justify-between">
                                                  <div className="flex-1">
                                                    <div className="flex items-center gap-2 mb-2">
                                                      <h6 className="font-medium">{power.name}</h6>
                                                      <Badge variant="outline" className="text-xs">
                                                        {power.activationType}
                                                      </Badge>
                                                    </div>
                                                    
                                                    {viewMode === 'rich' && (
                                                      <>
                                                        <p className="text-sm text-muted-foreground mb-2">
                                                          {power.description}
                                                        </p>
                                                        
                                                        <div className="grid grid-cols-2 gap-2 text-xs">
                                                          {getPowerDisplayFields(power).map((field, index) => (
                                                            <div key={index}>
                                                              <span className="font-medium">{field.label}:</span> {field.value}
                                                            </div>
                                                          ))}
                                                        </div>
                                                      </>
                                                    )}
                                                    
                                                    <div className="flex items-center gap-2 mt-2">
                                                      {power.costs.map((cost, index) => (
                                                        <Badge key={index} variant="outline" className="text-xs">
                                                          {cost.context}: {cost.resources.map(r => `${r.amount} ${r.type}`).join(', ')}
                                                        </Badge>
                                                      ))}
                                                    </div>
                                                  </div>
                                                  
                                                  <div className="flex items-center gap-1 ml-4">
                                                    <Button
                                                      size="sm"
                                                      onClick={() => handleUseMagic(power, 'power')}
                                                      disabled={!canUseMagic(power, safeCharacter).canUse}
                                                    >
                                                      <Play className="w-3 h-3 mr-1" />
                                                      Utiliser
                                                    </Button>
                                                    
                                                    {editMode && (
                                                      <DropdownMenu>
                                                        <DropdownMenuTrigger asChild>
                                                          <Button variant="ghost" size="sm">
                                                            <MoreVertical className="w-3 h-3" />
                                                          </Button>
                                                        </DropdownMenuTrigger>
                                                        <DropdownMenuContent>
                                                          <DropdownMenuItem onClick={() => {
                                                            setSelectedRuneId(rune.id);
                                                            setEditingPowerType('quick');
                                                            setEditingPower(power);
                                                            setShowPowerDialog(true);
                                                          }}>
                                                            <Edit className="w-3 h-3 mr-2" />
                                                            Modifier
                                                          </DropdownMenuItem>
                                                          <DropdownMenuItem onClick={() => {
                                                            const newPower = { ...power, id: crypto.randomUUID() };
                                                            setSelectedRuneId(rune.id);
                                                            setEditingPowerType('quick');
                                                            setEditingPower(newPower);
                                                            setShowPowerDialog(true);
                                                          }}>
                                                            <Copy className="w-3 h-3 mr-2" />
                                                            Dupliquer
                                                          </DropdownMenuItem>
                                                          <DropdownMenuSeparator />
                                                          <AlertDialog>
                                                            <AlertDialogTrigger asChild>
                                                              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                                                <Trash2 className="w-3 h-3 mr-2" />
                                                                Supprimer
                                                              </DropdownMenuItem>
                                                            </AlertDialogTrigger>
                                                            <AlertDialogContent>
                                                              <AlertDialogHeader>
                                                                <AlertDialogTitle>Supprimer le pouvoir</AlertDialogTitle>
                                                                <AlertDialogDescription>
                                                                  Êtes-vous sûr de vouloir supprimer le pouvoir "{power.name}" ?
                                                                </AlertDialogDescription>
                                                              </AlertDialogHeader>
                                                              <AlertDialogFooter>
                                                                <AlertDialogCancel>Annuler</AlertDialogCancel>
                                                                <AlertDialogAction onClick={() => {
                                                                  setSelectedRuneId(rune.id);
                                                                  handleDeletePower(power.id, 'quick');
                                                                }}>
                                                                  Supprimer
                                                                </AlertDialogAction>
                                                              </AlertDialogFooter>
                                                            </AlertDialogContent>
                                                          </AlertDialog>
                                                        </DropdownMenuContent>
                                                      </DropdownMenu>
                                                    )}
                                                  </div>
                                                </div>
                                              </CardContent>
                                            </Card>
                                          ))
                                        ) : (
                                          <div className="text-center py-4">
                                            <Clock className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                                            <p className="text-sm text-muted-foreground mb-4">Aucun pouvoir rapide</p>
                                            <Button
                                              variant="outline"
                                              onClick={() => {
                                                setSelectedRuneId(rune.id);
                                                setEditingPowerType('quick');
                                                setEditingPower(createNewPower());
                                                setShowPowerDialog(true);
                                              }}
                                            >
                                              <Plus className="w-4 h-4 mr-2" />
                                              Ajouter le premier pouvoir rapide
                                            </Button>
                                          </div>
                                        )}
                                      </TabsContent>
                                      
                                      <TabsContent value="lasting" className="space-y-3 mt-4">
                                        <div className="flex justify-end">
                                          <Button
                                            size="sm"
                                            onClick={() => {
                                              setSelectedRuneId(rune.id);
                                              setEditingPowerType('lasting');
                                              setEditingPower(createNewPower());
                                              setShowPowerDialog(true);
                                            }}
                                          >
                                            <Plus className="w-4 h-4 mr-2" />
                                            Ajouter
                                          </Button>
                                        </div>
                                        
                                        {rune.lastingPowers.length > 0 ? (
                                          rune.lastingPowers.map((power) => (
                                            <Card key={power.id} className="bg-background/50">
                                              <CardContent className="pt-4">
                                                <div className="flex items-start justify-between">
                                                  <div className="flex-1">
                                                    <div className="flex items-center gap-2 mb-2">
                                                      <h6 className="font-medium">{power.name}</h6>
                                                      <Badge variant="outline" className="text-xs">
                                                        {power.activationType}
                                                      </Badge>
                                                    </div>
                                                    
                                                    {viewMode === 'rich' && (
                                                      <>
                                                        <p className="text-sm text-muted-foreground mb-2">
                                                          {power.description}
                                                        </p>
                                                        
                                                        <div className="grid grid-cols-2 gap-2 text-xs">
                                                          {getPowerDisplayFields(power).map((field, index) => (
                                                            <div key={index}>
                                                              <span className="font-medium">{field.label}:</span> {field.value}
                                                            </div>
                                                          ))}
                                                        </div>
                                                      </>
                                                    )}
                                                    
                                                    <div className="flex items-center gap-2 mt-2">
                                                      {power.costs.map((cost, index) => (
                                                        <Badge key={index} variant="outline" className="text-xs">
                                                          {cost.context}: {cost.resources.map(r => `${r.amount} ${r.type}`).join(', ')}
                                                        </Badge>
                                                      ))}
                                                    </div>
                                                  </div>
                                                  
                                                  <div className="flex items-center gap-1 ml-4">
                                                    <Button
                                                      size="sm"
                                                      onClick={() => handleUseMagic(power, 'power')}
                                                      disabled={!canUseMagic(power, safeCharacter).canUse}
                                                    >
                                                      <Play className="w-3 h-3 mr-1" />
                                                      Utiliser
                                                    </Button>
                                                    
                                                    {editMode && (
                                                      <DropdownMenu>
                                                        <DropdownMenuTrigger asChild>
                                                          <Button variant="ghost" size="sm">
                                                            <MoreVertical className="w-3 h-3" />
                                                          </Button>
                                                        </DropdownMenuTrigger>
                                                        <DropdownMenuContent>
                                                          <DropdownMenuItem onClick={() => {
                                                            setSelectedRuneId(rune.id);
                                                            setEditingPowerType('lasting');
                                                            setEditingPower(power);
                                                            setShowPowerDialog(true);
                                                          }}>
                                                            <Edit className="w-3 h-3 mr-2" />
                                                            Modifier
                                                          </DropdownMenuItem>
                                                          <DropdownMenuItem onClick={() => {
                                                            const newPower = { ...power, id: crypto.randomUUID() };
                                                            setSelectedRuneId(rune.id);
                                                            setEditingPowerType('lasting');
                                                            setEditingPower(newPower);
                                                            setShowPowerDialog(true);
                                                          }}>
                                                            <Copy className="w-3 h-3 mr-2" />
                                                            Dupliquer
                                                          </DropdownMenuItem>
                                                          <DropdownMenuSeparator />
                                                          <AlertDialog>
                                                            <AlertDialogTrigger asChild>
                                                              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                                                <Trash2 className="w-3 h-3 mr-2" />
                                                                Supprimer
                                                              </DropdownMenuItem>
                                                            </AlertDialogTrigger>
                                                            <AlertDialogContent>
                                                              <AlertDialogHeader>
                                                                <AlertDialogTitle>Supprimer le pouvoir</AlertDialogTitle>
                                                                <AlertDialogDescription>
                                                                  Êtes-vous sûr de vouloir supprimer le pouvoir "{power.name}" ?
                                                                </AlertDialogDescription>
                                                              </AlertDialogHeader>
                                                              <AlertDialogFooter>
                                                                <AlertDialogCancel>Annuler</AlertDialogCancel>
                                                                <AlertDialogAction onClick={() => {
                                                                  setSelectedRuneId(rune.id);
                                                                  handleDeletePower(power.id, 'lasting');
                                                                }}>
                                                                  Supprimer
                                                                </AlertDialogAction>
                                                              </AlertDialogFooter>
                                                            </AlertDialogContent>
                                                          </AlertDialog>
                                                        </DropdownMenuContent>
                                                      </DropdownMenu>
                                                    )}
                                                  </div>
                                                </div>
                                              </CardContent>
                                            </Card>
                                          ))
                                        ) : (
                                          <div className="text-center py-4">
                                            <Target className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                                            <p className="text-sm text-muted-foreground mb-4">Aucun pouvoir durable</p>
                                            <Button
                                              variant="outline"
                                              onClick={() => {
                                                setSelectedRuneId(rune.id);
                                                setEditingPowerType('lasting');
                                                setEditingPower(createNewPower());
                                                setShowPowerDialog(true);
                                              }}
                                            >
                                              <Plus className="w-4 h-4 mr-2" />
                                              Ajouter le premier pouvoir durable
                                            </Button>
                                          </div>
                                        )}
                                      </TabsContent>
                                    </Tabs>
                                  </CardContent>
                                </CollapsibleContent>
                              </Collapsible>
                            </Card>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-4">
                          <Zap className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                          <p className="text-sm text-muted-foreground mb-4">Aucune rune dans cette école</p>
                          <Button
                            variant="outline"
                            onClick={() => {
                              setEditingRune(createNewRune());
                              setShowRuneDialog(true);
                            }}
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Ajouter la première rune
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        ))}
      </div>

      {/* Spell Dialog */}
      <Dialog open={showSpellDialog} onOpenChange={setShowSpellDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>
              {editingSpell?.id && selectedSchoolId ? 'Modifier le sort' : 'Nouveau sort'}
            </DialogTitle>
            <DialogDescription>
              Créez ou modifiez un sort
            </DialogDescription>
          </DialogHeader>
          
          {editingSpell && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="spell-name">Nom du sort</Label>
                  <Input
                    id="spell-name"
                    value={editingSpell.name}
                    onChange={(e) => setEditingSpell({ ...editingSpell, name: e.target.value })}
                    placeholder="Nom du sort"
                  />
                </div>
                
                <div>
                  <Label htmlFor="spell-activation">Type d'activation</Label>
                  <Select
                    value={editingSpell.activationType}
                    onValueChange={(value: 'action' | 'bonus' | 'reaction' | 'free' | 'ritual') => 
                      setEditingSpell({ ...editingSpell, activationType: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="action">Action</SelectItem>
                      <SelectItem value="bonus">Action bonus</SelectItem>
                      <SelectItem value="reaction">Réaction</SelectItem>
                      <SelectItem value="free">Action libre</SelectItem>
                      <SelectItem value="ritual">Rituel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="spell-description">Description</Label>
                <Textarea
                  id="spell-description"
                  value={editingSpell.description}
                  onChange={(e) => setEditingSpell({ ...editingSpell, description: e.target.value })}
                  placeholder="Description du sort..."
                  rows={4}
                />
              </div>
              
              <SpellCostEditor
                costs={editingSpell.costs}
                onChange={(costs) => setEditingSpell({ ...editingSpell, costs })}
              />
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="spell-range">Portée</Label>
                  <Input
                    id="spell-range"
                    value={editingSpell.range || ''}
                    onChange={(e) => setEditingSpell({ ...editingSpell, range: e.target.value })}
                    placeholder="Contact, 30m..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="spell-duration">Durée</Label>
                  <Input
                    id="spell-duration"
                    value={editingSpell.duration || ''}
                    onChange={(e) => setEditingSpell({ ...editingSpell, duration: e.target.value })}
                    placeholder="Instantané, 1 heure..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="spell-scaling">Amélioration</Label>
                  <Input
                    id="spell-scaling"
                    value={editingSpell.scaling || ''}
                    onChange={(e) => setEditingSpell({ ...editingSpell, scaling: e.target.value })}
                    placeholder="PM supplémentaires..."
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="spell-tags">Tags (séparés par des virgules)</Label>
                <Input
                  id="spell-tags"
                  value={editingSpell.tags?.join(', ') || ''}
                  onChange={(e) => setEditingSpell({ 
                    ...editingSpell, 
                    tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag) 
                  })}
                  placeholder="feu, dégâts, zone..."
                />
              </div>
              
              <div>
                <Label htmlFor="spell-prerequisites">Prérequis</Label>
                <Input
                  id="spell-prerequisites"
                  value={editingSpell.prerequisites || ''}
                  onChange={(e) => setEditingSpell({ ...editingSpell, prerequisites: e.target.value })}
                  placeholder="Niveau 3, École de Feu..."
                />
              </div>
              
              <div>
                <Label htmlFor="spell-limitations">Limitations</Label>
                <Textarea
                  id="spell-limitations"
                  value={editingSpell.limitations || ''}
                  onChange={(e) => setEditingSpell({ ...editingSpell, limitations: e.target.value })}
                  placeholder="Une fois par jour, ligne de vue..."
                  rows={2}
                />
              </div>
            </div>
          )}
          
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setShowSpellDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleSaveSpell}>
              Sauvegarder
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Rune Dialog */}
      <Dialog open={showRuneDialog} onOpenChange={setShowRuneDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>
              {editingRune?.id ? 'Modifier la rune' : 'Nouvelle rune'}
            </DialogTitle>
            <DialogDescription>
              Créez ou modifiez une rune de base
            </DialogDescription>
          </DialogHeader>
          
          {editingRune && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="rune-code">Code de la rune</Label>
                  <Input
                    id="rune-code"
                    value={editingRune.code}
                    onChange={(e) => setEditingRune({ ...editingRune, code: e.target.value })}
                    placeholder="Ea, Vérit, Illusio..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="rune-name">Nom</Label>
                  <Input
                    id="rune-name"
                    value={editingRune.name}
                    onChange={(e) => setEditingRune({ ...editingRune, name: e.target.value })}
                    placeholder="Nom de la rune"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="rune-description">Description</Label>
                <Textarea
                  id="rune-description"
                  value={editingRune.description}
                  onChange={(e) => setEditingRune({ ...editingRune, description: e.target.value })}
                  placeholder="Description de la rune..."
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="rune-mastery">Maîtrise (%)</Label>
                <Input
                  id="rune-mastery"
                  type="number"
                  min="0"
                  max="100"
                  value={editingRune.masteryPercentage || 0}
                  onChange={(e) => setEditingRune({ 
                    ...editingRune, 
                    masteryPercentage: parseInt(e.target.value) || 0 
                  })}
                />
              </div>
            </div>
          )}
          
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setShowRuneDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleSaveRune}>
              Sauvegarder
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Power Dialog */}
      <Dialog open={showPowerDialog} onOpenChange={setShowPowerDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>
              {editingPower?.id && selectedRuneId ? 'Modifier le pouvoir' : 'Nouveau pouvoir'}
            </DialogTitle>
            <DialogDescription>
              Créez ou modifiez un pouvoir {editingPowerType === 'quick' ? 'rapide' : 'durable'}
            </DialogDescription>
          </DialogHeader>
          
          {editingPower && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="power-name">Nom du pouvoir</Label>
                  <Input
                    id="power-name"
                    value={editingPower.name}
                    onChange={(e) => setEditingPower({ ...editingPower, name: e.target.value })}
                    placeholder="Nom du pouvoir"
                  />
                </div>
                
                <div>
                  <Label htmlFor="power-activation">Type d'activation</Label>
                  <Select
                    value={editingPower.activationType}
                    onValueChange={(value: 'action' | 'bonus' | 'reaction' | 'free' | 'ritual') => 
                      setEditingPower({ ...editingPower, activationType: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="action">Action</SelectItem>
                      <SelectItem value="bonus">Action bonus</SelectItem>
                      <SelectItem value="reaction">Réaction</SelectItem>
                      <SelectItem value="free">Action libre</SelectItem>
                      <SelectItem value="ritual">Rituel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="power-description">Description</Label>
                <Textarea
                  id="power-description"
                  value={editingPower.description}
                  onChange={(e) => setEditingPower({ ...editingPower, description: e.target.value })}
                  placeholder="Description du pouvoir..."
                  rows={4}
                />
              </div>
              
              <SpellCostEditor
                costs={editingPower.costs}
                onChange={(costs) => setEditingPower({ ...editingPower, costs })}
              />
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="power-range">Portée</Label>
                  <Input
                    id="power-range"
                    value={editingPower.range || ''}
                    onChange={(e) => setEditingPower({ ...editingPower, range: e.target.value })}
                    placeholder="Contact, 30m..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="power-duration">Durée</Label>
                  <Input
                    id="power-duration"
                    value={editingPower.duration || ''}
                    onChange={(e) => setEditingPower({ ...editingPower, duration: e.target.value })}
                    placeholder="Instantané, 1 heure..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="power-scaling">Amélioration</Label>
                  <Input
                    id="power-scaling"
                    value={editingPower.scaling || ''}
                    onChange={(e) => setEditingPower({ ...editingPower, scaling: e.target.value })}
                    placeholder="PM supplémentaires..."
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="power-prerequisites">Prérequis</Label>
                <Input
                  id="power-prerequisites"
                  value={editingPower.prerequisites || ''}
                  onChange={(e) => setEditingPower({ ...editingPower, prerequisites: e.target.value })}
                  placeholder="Maîtrise 50%, combinaison avec..."
                />
              </div>
              
              <div>
                <Label htmlFor="power-limitations">Limitations</Label>
                <Textarea
                  id="power-limitations"
                  value={editingPower.limitations || ''}
                  onChange={(e) => setEditingPower({ ...editingPower, limitations: e.target.value })}
                  placeholder="Une fois par jour, ligne de vue..."
                  rows={2}
                />
              </div>
            </div>
          )}
          
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setShowPowerDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleSavePower}>
              Sauvegarder
            </Button>
          </div>
        </DialogContent>
      </Dialog>


      {/* Paste Spell Confirmation Dialog */}
      <Dialog open={showPasteSpellDialog} onOpenChange={setShowPasteSpellDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer l'ajout de sort</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir ajouter ce sort ?
            </DialogDescription>
          </DialogHeader>
          
          {pastedSpell && (
            <div className="bg-muted p-4 rounded-lg space-y-2">
              <div className="grid grid-cols-[120px_1fr] gap-2 text-sm">
                <span className="font-medium">Nom :</span>
                <span>{pastedSpell.name}</span>
                
                <span className="font-medium">Niveau :</span>
                <span>{pastedSpell.level}</span>
                
                <span className="font-medium">Activation :</span>
                <span>{pastedSpell.activationType}</span>
                
                <span className="font-medium">Description :</span>
                <span className="text-xs">{pastedSpell.description}</span>
              </div>
            </div>
          )}
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowPasteSpellDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleConfirmPasteSpell}>
              <Sparkles className="w-4 h-4 mr-2" />
              Créer le sort
            </Button>
          </div>
        </DialogContent>
      </Dialog>

    </div>
  );
}