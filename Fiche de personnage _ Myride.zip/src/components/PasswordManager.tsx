import { useState } from 'react';
import { Lock, Unlock } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { toast } from 'sonner@2.0.3';
import type { Character } from '../types/game';

interface PasswordManagerProps {
  character: Character;
  onUpdateCharacter: (character: Character) => void;
}

export const PasswordManager = ({ character, onUpdateCharacter }: PasswordManagerProps) => {
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState('');
  const [confirmCode, setConfirmCode] = useState('');
  const [newCode, setNewCode] = useState('');
  const [confirmNewCode, setConfirmNewCode] = useState('');
  const [lockEnabled, setLockEnabled] = useState(character.lock?.enabled || false);

  const isLocked = character.lock?.enabled || false;

  const handleCodeChange = (value: string, setter: (value: string) => void) => {
    // Only allow digits and limit to 4 characters
    const digits = value.replace(/\D/g, '').slice(0, 4);
    setter(digits);
  };

  const validateCode = (code: string): boolean => {
    return /^\d{4}$/.test(code);
  };

  const handleActivate = () => {
    if (!validateCode(code)) {
      toast.error('Le code doit contenir exactement 4 chiffres');
      return;
    }

    if (code !== confirmCode) {
      toast.error('Les codes ne correspondent pas');
      return;
    }

    const updatedCharacter = {
      ...character,
      lock: {
        enabled: true,
        code,
        updatedAt: new Date().toISOString(),
      },
      updatedAt: new Date().toISOString(),
    };

    onUpdateCharacter(updatedCharacter);
    toast.success('Protection par code activée');
    setOpen(false);
    resetFields();
  };

  const handleUpdate = () => {
    if (lockEnabled) {
      // Updating or staying enabled
      if (!validateCode(newCode)) {
        toast.error('Le nouveau code doit contenir exactement 4 chiffres');
        return;
      }

      if (newCode !== confirmNewCode) {
        toast.error('Les nouveaux codes ne correspondent pas');
        return;
      }

      const updatedCharacter = {
        ...character,
        lock: {
          enabled: true,
          code: newCode,
          updatedAt: new Date().toISOString(),
        },
        updatedAt: new Date().toISOString(),
      };

      onUpdateCharacter(updatedCharacter);
      toast.success('Code mis à jour');
    } else {
      // Disabling lock
      const updatedCharacter = {
        ...character,
        lock: {
          enabled: false,
          code: character.lock?.code || '',
          updatedAt: new Date().toISOString(),
        },
        updatedAt: new Date().toISOString(),
      };

      onUpdateCharacter(updatedCharacter);
      toast.success('Protection par code désactivée');
    }

    setOpen(false);
    resetFields();
  };

  const resetFields = () => {
    setCode('');
    setConfirmCode('');
    setNewCode('');
    setConfirmNewCode('');
    setLockEnabled(character.lock?.enabled || false);
  };

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
    if (!newOpen) {
      resetFields();
    } else {
      setLockEnabled(character.lock?.enabled || false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          {isLocked ? <Lock className="w-4 h-4 mr-2" /> : <Unlock className="w-4 h-4 mr-2" />}
          Mot de passe
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle>
            {!isLocked ? 'Protéger cette fiche par code (4 chiffres)' : 'Modifier ou désactiver le code'}
          </DialogTitle>
          <DialogDescription>
            {!isLocked 
              ? 'Créez un code à 4 chiffres pour protéger l\'accès à cette fiche.'
              : 'Modifiez le code ou désactivez la protection.'
            }
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {!isLocked ? (
            // First time setup
            <>
              <div>
                <Label htmlFor="code">Code (4 chiffres)</Label>
                <Input
                  id="code"
                  type="password"
                  inputMode="numeric"
                  value={code}
                  onChange={(e) => handleCodeChange(e.target.value, setCode)}
                  placeholder="••••"
                  maxLength={4}
                  className="text-center tracking-wider"
                />
              </div>
              
              <div>
                <Label htmlFor="confirm-code">Confirmer le code</Label>
                <Input
                  id="confirm-code"
                  type="password"
                  inputMode="numeric"
                  value={confirmCode}
                  onChange={(e) => handleCodeChange(e.target.value, setConfirmCode)}
                  placeholder="••••"
                  maxLength={4}
                  className="text-center tracking-wider"
                />
              </div>
            </>
          ) : (
            // Modify existing lock
            <>
              <div className="flex items-center space-x-2">
                <Switch
                  id="lock-enabled"
                  checked={lockEnabled}
                  onCheckedChange={setLockEnabled}
                />
                <Label htmlFor="lock-enabled">Activer la protection</Label>
              </div>

              {lockEnabled && (
                <>
                  <div>
                    <Label htmlFor="new-code">Nouveau code (4 chiffres)</Label>
                    <Input
                      id="new-code"
                      type="password"
                      inputMode="numeric"
                      value={newCode}
                      onChange={(e) => handleCodeChange(e.target.value, setNewCode)}
                      placeholder="••••"
                      maxLength={4}
                      className="text-center tracking-wider"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="confirm-new-code">Confirmer le nouveau code</Label>
                    <Input
                      id="confirm-new-code"
                      type="password"
                      inputMode="numeric"
                      value={confirmNewCode}
                      onChange={(e) => handleCodeChange(e.target.value, setConfirmNewCode)}
                      placeholder="••••"
                      maxLength={4}
                      className="text-center tracking-wider"
                    />
                  </div>
                </>
              )}
            </>
          )}
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Annuler
          </Button>
          <Button 
            onClick={!isLocked ? handleActivate : handleUpdate}
            disabled={
              !isLocked 
                ? !code || !confirmCode || code !== confirmCode || !validateCode(code)
                : lockEnabled && (!newCode || !confirmNewCode || newCode !== confirmNewCode || !validateCode(newCode))
            }
          >
            {!isLocked ? 'Activer' : 'Enregistrer'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};