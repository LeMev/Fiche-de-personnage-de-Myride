import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import type { Character } from '../types/game';
import { Shield, Calculator, Settings, Info } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface TotalArmorManagerProps {
  character: Character;
  editMode: boolean;
  onUpdateCharacter: (character: Character) => void;
}

export function TotalArmorManager({ character, editMode, onUpdateCharacter }: TotalArmorManagerProps) {
  const [showArmorDialog, setShowArmorDialog] = useState(false);

  const calculateAutoArmor = () => {
    let totalArmor = 0;

    // Sum equipped armor items
    character.inventory.items.forEach(item => {
      if (item.equipped && item.armorBonus) {
        totalArmor += item.armorBonus;
      }
    });

    // Add armor bonuses from abilities (if any ability provides armor bonus)
    character.abilities.forEach(ability => {
      if (ability.type === 'passive' && ability.effects) {
        const armorMatch = ability.effects.match(/\+(\d+)\s*armure?/i);
        if (armorMatch) {
          totalArmor += parseInt(armorMatch[1], 10);
        }
      }
    });

    return totalArmor;
  };

  const getCurrentArmor = () => {
    if (character.resources.armorAutocalcEnabled) {
      return calculateAutoArmor();
    }
    return character.resources.armorManualValue || 0;
  };

  const toggleAutocalc = (enabled: boolean) => {
    const updatedCharacter = {
      ...character,
      resources: {
        ...character.resources,
        armorAutocalcEnabled: enabled,
        totalArmor: enabled ? calculateAutoArmor() : (character.resources.armorManualValue || 0),
      },
      updatedAt: new Date().toISOString(),
    };

    onUpdateCharacter(updatedCharacter);
    toast.success(`Calcul automatique ${enabled ? 'activé' : 'désactivé'}`);
  };

  const updateManualArmor = (value: number) => {
    const updatedCharacter = {
      ...character,
      resources: {
        ...character.resources,
        armorManualValue: value,
        totalArmor: character.resources.armorAutocalcEnabled ? calculateAutoArmor() : value,
      },
      updatedAt: new Date().toISOString(),
    };

    onUpdateCharacter(updatedCharacter);
  };

  const getArmorBreakdown = () => {
    const breakdown = [];
    let equippedArmorTotal = 0;
    let abilityArmorTotal = 0;

    // Equipped armor items
    character.inventory.items.forEach(item => {
      if (item.equipped && item.armorBonus) {
        breakdown.push({
          source: `${item.name} (équipé)`,
          value: item.armorBonus,
          type: 'equipment'
        });
        equippedArmorTotal += item.armorBonus;
      }
    });

    // Armor bonuses from abilities
    character.abilities.forEach(ability => {
      if (ability.type === 'passive' && ability.effects) {
        const armorMatch = ability.effects.match(/\+(\d+)\s*armure?/i);
        if (armorMatch) {
          const bonus = parseInt(armorMatch[1], 10);
          breakdown.push({
            source: `${ability.name} (capacité)`,
            value: bonus,
            type: 'ability'
          });
          abilityArmorTotal += bonus;
        }
      }
    });

    return { breakdown, equippedArmorTotal, abilityArmorTotal };
  };

  const currentArmor = getCurrentArmor();
  const { breakdown } = getArmorBreakdown();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label className="text-base font-medium">Armure totale</Label>
        {editMode && (
          <Dialog open={showArmorDialog} onOpenChange={setShowArmorDialog}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Configuration de l'Armure</DialogTitle>
                <DialogDescription>
                  Configurez le mode de calcul de l'armure totale
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="armor-autocalc"
                    checked={character.resources.armorAutocalcEnabled}
                    onCheckedChange={toggleAutocalc}
                  />
                  <Label htmlFor="armor-autocalc">Calcul automatique</Label>
                </div>
                
                {character.resources.armorAutocalcEnabled ? (
                  <div className="space-y-3">
                    <div className="p-3 bg-muted rounded">
                      <div className="flex items-center gap-2 mb-2">
                        <Calculator className="w-4 h-4" />
                        <span className="text-sm font-medium">Calcul automatique activé</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        L'armure est calculée automatiquement en fonction de votre équipement et de vos capacités.
                      </p>
                    </div>
                    
                    {breakdown.length > 0 && (
                      <div className="space-y-2">
                        <Label className="text-sm">Détail du calcul :</Label>
                        {breakdown.map((item, index) => (
                          <div key={index} className="flex justify-between text-sm">
                            <span>{item.source}</span>
                            <span className="font-mono">+{item.value}</span>
                          </div>
                        ))}
                        <Separator />
                        <div className="flex justify-between font-medium">
                          <span>Total</span>
                          <span className="font-mono">{currentArmor}</span>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="p-3 bg-muted rounded">
                      <div className="flex items-center gap-2 mb-2">
                        <Info className="w-4 h-4" />
                        <span className="text-sm font-medium">Saisie manuelle</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Vous pouvez définir manuellement la valeur d'armure totale.
                      </p>
                    </div>
                    
                    <div>
                      <Label htmlFor="manual-armor">Armure totale</Label>
                      <Input
                        id="manual-armor"
                        type="number"
                        min="0"
                        value={character.resources.armorManualValue || 0}
                        onChange={(e) => updateManualArmor(parseInt(e.target.value) || 0)}
                        className="text-center"
                      />
                    </div>
                  </div>
                )}
                
                <div className="flex justify-end pt-4">
                  <Button onClick={() => setShowArmorDialog(false)}>
                    Fermer
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      <div className="flex items-center gap-3">
        <Shield className="w-5 h-5 text-muted-foreground" />
        <div className="flex-1">
          <div className="text-2xl font-bold font-mono">
            {currentArmor}
          </div>
          {character.resources.armorAutocalcEnabled && (
            <div className="text-xs text-muted-foreground">
              Auto-calculé
            </div>
          )}
        </div>
        
        {!editMode && breakdown.length > 0 && (
          <div className="text-xs text-muted-foreground text-right">
            {breakdown.length} source{breakdown.length !== 1 ? 's' : ''}
          </div>
        )}
      </div>
    </div>
  );
}