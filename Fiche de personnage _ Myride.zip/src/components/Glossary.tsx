import {
  useState,
  useMemo,
  useCallback,
  useEffect,
  useRef,
} from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Separator } from "./ui/separator";
import {
  Library,
  Search,
  Plus,
  Edit,
  Trash,
  FolderPlus,
  FolderOpen,
  Folder,
  MoreVertical,
  ChevronRight,
  ChevronDown,
  Sparkles,
  FileText,
  Wand2,
  Loader2,
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { ItemEditor } from "./ItemEditor";
import { GlossaryImportExport } from "./GlossaryImportExport";
import {
  PRESET_GLOSSARY_ITEMS,
  DEFAULT_GLOSSARY_FOLDERS,
} from "../constants/glossaryConstants";
import { useVirtualizer } from "@tanstack/react-virtual";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "./ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";
import { Checkbox } from "./ui/checkbox";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "./ui/resizable";
import type {
  GlossaryItem,
  GlossaryFolder,
  GlossaryFilterType,
  GlossarySortField,
  Character,
} from "../types/game";
import {
  glossaryItemToAbility,
  glossaryItemToSpell,
} from "../utils/glossaryUtils";
import { GlossaryRepository } from "../data/GlossaryRepository";

interface GlossaryProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preFilterType?: "capacité" | "magie";
  character?: Character;
  onAddToSheet?: (item: GlossaryItem) => void;
}


export function Glossary({
  open,
  onOpenChange,
  preFilterType,
  character,
  onAddToSheet,
}: GlossaryProps) {
  // State management
  const [glossaryItems, setGlossaryItems] = useState<
    GlossaryItem[]
  >(PRESET_GLOSSARY_ITEMS);
  const [folders, setFolders] = useState<GlossaryFolder[]>(
    DEFAULT_GLOSSARY_FOLDERS,
  );
  const [expandedFolders, setExpandedFolders] = useState<
    Set<string>
  >(new Set());
  const [selectedFolderId, setSelectedFolderId] = useState<
    string | null
  >(null);
  const [selectedItemIds, setSelectedItemIds] = useState<
    Set<string>
  >(new Set());
  const [lastSelectedIndex, setLastSelectedIndex] =
    useState<number>(-1);

  // Search & filters
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] =
    useState<GlossaryFilterType>(preFilterType || "all");
  const [filterSchool, setFilterSchool] =
    useState<string>("all");
  const [filterTag, setFilterTag] = useState<string>("all");
  const [sortField, setSortField] =
    useState<GlossarySortField>("name");

  // UI state
  const [showItemEditor, setShowItemEditor] = useState(false);
  const [editingItem, setEditingItem] =
    useState<GlossaryItem | null>(null);
  const [editorDefaultType, setEditorDefaultType] = useState<
    "capacité" | "magie"
  >("capacité");
  const [showDeleteConfirm, setShowDeleteConfirm] =
    useState(false);
  const [itemToDelete, setItemToDelete] = useState<
    string | null
  >(null);
  const [showFolderDialog, setShowFolderDialog] =
    useState(false);
  const [folderName, setFolderName] = useState("");
  const [editingFolderId, setEditingFolderId] = useState<
    string | null
  >(null);
  
  // Persistence state
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Refs
  const listParentRef = useRef<HTMLDivElement>(null);

  // Load glossary data on mount
  useEffect(() => {
    const loadGlossary = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await GlossaryRepository.load();
        setGlossaryItems(data.items);
        setFolders(data.folders);
      } catch (err) {
        console.error('Error loading glossary:', err);
        setError(err instanceof Error ? err.message : 'Erreur lors du chargement du glossaire');
        toast.error('Impossible de charger le glossaire');
      } finally {
        setLoading(false);
      }
    };

    loadGlossary();
  }, []);

  // Reset filter type when dialog opens
  useEffect(() => {
    if (open && preFilterType) {
      setFilterType(preFilterType);
    }
  }, [open, preFilterType]);

  // Keyboard shortcuts
  useEffect(() => {
    if (!open) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Search shortcut (Cmd/Ctrl + K)
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        const searchInput =
          document.querySelector<HTMLInputElement>(
            '[placeholder*="Rechercher"]',
          );
        searchInput?.focus();
        return;
      }

      // Only handle other shortcuts if not typing in an input
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return;
      }

      // Enter: Edit selected item
      if (e.key === "Enter" && selectedItemIds.size === 1) {
        e.preventDefault();
        const item = glossaryItems.find((i) =>
          selectedItemIds.has(i.id),
        );
        if (item) handleEditItem(item);
        return;
      }

      // Delete: Delete selected items
      if (
        (e.key === "Delete" || e.key === "Backspace") &&
        selectedItemIds.size > 0
      ) {
        e.preventDefault();
        handleDeleteSelected();
        return;
      }

      // Escape: Clear selection
      if (e.key === "Escape" && selectedItemIds.size > 0) {
        e.preventDefault();
        setSelectedItemIds(new Set());
        return;
      }

      // A: Add selected to sheet (if available)
      if (
        e.key === "a" &&
        selectedItemIds.size > 0 &&
        onAddToSheet
      ) {
        e.preventDefault();
        handleAddSelectedToSheet();
        return;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () =>
      window.removeEventListener("keydown", handleKeyDown);
  }, [open, selectedItemIds, glossaryItems, onAddToSheet]);

  // Get unique schools and tags for filters
  const availableSchools = useMemo(() => {
    const schools = new Set<string>();
    glossaryItems.forEach((item) => {
      if (item.school) schools.add(item.school);
    });
    return Array.from(schools).sort();
  }, [glossaryItems]);

  const availableTags = useMemo(() => {
    const tags = new Set<string>();
    glossaryItems.forEach((item) => {
      item.tags.forEach((tag) => tags.add(tag));
    });
    return Array.from(tags).sort();
  }, [glossaryItems]);

  // Filter and sort items
  const filteredItems = useMemo(() => {
    return glossaryItems
      .filter((item) => {
        // Type filter
        if (filterType !== "all" && item.type !== filterType)
          return false;

        // School filter
        if (
          filterSchool !== "all" &&
          item.school !== filterSchool
        )
          return false;

        // Tag filter
        if (
          filterTag !== "all" &&
          !item.tags.includes(filterTag)
        )
          return false;

        // Folder filter
        if (
          selectedFolderId &&
          item.folderId !== selectedFolderId
        )
          return false;

        // Search query
        if (searchQuery.trim()) {
          const query = searchQuery.toLowerCase();
          return (
            item.name.toLowerCase().includes(query) ||
            item.description.toLowerCase().includes(query) ||
            item.tags.some((tag) =>
              tag.toLowerCase().includes(query),
            ) ||
            (item.school &&
              item.school.toLowerCase().includes(query))
          );
        }

        return true;
      })
      .sort((a, b) => {
        switch (sortField) {
          case "name":
            return a.name.localeCompare(b.name);
          case "school":
            return (a.school || "").localeCompare(
              b.school || "",
            );
          case "type":
            return a.type.localeCompare(b.type);
          case "createdAt":
            return (
              new Date(b.createdAt).getTime() -
              new Date(a.createdAt).getTime()
            );
          default:
            return 0;
        }
      });
  }, [
    glossaryItems,
    filterType,
    filterSchool,
    filterTag,
    selectedFolderId,
    searchQuery,
    sortField,
  ]);

  // Virtualizer for the list
  const rowVirtualizer = useVirtualizer({
    count: filteredItems.length,
    getScrollElement: () => listParentRef.current,
    estimateSize: () => 80,
    overscan: 8,
  });

  // Folder tree structure
  const folderTree = useMemo(() => {
    const rootFolders = folders.filter((f) => !f.parentId);
    const buildTree = (parentId?: string): GlossaryFolder[] => {
      return folders
        .filter((f) => f.parentId === parentId)
        .sort((a, b) => a.order - b.order);
    };
    return { root: rootFolders, buildTree };
  }, [folders]);

  // Handlers
  const handleCreateItem = (type?: "capacité" | "magie") => {
    setEditorDefaultType(type || "capacité");
    setEditingItem(null);
    setShowItemEditor(true);
  };

  const handleEditItem = (item: GlossaryItem) => {
    setEditingItem(item);
    setShowItemEditor(true);
  };

  const handleSaveItem = async (
    item: GlossaryItem,
    addToSheet = false,
  ) => {
    try {
      setSaving(true);
      
      let savedItem: GlossaryItem;
      
      if (editingItem) {
        // Update existing item
        savedItem = await GlossaryRepository.updateItem(item.id, item);
        setGlossaryItems((prev) =>
          prev.map((i) => (i.id === item.id ? savedItem : i)),
        );
        toast.success('Élément mis à jour');
      } else {
        // Create new item
        const { id, createdAt, updatedAt, ...itemData } = item;
        savedItem = await GlossaryRepository.createItem(itemData);
        setGlossaryItems((prev) => [...prev, savedItem]);
        toast.success('Élément créé');
      }

      if (addToSheet && onAddToSheet) {
        onAddToSheet(savedItem);
      }
    } catch (error) {
      console.error('Error saving item:', error);
      toast.error('Erreur lors de la sauvegarde');
      throw error;
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteItem = (itemId: string) => {
    setItemToDelete(itemId);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (itemToDelete) {
      try {
        setSaving(true);
        await GlossaryRepository.deleteItem(itemToDelete);
        setGlossaryItems((prev) =>
          prev.filter((item) => item.id !== itemToDelete),
        );
        setSelectedItemIds((prev) => {
          const newSet = new Set(prev);
          newSet.delete(itemToDelete);
          return newSet;
        });
        toast.success("Élément supprimé");
      } catch (error) {
        console.error('Error deleting item:', error);
        toast.error('Erreur lors de la suppression');
      } finally {
        setSaving(false);
      }
    }
    setItemToDelete(null);
    setShowDeleteConfirm(false);
  };

  const handleDeleteSelected = () => {
    if (selectedItemIds.size === 0) return;

    const count = selectedItemIds.size;
    setGlossaryItems((prev) =>
      prev.filter((item) => !selectedItemIds.has(item.id)),
    );
    setSelectedItemIds(new Set());
    toast.success(
      `${count} élément${count > 1 ? "s supprimés" : " supprimé"}`,
    );
  };

  const handleAddSelectedToSheet = () => {
    if (
      !onAddToSheet ||
      selectedItemIds.size === 0 ||
      !character
    )
      return;

    const items = glossaryItems.filter((item) =>
      selectedItemIds.has(item.id),
    );
    let addedCount = 0;
    let skippedCount = 0;

    items.forEach((item) => {
      // Check for duplicates based on name, type, and school
      const isDuplicate =
        item.type === "capacité"
          ? character.abilities.some(
              (a) => a.name === item.name,
            )
          : character.magic.schools.some(
              (s) =>
                s.name === item.school &&
                s.spells?.some((sp) => sp.name === item.name),
            );

      if (isDuplicate) {
        skippedCount++;
      } else {
        onAddToSheet(item);
        addedCount++;
      }
    });

    if (addedCount > 0) {
      toast.success(
        `${addedCount} élément${addedCount > 1 ? "s ajoutés" : " ajouté"} à la fiche`,
      );
    }
    if (skippedCount > 0) {
      toast.info(
        `${skippedCount} doublon${skippedCount > 1 ? "s ignorés" : " ignoré"}`,
      );
    }
  };

  const handleToggleSelection = (
    itemId: string,
    ctrlKey = false,
    shiftKey = false,
  ) => {
    const currentIndex = filteredItems.findIndex(
      (item) => item.id === itemId,
    );

    setSelectedItemIds((prev) => {
      const newSet = new Set(prev);

      if (shiftKey && lastSelectedIndex >= 0) {
        // Range selection
        const start = Math.min(lastSelectedIndex, currentIndex);
        const end = Math.max(lastSelectedIndex, currentIndex);
        for (let i = start; i <= end; i++) {
          newSet.add(filteredItems[i].id);
        }
      } else if (ctrlKey || ctrlKey === undefined) {
        // Toggle single item (Ctrl/Cmd)
        if (newSet.has(itemId)) {
          newSet.delete(itemId);
        } else {
          newSet.add(itemId);
        }
      } else {
        // Single selection (no modifiers)
        newSet.clear();
        newSet.add(itemId);
      }

      return newSet;
    });

    setLastSelectedIndex(currentIndex);
  };

  const handleSelectAll = () => {
    if (selectedItemIds.size === filteredItems.length) {
      setSelectedItemIds(new Set());
    } else {
      setSelectedItemIds(
        new Set(filteredItems.map((item) => item.id)),
      );
    }
  };

  const handleCreateFolder = () => {
    setEditingFolderId(null);
    setFolderName("");
    setShowFolderDialog(true);
  };

  const handleEditFolder = (folder: GlossaryFolder) => {
    setEditingFolderId(folder.id);
    setFolderName(folder.name);
    setShowFolderDialog(true);
  };

  const handleSaveFolder = async () => {
    if (!folderName.trim()) {
      toast.error("Le nom du dossier est requis");
      return;
    }

    try {
      setSaving(true);
      
      if (editingFolderId) {
        // Update existing folder
        const savedFolder = await GlossaryRepository.updateFolder(editingFolderId, {
          name: folderName.trim(),
        });
        setFolders((prev) =>
          prev.map((f) => (f.id === editingFolderId ? savedFolder : f)),
        );
        toast.success("Dossier renommé");
      } else {
        // Create new folder
        const savedFolder = await GlossaryRepository.createFolder({
          name: folderName.trim(),
          order: folders.length,
        });
        setFolders((prev) => [...prev, savedFolder]);
        toast.success("Dossier créé");
      }

      setShowFolderDialog(false);
      setFolderName("");
    } catch (error) {
      console.error('Error saving folder:', error);
      toast.error('Erreur lors de la sauvegarde du dossier');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteFolder = async (folderId: string) => {
    const hasItems = glossaryItems.some(
      (item) => item.folderId === folderId,
    );
    if (hasItems) {
      toast.error(
        "Ce dossier contient des éléments. Veuillez les déplacer avant de supprimer le dossier.",
      );
      return;
    }

    try {
      setSaving(true);
      await GlossaryRepository.deleteFolder(folderId);
      setFolders((prev) => prev.filter((f) => f.id !== folderId));
      if (selectedFolderId === folderId) {
        setSelectedFolderId(null);
      }
      toast.success("Dossier supprimé");
    } catch (error) {
      console.error('Error deleting folder:', error);
      toast.error('Erreur lors de la suppression du dossier');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleFolder = (folderId: string) => {
    setExpandedFolders((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(folderId)) {
        newSet.delete(folderId);
      } else {
        newSet.add(folderId);
      }
      return newSet;
    });
  };

  const handleImportGlossary = async (data: {
    items: GlossaryItem[];
    folders: GlossaryFolder[];
  }) => {
    try {
      setSaving(true);

      // Check for duplicate items (same name and type)
      const existingKeys = new Set(
        glossaryItems.map((item) => `${item.name.toLowerCase()}|${item.type}`),
      );

      const newItems = data.items.filter(
        (item) =>
          !existingKeys.has(`${item.name.toLowerCase()}|${item.type}`),
      );

      // Check for duplicate folders (same name)
      const existingFolderNames = new Set(
        folders.map((folder) => folder.name.toLowerCase()),
      );

      const newFolders = data.folders.filter(
        (folder) => !existingFolderNames.has(folder.name.toLowerCase()),
      );

      // Save new items to repository
      for (const item of newItems) {
        const { id, createdAt, updatedAt, ...itemData } = item;
        const savedItem = await GlossaryRepository.createItem(itemData);
        setGlossaryItems((prev) => [...prev, savedItem]);
      }

      // Save new folders to repository
      for (const folder of newFolders) {
        const { id, createdAt, updatedAt, ...folderData } = folder;
        const savedFolder = await GlossaryRepository.createFolder(folderData);
        setFolders((prev) => [...prev, savedFolder]);
      }

      const skippedItems = data.items.length - newItems.length;
      const skippedFolders = data.folders.length - newFolders.length;

      if (newItems.length > 0 || newFolders.length > 0) {
        const itemsMsg = newItems.length > 0
          ? `${newItems.length} élément${newItems.length > 1 ? "s" : ""}`
          : "";
        const foldersMsg = newFolders.length > 0
          ? `${newFolders.length} dossier${newFolders.length > 1 ? "s" : ""}`
          : "";
        const separator = itemsMsg && foldersMsg ? " et " : "";
        toast.success(`Importé ${itemsMsg}${separator}${foldersMsg}`);
      }

      if (skippedItems > 0 || skippedFolders > 0) {
        const skippedMsg =
          skippedItems > 0 && skippedFolders > 0
            ? `${skippedItems} élément${skippedItems > 1 ? "s" : ""} et ${skippedFolders} dossier${skippedFolders > 1 ? "s" : ""} ignorés (doublons)`
            : skippedItems > 0
              ? `${skippedItems} élément${skippedItems > 1 ? "s" : ""} ignoré${skippedItems > 1 ? "s" : ""} (doublon${skippedItems > 1 ? "s" : ""})`
              : `${skippedFolders} dossier${skippedFolders > 1 ? "s" : ""} ignoré${skippedFolders > 1 ? "s" : ""} (doublon${skippedFolders > 1 ? "s" : ""})`;
        toast.info(skippedMsg);
      }
    } catch (error) {
      console.error("Import error:", error);
      toast.error("Erreur lors de l'importation");
    } finally {
      setSaving(false);
    }
  };

  // Get item count for a folder
  const getFolderItemCount = (folderId: string) => {
    return glossaryItems.filter(
      (item) => item.folderId === folderId,
    ).length;
  };

  // Render folder tree node
  const renderFolderNode = (
    folder: GlossaryFolder,
    depth = 0,
  ) => {
    const isExpanded = expandedFolders.has(folder.id);
    const isSelected = selectedFolderId === folder.id;
    const itemCount = getFolderItemCount(folder.id);
    const children = folderTree.buildTree(folder.id);

    return (
      <div key={folder.id}>
        <div
          className={`
            group w-full flex items-center gap-2 px-2 py-1.5 rounded hover:bg-accent/50 transition-colors cursor-pointer
            ${isSelected ? "bg-accent" : ""}
          `}
          style={{ paddingLeft: `${depth * 16 + 8}px` }}
          onClick={() => {
            setSelectedFolderId(isSelected ? null : folder.id);
            if (children.length > 0) {
              handleToggleFolder(folder.id);
            }
          }}
          role="treeitem"
          aria-selected={isSelected}
          aria-expanded={
            children.length > 0 ? isExpanded : undefined
          }
        >
          {children.length > 0 ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleToggleFolder(folder.id);
              }}
              className="hover:bg-accent/50 rounded p-0.5"
              aria-label={isExpanded ? "Réduire" : "Développer"}
            >
              {isExpanded ? (
                <ChevronDown className="w-3 h-3" />
              ) : (
                <ChevronRight className="w-3 h-3" />
              )}
            </button>
          ) : (
            <div className="w-4" />
          )}

          <FolderOpen className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          <span className="flex-1 text-left text-sm truncate">
            {folder.name}
          </span>
          <span className="text-xs text-muted-foreground">
            {itemCount}
          </span>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                onClick={(e) => e.stopPropagation()}
                className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 hover:bg-accent rounded inline-flex items-center justify-center"
                aria-label="Options du dossier"
              >
                <MoreVertical className="w-3 h-3" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={() => handleEditFolder(folder)}
              >
                <Edit className="w-4 h-4 mr-2" />
                Renommer
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => handleDeleteFolder(folder.id)}
                className="text-destructive"
              >
                <Trash className="w-4 h-4 mr-2" />
                Supprimer
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {isExpanded && children.length > 0 && (
          <div>
            {children.map((child) =>
              renderFolderNode(child, depth + 1),
            )}
          </div>
        )}
      </div>
    );
  };

  const selectedItem =
    selectedItemIds.size === 1
      ? glossaryItems.find((item) =>
          selectedItemIds.has(item.id),
        )
      : null;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent
          className="w-[98vw] max-w-[98vw] h-[85vh] p-0 flex flex-col overflow-hidden"
          aria-describedby={undefined}
        >
          <DialogHeader className="px-6 pt-6 pb-4">
            <DialogTitle className="flex items-center gap-2">
              <Library className="w-5 h-5" />
              Glossaire des capacités et magies
            </DialogTitle>
            <DialogDescription>
              Gérez votre bibliothèque de capacités et sorts
              réutilisables • Entrée: Modifier • Suppr:
              Supprimer • A: Ajouter
            </DialogDescription>
          </DialogHeader>

          {/* Toolbar */}
          <div className="px-6 pb-4 space-y-3 border-b">
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                onClick={() => handleCreateItem("capacité")}
              >
                <Plus className="w-4 h-4 mr-2" />
                Nouvelle capacité
              </Button>
              <Button
                size="sm"
                onClick={() => handleCreateItem("magie")}
              >
                <Plus className="w-4 h-4 mr-2" />
                Nouvelle magie
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCreateFolder}
              >
                <FolderPlus className="w-4 h-4 mr-2" />
                Nouveau dossier
              </Button>

              <Separator
                orientation="vertical"
                className="h-8"
              />

              <GlossaryImportExport
                items={glossaryItems}
                folders={folders}
                onImport={handleImportGlossary}
              />
            </div>

            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <Input
                  value={searchQuery}
                  onChange={(e) =>
                    setSearchQuery(e.target.value)
                  }
                  placeholder="Rechercher... (⌘K)"
                  className="pl-9"
                />
              </div>

              <Select
                value={filterType}
                onValueChange={(v) =>
                  setFilterType(v as GlossaryFilterType)
                }
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent
                  className="z-[100]"
                  position="popper"
                  sideOffset={4}
                >
                  <SelectItem value="all">
                    Tous types
                  </SelectItem>
                  <SelectItem value="capacité">
                    Capacités
                  </SelectItem>
                  <SelectItem value="magie">Magie</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={filterSchool}
                onValueChange={setFilterSchool}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="École" />
                </SelectTrigger>
                <SelectContent
                  className="z-[100]"
                  position="popper"
                  sideOffset={4}
                >
                  <SelectItem value="all">
                    Toutes écoles
                  </SelectItem>
                  {availableSchools.map((school) => (
                    <SelectItem key={school} value={school}>
                      {school}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={filterTag}
                onValueChange={setFilterTag}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Tag" />
                </SelectTrigger>
                <SelectContent
                  className="z-[100]"
                  position="popper"
                  sideOffset={4}
                >
                  <SelectItem value="all">Tous tags</SelectItem>
                  {availableTags.map((tag) => (
                    <SelectItem key={tag} value={tag}>
                      {tag}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={sortField}
                onValueChange={(v) =>
                  setSortField(v as GlossarySortField)
                }
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Tri" />
                </SelectTrigger>
                <SelectContent
                  className="z-[100]"
                  position="popper"
                  sideOffset={4}
                >
                  <SelectItem value="name">Nom</SelectItem>
                  <SelectItem value="school">École</SelectItem>
                  <SelectItem value="type">Type</SelectItem>
                  <SelectItem value="createdAt">
                    Récents
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {selectedItemIds.size > 0 && (
              <div className="flex items-center gap-2 p-2 bg-accent/50 rounded-lg">
                <span className="text-sm">
                  {selectedItemIds.size} élément
                  {selectedItemIds.size > 1 ? "s" : ""}{" "}
                  sélectionné
                  {selectedItemIds.size > 1 ? "s" : ""}
                </span>
                <Separator
                  orientation="vertical"
                  className="h-6"
                />
                {selectedItemIds.size === 1 && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      selectedItem &&
                      handleEditItem(selectedItem)
                    }
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Modifier
                  </Button>
                )}
                {onAddToSheet && (
                  <Button
                    size="sm"
                    onClick={handleAddSelectedToSheet}
                  >
                    Ajouter à la fiche
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleDeleteSelected}
                >
                  <Trash className="w-4 h-4 mr-2" />
                  Supprimer
                </Button>
              </div>
            )}
          </div>

          {/* 3-Panel Layout */}
          <ResizablePanelGroup
            direction="horizontal"
            className="min-h-0 flex-1 overflow-hidden"
          >
            {/* Left Panel: Folder Tree */}
            <ResizablePanel
              defaultSize={20}
              minSize={15}
              maxSize={35}
              className="flex flex-col overflow-hidden"
            >
              <div className="p-3 border-b">
                <h3 className="font-medium text-sm">
                  Dossiers
                </h3>
              </div>
              <ScrollArea className="h-full">
                <div className="p-2 space-y-0.5">
                  <button
                    onClick={() => setSelectedFolderId(null)}
                    className={`
                      w-full flex items-center gap-2 px-2 py-1.5 rounded hover:bg-accent/50 transition-colors
                      ${selectedFolderId === null ? "bg-accent" : ""}
                    `}
                    role="treeitem"
                    aria-selected={selectedFolderId === null}
                  >
                    <Folder className="w-4 h-4 text-muted-foreground" />
                    <span className="flex-1 text-left text-sm">
                      Tous les éléments
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {glossaryItems.length}
                    </span>
                  </button>

                  {folderTree.root.length === 0 ? (
                    <div className="text-center py-8 px-4">
                      <FolderOpen className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-50" />
                      <p className="text-xs text-muted-foreground">
                        Aucun dossier
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-0.5" role="tree">
                      {folderTree.root.map((folder) =>
                        renderFolderNode(folder),
                      )}
                    </div>
                  )}
                </div>
              </ScrollArea>
            </ResizablePanel>

            <ResizableHandle withHandle />

            {/* Center Panel: Item List */}
            <ResizablePanel
              defaultSize={50}
              minSize={30}
              className="overflow-hidden"
            >
              <div className="p-3 border-b flex items-center justify-between">
                <h3 className="font-medium text-sm">
                  {filteredItems.length} élément
                  {filteredItems.length > 1 ? "s" : ""}
                </h3>
                {filteredItems.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleSelectAll}
                  >
                    <Checkbox
                      checked={
                        selectedItemIds.size ===
                          filteredItems.length &&
                        filteredItems.length > 0
                      }
                      onCheckedChange={handleSelectAll}
                      className="mr-2"
                    />
                    Tout sélectionner
                  </Button>
                )}
              </div>

              <div
                className="flex-1 min-h-0 overflow-auto"
                ref={listParentRef}
              >
                {filteredItems.length === 0 ? (
                  <div className="text-center py-12 px-4">
                    <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="font-medium mb-2">
                      Aucun élément trouvé
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      {searchQuery
                        ? "Essayez une autre recherche"
                        : "Créez votre première capacité ou magie"}
                    </p>
                    {!searchQuery && (
                      <div className="flex gap-2 justify-center">
                        <Button
                          size="sm"
                          onClick={() =>
                            handleCreateItem("capacité")
                          }
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Capacité
                        </Button>
                        <Button
                          size="sm"
                          onClick={() =>
                            handleCreateItem("magie")
                          }
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Magie
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div
                    style={{
                      height: `${rowVirtualizer.getTotalSize()}px`,
                      width: "100%",
                      position: "relative",
                    }}
                  >
                    {rowVirtualizer
                      .getVirtualItems()
                      .map((virtualRow) => {
                        const item =
                          filteredItems[virtualRow.index];
                        const isSelected =
                          selectedItemIds.has(item.id);

                        return (
                          <div
                            key={item.id}
                            data-index={virtualRow.index}
                            style={{
                              position: "absolute",
                              top: 0,
                              left: 0,
                              width: "100%",
                              height: `${virtualRow.size}px`,
                              transform: `translateY(${virtualRow.start}px)`,
                            }}
                          >
                            <div
                              className={`
                            mx-2 my-1 p-3 border rounded-lg cursor-pointer transition-colors
                            ${isSelected ? "bg-accent border-primary" : "hover:bg-accent/50"}
                          `}
                              onClick={(e) => {
                                if (e.detail === 2) {
                                  // Double-click to edit
                                  handleEditItem(item);
                                } else {
                                  // Single click with modifiers
                                  handleToggleSelection(
                                    item.id,
                                    e.ctrlKey || e.metaKey,
                                    e.shiftKey,
                                  );
                                }
                              }}
                              role="row"
                              aria-selected={isSelected}
                              tabIndex={0}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") {
                                  e.preventDefault();
                                  handleEditItem(item);
                                }
                              }}
                            >
                              <div className="flex items-start gap-3">
                                <Checkbox
                                  checked={isSelected}
                                  onCheckedChange={(
                                    checked,
                                  ) => {
                                    if (checked) {
                                      setSelectedItemIds(
                                        (prev) =>
                                          new Set([
                                            ...prev,
                                            item.id,
                                          ]),
                                      );
                                    } else {
                                      setSelectedItemIds(
                                        (prev) => {
                                          const newSet =
                                            new Set(prev);
                                          newSet.delete(
                                            item.id,
                                          );
                                          return newSet;
                                        },
                                      );
                                    }
                                  }}
                                  onClick={(e) =>
                                    e.stopPropagation()
                                  }
                                  className="mt-0.5"
                                />

                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                                    <h4 className="font-medium truncate">
                                      {item.name}
                                    </h4>
                                    <Badge
                                      variant={
                                        item.type === "magie"
                                          ? "default"
                                          : "secondary"
                                      }
                                      className="text-xs"
                                    >
                                      {item.type ===
                                      "magie" ? (
                                        <>
                                          <Wand2 className="w-3 h-3 mr-1" />
                                          Magie
                                        </>
                                      ) : (
                                        <>
                                          <FileText className="w-3 h-3 mr-1" />
                                          Capacité
                                        </>
                                      )}
                                    </Badge>
                                    {item.school && (
                                      <Badge
                                        variant="outline"
                                        className="text-xs"
                                      >
                                        {item.school}
                                      </Badge>
                                    )}
                                  </div>
                                  <p className="text-sm text-muted-foreground line-clamp-1">
                                    {item.description}
                                  </p>
                                  {item.tags.length > 0 && (
                                    <div className="flex flex-wrap gap-1 mt-1">
                                      {item.tags
                                        .slice(0, 3)
                                        .map((tag) => (
                                          <Badge
                                            key={tag}
                                            variant="outline"
                                            className="text-xs"
                                          >
                                            {tag}
                                          </Badge>
                                        ))}
                                      {item.tags.length >
                                        3 && (
                                        <Badge
                                          variant="outline"
                                          className="text-xs"
                                        >
                                          +
                                          {item.tags.length -
                                            3}
                                        </Badge>
                                      )}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            </ResizablePanel>

            <ResizableHandle withHandle />

            {/* Right Panel: Preview/Edit */}
            <ResizablePanel
              defaultSize={30}
              minSize={20}
              maxSize={40}
              className="flex flex-col overflow-hidden"
            >
              <div className="p-3 border-b">
                <h3 className="font-medium text-sm">Aperçu</h3>
              </div>

              <ScrollArea className="h-full">
                {selectedItem ? (
                  <div className="p-4 space-y-4">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-medium">
                          {selectedItem.name}
                        </h3>
                        <Badge
                          variant={
                            selectedItem.type === "magie"
                              ? "default"
                              : "secondary"
                          }
                        >
                          {selectedItem.type}
                        </Badge>
                      </div>
                      {selectedItem.school && (
                        <p className="text-sm text-muted-foreground mb-2">
                          <span className="font-medium">
                            École:
                          </span>{" "}
                          {selectedItem.school}
                        </p>
                      )}
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-1">
                        Description
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {selectedItem.description}
                      </p>
                    </div>

                    {selectedItem.effects && (
                      <div>
                        <p className="text-sm font-medium mb-1">
                          Effets
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {selectedItem.effects}
                        </p>
                      </div>
                    )}

                    {selectedItem.activationType && (
                      <div>
                        <p className="text-sm font-medium mb-1">
                          Type d'activation
                        </p>
                        <Badge variant="outline">
                          {selectedItem.activationType}
                        </Badge>
                      </div>
                    )}

                    {selectedItem.frequency && (
                      <div>
                        <p className="text-sm font-medium mb-1">
                          Fréquence
                        </p>
                        <Badge variant="outline">
                          {selectedItem.frequency}
                        </Badge>
                      </div>
                    )}

                    {selectedItem.range && (
                      <div>
                        <p className="text-sm font-medium mb-1">
                          Portée
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {selectedItem.range}
                        </p>
                      </div>
                    )}

                    {selectedItem.duration && (
                      <div>
                        <p className="text-sm font-medium mb-1">
                          Durée
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {selectedItem.duration}
                        </p>
                      </div>
                    )}

                    {selectedItem.prerequisites && (
                      <div>
                        <p className="text-sm font-medium mb-1">
                          Prérequis
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {selectedItem.prerequisites}
                        </p>
                      </div>
                    )}

                    {selectedItem.tags.length > 0 && (
                      <div>
                        <p className="text-sm font-medium mb-2">
                          Tags
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {selectedItem.tags.map((tag) => (
                            <Badge
                              key={tag}
                              variant="outline"
                              className="text-xs"
                            >
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    <Separator />

                    <div className="space-y-2">
                      <Button
                        className="w-full"
                        variant="outline"
                        onClick={() =>
                          handleEditItem(selectedItem)
                        }
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Modifier
                      </Button>
                      {onAddToSheet && character && (
                        <Button
                          className="w-full"
                          onClick={() => {
                            // Check for duplicates
                            const isDuplicate =
                              selectedItem.type === "capacité"
                                ? character.abilities.some(
                                    (a) =>
                                      a.name ===
                                      selectedItem.name,
                                  )
                                : character.magic.schools.some(
                                    (s) =>
                                      s.name ===
                                        selectedItem.school &&
                                      s.spells?.some(
                                        (sp) =>
                                          sp.name ===
                                          selectedItem.name,
                                      ),
                                  );

                            if (isDuplicate) {
                              toast.warning(
                                `"${selectedItem.name}" existe déjà dans la fiche`,
                              );
                            } else {
                              onAddToSheet(selectedItem);
                              toast.success(
                                `"${selectedItem.name}" ajouté à la fiche`,
                              );
                            }
                          }}
                        >
                          Ajouter à la fiche
                        </Button>
                      )}
                    </div>
                  </div>
                ) : selectedItemIds.size > 1 ? (
                  <div className="p-4">
                    <div className="text-center py-8">
                      <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                      <h3 className="font-medium mb-2">
                        {selectedItemIds.size} éléments
                        sélectionnés
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Utilisez la barre d'outils pour
                        effectuer des actions groupées
                      </p>
                      {onAddToSheet && (
                        <Button
                          onClick={handleAddSelectedToSheet}
                        >
                          Ajouter {selectedItemIds.size} élément
                          {selectedItemIds.size > 1
                            ? "s"
                            : ""}{" "}
                          à la fiche
                        </Button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="p-4">
                    <div className="text-center py-8">
                      <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                      <p className="text-sm text-muted-foreground">
                        Sélectionnez un élément pour voir les
                        détails
                      </p>
                    </div>
                  </div>
                )}
              </ScrollArea>
            </ResizablePanel>
          </ResizablePanelGroup>
        </DialogContent>
      </Dialog>

      {/* Item Editor Dialog */}
      <ItemEditor
        open={showItemEditor}
        onOpenChange={setShowItemEditor}
        item={editingItem}
        folders={folders}
        onSave={handleSaveItem}
        defaultType={editorDefaultType}
      />

      {/* Delete Confirmation */}
      <AlertDialog
        open={showDeleteConfirm}
        onOpenChange={setShowDeleteConfirm}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Confirmer la suppression
            </AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer cet élément ?
              Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Folder Dialog */}
      <Dialog
        open={showFolderDialog}
        onOpenChange={setShowFolderDialog}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingFolderId
                ? "Renommer le dossier"
                : "Nouveau dossier"}
            </DialogTitle>
            <DialogDescription>
              {editingFolderId
                ? "Modifiez le nom du dossier"
                : "Créez un nouveau dossier pour organiser vos éléments"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="folderName">Nom du dossier</Label>
              <Input
                id="folderName"
                value={folderName}
                onChange={(e) => setFolderName(e.target.value)}
                placeholder="Ex: Sorts de combat, Capacités défensives..."
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleSaveFolder();
                  }
                }}
                autoFocus
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => setShowFolderDialog(false)}
              disabled={saving}
            >
              Annuler
            </Button>
            <Button onClick={handleSaveFolder} disabled={saving}>
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {editingFolderId ? "Renommer" : "Créer"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}