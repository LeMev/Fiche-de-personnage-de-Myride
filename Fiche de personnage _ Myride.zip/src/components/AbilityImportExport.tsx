import { useState } from "react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Alert, AlertDescription } from "./ui/alert";
import type { Character, Ability } from "../types/game";
import {
  Download,
  Upload,
  FileText,
  AlertCircle,
  Copy,
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import {
  toCanonicalAbility,
  normalizeInput,
  serializeCanonical,
  getExampleCanonical,
  type CanonicalAbilityPayload,
} from "../utils/abilitySchema";
import { copyToClipboard } from "../utils/clipboardUtils";

interface AbilityImportExportProps {
  character: Character;
  onUpdateCharacter: (character: Character) => void;
}

export function AbilityImportExport({
  character,
  onUpdateCharacter,
}: AbilityImportExportProps) {
  const [showExportDialog, setShowExportDialog] =
    useState(false);
  const [showImportDialog, setShowImportDialog] =
    useState(false);
  const [importData, setImportData] = useState("");
  const [importError, setImportError] = useState("");

  const exportAbilities = () => {
    // Sérialisation au format canonique avec ordre déterministe
    const canonicalAbilities = character.abilities.map(
      (ability) => toCanonicalAbility(ability),
    );

    const payload: CanonicalAbilityPayload = {
      abilities: canonicalAbilities,
    };

    // JSON pretty-print avec 2 espaces
    return serializeCanonical(payload);
  };

  const handleExport = async () => {
    const data = exportAbilities();
    try {
      await copyToClipboard(JSON.parse(data));
      toast.success(
        "Capacités copiées au format Myride (abilities).",
      );
    } catch (error) {
      toast.error("Erreur lors de la copie");
    }
  };

  const handleImport = () => {
    setImportError("");

    try {
      // Parser robuste avec normalisation
      const normalized = normalizeInput(importData);

      // Convertir les capacités canoniques vers le format interne complet
      const validatedAbilities: Ability[] =
        normalized.abilities.map((canonical) => {
          const newAbility: Ability = {
            id: `ability-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            name: canonical.name,
            type: canonical.type,
            description: canonical.description,
            effects: canonical.effects,
            costs: canonical.costs.map((cost) => ({
              context: cost.context,
              resources: cost.resources.map((r) => ({
                id: crypto.randomUUID(),
                type: r.type,
                amount: r.amount,
                perUnit: r.perUnit,
              })),
            })),
            frequency: canonical.frequency,
            restRefresh: canonical.restRefresh,
            prerequisites: canonical.prerequisites,
            tags: [],
            usedToday: 0,
            currentCooldown: 0,
            usageLog: [],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };

          // Ajouter les champs optionnels s'ils sont présents
          if (canonical.activationType) {
            newAbility.activationType =
              canonical.activationType;
          }
          if (canonical.charges !== undefined) {
            newAbility.charges = canonical.charges;
          }
          if (canonical.maxCharges !== undefined) {
            newAbility.maxCharges = canonical.maxCharges;
          }
          if (canonical.dailyUses !== undefined) {
            newAbility.dailyUses = canonical.dailyUses;
          }
          if (canonical.cooldownTurns !== undefined) {
            newAbility.cooldownTurns = canonical.cooldownTurns;
          }
          if (canonical.hasCharges !== undefined) {
            newAbility.hasCharges = canonical.hasCharges;
          }
          if (canonical.rechargesOnLongRest !== undefined) {
            newAbility.rechargesOnLongRest =
              canonical.rechargesOnLongRest;
          }
          if (
            canonical.hasCharges &&
            canonical.maxCharges !== undefined
          ) {
            newAbility.currentCharges = canonical.maxCharges; // Initialize current charges to max
          }

          return newAbility;
        });

      // Vérifier les conflits de noms
      const existingNames = character.abilities.map((a) =>
        a.name.toLowerCase(),
      );
      const conflicts = validatedAbilities.filter((a) =>
        existingNames.includes(a.name.toLowerCase()),
      );

      if (conflicts.length > 0) {
        const conflictNames = conflicts
          .map((a) => a.name)
          .join(", ");
        throw new Error(
          `Conflit de noms : les capacités suivantes existent déjà : ${conflictNames}`,
        );
      }

      // Ajouter les capacités au personnage
      const updatedCharacter = {
        ...character,
        abilities: [
          ...character.abilities,
          ...validatedAbilities,
        ],
        updatedAt: new Date().toISOString(),
      };

      onUpdateCharacter(updatedCharacter);
      setShowImportDialog(false);
      setImportData("");
      toast.success(
        `Importé ${validatedAbilities.length} capacité${validatedAbilities.length !== 1 ? "s" : ""}.`,
      );
    } catch (error) {
      setImportError(
        error instanceof Error
          ? error.message
          : "Erreur inconnue lors de l'import",
      );
    }
  };

  const handleCopyExample = async () => {
    const example = getExampleCanonical();
    try {
      await copyToClipboard(JSON.parse(example));
      toast.success("Exemple copié dans le presse-papiers");
    } catch (error) {
      toast.error("Erreur lors de la copie de l'exemple");
    }
  };

  const handleLoadExample = () => {
    setImportData(getExampleCanonical());
    setImportError("");
  };

  const downloadAsFile = () => {
    const data = exportAbilities();
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `capacites-${character.name.toLowerCase().replace(/\s+/g, "-")}-${new Date().toISOString().split("T")[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Fichier téléchargé");
  };

  return (
    <div className="flex gap-2">
      <Dialog
        open={showExportDialog}
        onOpenChange={setShowExportDialog}
      >
        <DialogTrigger asChild>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </Button>
        </DialogTrigger>
        <DialogContent
          className="max-w-2xl"
          aria-describedby={undefined}
        >
          <DialogHeader>
            <DialogTitle>Exporter les capacités</DialogTitle>
            <DialogDescription>
              Exportez toutes les capacités de {character.name}{" "}
              au format JSON canonique Myride
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="export-data">
                Données d'export (format canonique)
              </Label>
              <Textarea
                id="export-data"
                value={exportAbilities()}
                readOnly
                rows={12}
                className="font-mono text-sm"
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handleExport} className="flex-1">
                <FileText className="w-4 h-4 mr-2" />
                Copier dans le presse-papiers
              </Button>
              <Button
                onClick={downloadAsFile}
                variant="outline"
                className="flex-1"
              >
                <Download className="w-4 h-4 mr-2" />
                Télécharger en tant que fichier
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog
        open={showImportDialog}
        onOpenChange={setShowImportDialog}
      >
        <DialogTrigger asChild>
          <Button variant="outline" size="sm">
            <Upload className="w-4 h-4 mr-2" />
            Importer
          </Button>
        </DialogTrigger>
        <DialogContent
          className="max-w-2xl"
          aria-describedby={undefined}
        >
          <DialogHeader>
            <DialogTitle>Importer des capacités</DialogTitle>
            <DialogDescription>
              Importez des capacités au format JSON Myride.
              Accepte {"{ abilities: [...] }"}, une liste, ou un
              objet unique — tout est normalisé.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="import-data">
                Données JSON à importer
              </Label>
              <Textarea
                id="import-data"
                value={importData}
                onChange={(e) => {
                  setImportData(e.target.value);
                  setImportError("");
                }}
                placeholder="Collez ici les données JSON exportées..."
                rows={8}
                className="font-mono text-sm"
              />
            </div>

            {importError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <div>{importError}</div>
                    <div className="text-sm">
                      Format attendu:{" "}
                      {`{ "abilities": [ { ... } ] }`}
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-2">
              <Button
                onClick={handleImport}
                disabled={!importData.trim()}
              >
                <Upload className="w-4 h-4 mr-2" />
                Importer les capacités
              </Button>
              <Button
                variant="outline"
                onClick={handleLoadExample}
              >
                <FileText className="w-4 h-4 mr-2" />
                Charger un exemple
              </Button>
              <Button
                variant="outline"
                onClick={handleCopyExample}
                title="Copie un exemple de format dans le presse-papiers"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copier l'exemple
              </Button>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                L'import créera de nouvelles capacités. Les
                capacités existantes avec le même nom ne seront
                pas remplacées.
              </AlertDescription>
            </Alert>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}