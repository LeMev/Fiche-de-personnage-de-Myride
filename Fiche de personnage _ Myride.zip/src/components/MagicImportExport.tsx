import { useState } from 'react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import type { MagicSchool } from '../types/game';
import { Upload, Download, FileText } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface MagicImportExportProps {
  onImportSchool: (school: MagicSchool) => void;
}

export function MagicImportExport({ onImportSchool }: MagicImportExportProps) {
  const [importData, setImportData] = useState('');
  const [showImportDialog, setShowImportDialog] = useState(false);

  const handleImport = () => {
    try {
      const school = JSON.parse(importData) as MagicSchool;
      
      // Validation basique
      if (!school.name || !school.type || !school.id) {
        throw new Error('Données d\'école invalides');
      }
      
      // Générer un nouvel ID pour éviter les conflits
      const importedSchool: MagicSchool = {
        ...school,
        id: crypto.randomUUID(),
        isShared: false, // Par défaut, les écoles importées ne sont pas partagées
        createdBy: '', // Sera mis à jour par le composant parent
      };

      onImportSchool(importedSchool);
      setImportData('');
      setShowImportDialog(false);
      toast.success('École de magie importée avec succès');
    } catch (error) {
      toast.error('Erreur lors de l\'import: format JSON invalide');
      console.error('Import error:', error);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setImportData(content);
    };
    reader.readAsText(file);
  };

  return (
    <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Upload className="w-4 h-4 mr-2" />
          Importer une École
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Importer une École de Magie</DialogTitle>
          <DialogDescription>
            Importez une école de magie depuis un fichier JSON ou en collant directement le contenu
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="file-upload">Charger depuis un fichier</Label>
            <div className="flex items-center gap-2 mt-2">
              <input
                id="file-upload"
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
              />
              <Button
                variant="outline"
                onClick={() => document.getElementById('file-upload')?.click()}
              >
                <FileText className="w-4 h-4 mr-2" />
                Choisir un fichier JSON
              </Button>
            </div>
          </div>

          <div>
            <Label htmlFor="import-data">Ou coller le JSON directement</Label>
            <Textarea
              id="import-data"
              value={importData}
              onChange={(e) => setImportData(e.target.value)}
              placeholder="Collez ici le contenu JSON de l'école de magie..."
              rows={12}
              className="font-mono text-sm"
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowImportDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleImport} disabled={!importData.trim()}>
              <Upload className="w-4 h-4 mr-2" />
              Importer
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}