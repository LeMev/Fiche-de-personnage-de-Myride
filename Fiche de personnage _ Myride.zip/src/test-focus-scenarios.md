# Tests manuels pour le système Focus

## Tests à effectuer

### 1. Interface utilisateur
- [ ] Le bouton Focus est visible dans l'onglet Magie en permanence
- [ ] Le bouton a deux états visuels distincts (activé/désactivé)
- [ ] Le tooltip s'affiche correctement au survol
- [ ] Le bouton fonctionne au clavier (Espace/Entrée)
- [ ] Sur mobile, le bouton reste visible et accessible

### 2. Toggle du Focus
- [ ] Premier clic active le Focus → toast "Focus activé : -1 PM à chaque consommation"
- [ ] Deuxième clic désactive le Focus → toast "Focus désactivé"
- [ ] L'état persiste quand on change d'onglet et revient sur Magie
- [ ] L'état persiste quand on recharge l'application

### 3. Coûts de magie (sorts)
- [ ] Sort coûtant 3 PM avec Focus activé → 2 PM déduits
- [ ] Sort coûtant 1 PM avec Focus activé → 0 PM déduits
- [ ] Sort coûtant 0 PM avec Focus activé → 0 PM déduits (pas de changement)
- [ ] Message affiché : "Sort utilisé (-2 PM, Focus : -1)" pour un coût de 3 PM
- [ ] Focus désactivé → coûts normaux

### 4. Coûts de capacités
- [ ] Capacité coûtant des PM avec Focus activé → réduction appliquée
- [ ] Capacité coûtant des PV + PM → seuls les PM sont réduits
- [ ] Message approprié avec indication de la réduction Focus

### 5. Gestion des erreurs
- [ ] PM insuffisants : vérification avec le coût réduit
- [ ] Annulation d'action → pas de réduction appliquée
- [ ] Plusieurs ressources dans une action → une seule réduction par action

### 6. Persistance des données
- [ ] Sauvegarde de personnage → l'état Focus est conservé
- [ ] Chargement de personnage → l'état Focus est restauré
- [ ] Nouveau personnage → Focus désactivé par défaut

### 7. Repos (court/long)
- [ ] Le Focus ne se remet PAS automatiquement à zéro après repos
- [ ] L'utilisateur doit manuellement désactiver le Focus

## Calculs attendus

### Coûts PM avec Focus
- 5 PM → 4 PM (réduction de 1)
- 3 PM → 2 PM (réduction de 1)  
- 1 PM → 0 PM (réduction de 1, minimum 0)
- 0 PM → 0 PM (pas de réduction si coût = 0)

### Messages toast attendus
- Activation : "Focus activé : -1 PM à chaque consommation"
- Désactivation : "Focus désactivé"
- Utilisation avec réduction : "Sort utilisé (-X PM, Focus : -1)"
- Utilisation sans réduction : "Sort utilisé (-X PM)"