import { Shield, Sword, Package, HelpCircle } from 'lucide-react';

export const CATEGORY_ICONS = {
  weapon: Sword,
  armor: Shield,
  consumable: Package,
  quest: Package,
  unknown: HelpCircle,
  misc: Package,
  container: Package,
};

export const CATEGORY_LABELS = {
  weapon: 'Arme',
  armor: 'Armure',
  consumable: 'Consommable',
  quest: 'Quête',
  unknown: 'Inconnu',
  misc: 'Divers',
  container: 'Conteneur',
};

export const RARITY_COLORS = {
  common: 'default',
  uncommon: 'secondary',
  rare: 'outline',
  epic: 'destructive',
  legendary: 'default',
} as const;

export const WEIGHT_UNITS = [
  { value: 'kg', label: 'kg' },
  { value: 'g', label: 'g' },
  { value: 'lb', label: 'lb' },
  { value: 'oz', label: 'oz' },
];

export const ENCUMBRANCE_COLORS = {
  light: 'text-green-600',
  medium: 'text-yellow-600',
  heavy: 'text-orange-600',
  overloaded: 'text-red-600',
  none: 'text-muted-foreground',
};

export const ENCUMBRANCE_LABELS = {
  light: 'Légère',
  medium: 'Moyenne',
  heavy: 'Lourde',
  overloaded: 'Surchargé',
  none: 'Aucune',
};