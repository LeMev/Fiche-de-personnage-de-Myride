export const ACTIVATION_TYPES = [
  { value: 'action', label: 'Action' },
  { value: 'bonus', label: 'Action bonus' },
  { value: 'reaction', label: 'Réaction' },
  { value: 'free', label: 'Gratuit' },
  { value: 'rest', label: 'Repos' },
] as const;

export const FREQUENCY_OPTIONS = [
  { value: 'unlimited', label: 'Illimité' },
  { value: 'once-per-turn', label: 'Une fois par tour' },
  { value: 'once-per-day', label: 'Une fois par jour' },
  { value: 'charges', label: 'Charges' },
  { value: 'cooldown', label: 'Récupération' },
] as const;

export const REST_REFRESH_OPTIONS = [
  { value: 'none', label: 'Aucune' },
  { value: 'short', label: 'Repos court' },
  { value: 'long', label: 'Repos long' },
] as const;

export const RESOURCE_TYPES = [
  { value: 'PM', label: 'PM' },
  { value: 'PV', label: 'PV' },
  { value: 'MM', label: 'MM' },
] as const;

export const SORT_OPTIONS = [
  { value: 'name', label: 'Nom' },
  { value: 'type', label: 'Type' },
  { value: 'activationType', label: 'Activation' },
  { value: 'createdAt', label: 'Date création' },
] as const;

export const TYPE_FILTER_OPTIONS = [
  { value: 'all', label: 'Tous' },
  { value: 'passive', label: 'Passifs' },
  { value: 'active', label: 'Actifs' },
] as const;

export const COST_FILTER_OPTIONS = [
  { value: 'all', label: 'Tous' },
  { value: 'with-cost', label: 'Avec coût' },
  { value: 'no-cost', label: 'Sans coût' },
] as const;

export const getActivationTypeLabel = (type: string | undefined) => {
  return ACTIVATION_TYPES.find(t => t.value === type)?.label || type;
};

export const getFrequencyLabel = (frequency: string | undefined, ability: any) => {
  switch (frequency) {
    case 'once-per-turn':
      return 'Une fois par tour';
    case 'once-per-day':
      return `${ability.dailyUses || 1} fois par jour`;
    case 'charges':
      return `${ability.charges || 0}/${ability.maxCharges || 0} charges`;
    case 'cooldown':
      return `Récupération ${ability.cooldownTurns || 0} tours`;
    case 'unlimited':
      return 'Illimité';
    default:
      return frequency || 'Illimité';
  }
};