import type { GlossaryItem, GlossaryFolder } from '../types/game';

/**
 * Preset glossary items (catalogue)
 * These are example items that users can use as templates
 */
export const PRESET_GLOSSARY_ITEMS: GlossaryItem[] = [
  // Example Abilities
  {
    id: 'preset-ability-1',
    type: 'capacité',
    name: 'Esquive acrobatique',
    tags: ['défense', 'mouvement'],
    description: 'Permet d\'esquiver une attaque en effectuant une roulade spectaculaire.',
    costProfiles: [
      {
        context: 'Combat',
        resources: [
          { id: crypto.randomUUID(), type: 'PM', amount: 2, perUnit: '' }
        ]
      }
    ],
    activationType: 'reaction',
    frequency: 'unlimited',
    effects: 'Augmente la défense de +5 contre une attaque.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    source: 'catalogue',
  },
  {
    id: 'preset-ability-2',
    type: 'capacité',
    name: 'Frappe puissante',
    tags: ['attaque', 'corps à corps'],
    description: 'Une frappe dévastatrice qui inflige des dégâts supplémentaires.',
    costProfiles: [
      {
        context: 'Combat',
        resources: [
          { id: crypto.randomUUID(), type: 'PM', amount: 3, perUnit: '' }
        ]
      }
    ],
    activationType: 'action',
    frequency: 'unlimited',
    effects: 'Inflige +1d6 dégâts supplémentaires.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    source: 'catalogue',
  },
  {
    id: 'preset-ability-3',
    type: 'capacité',
    name: 'Régénération naturelle',
    tags: ['passive', 'soin'],
    description: 'Récupère naturellement des points de vie au fil du temps.',
    costProfiles: [],
    activationType: undefined,
    frequency: 'unlimited',
    effects: 'Régénère 1 PV par tour au repos.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    source: 'catalogue',
  },
  
  // Example Magic Spells
  {
    id: 'preset-spell-1',
    type: 'magie',
    name: 'Projectile magique',
    school: 'Évocation',
    tags: ['attaque', 'distance'],
    description: 'Lance un projectile d\'énergie magique vers une cible.',
    costProfiles: [
      {
        id: crypto.randomUUID(),
        context: 'Standard',
        resources: [
          { id: crypto.randomUUID(), type: 'PM', amount: 2, perUnit: '' }
        ]
      }
    ],
    activationType: 'action',
    range: '30m',
    duration: 'Instantané',
    scaling: '+1d4 dégâts par 2 PM supplémentaires',
    effects: 'Inflige 1d6 dégâts de force.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    source: 'catalogue',
  },
  {
    id: 'preset-spell-2',
    type: 'magie',
    name: 'Bouclier arcanique',
    school: 'Abjuration',
    tags: ['défense', 'protection'],
    description: 'Crée un bouclier d\'énergie magique protectrice.',
    costProfiles: [
      {
        id: crypto.randomUUID(),
        context: 'Standard',
        resources: [
          { id: crypto.randomUUID(), type: 'PM', amount: 3, perUnit: '' }
        ]
      }
    ],
    activationType: 'bonus',
    range: 'Soi-même',
    duration: '1 minute',
    effects: 'Accorde +3 en armure.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    source: 'catalogue',
  },
  {
    id: 'preset-spell-3',
    type: 'magie',
    name: 'Soins mineurs',
    school: 'Évocation',
    tags: ['soin', 'support'],
    description: 'Soigne les blessures légères d\'un allié.',
    costProfiles: [
      {
        id: crypto.randomUUID(),
        context: 'Standard',
        resources: [
          { id: crypto.randomUUID(), type: 'PM', amount: 2, perUnit: '' }
        ]
      }
    ],
    activationType: 'action',
    range: 'Toucher',
    duration: 'Instantané',
    scaling: '+1d4 PV par PM supplémentaire',
    effects: 'Restaure 1d6 PV.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    source: 'catalogue',
  },
  {
    id: 'preset-spell-4',
    type: 'magie',
    name: 'Détection de la magie',
    school: 'Divination',
    tags: ['détection', 'utilitaire'],
    description: 'Révèle la présence de magie dans les environs.',
    costProfiles: [
      {
        id: crypto.randomUUID(),
        context: 'Rituel',
        resources: [
          { id: crypto.randomUUID(), type: 'PM', amount: 1, perUnit: '' }
        ]
      }
    ],
    activationType: 'ritual',
    range: '10m',
    duration: '10 minutes',
    effects: 'Détecte les auras magiques dans un rayon de 10m.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    source: 'catalogue',
  },
];

/**
 * Default glossary folders
 */
export const DEFAULT_GLOSSARY_FOLDERS: GlossaryFolder[] = [
  {
    id: 'folder-combat',
    name: 'Combat',
    order: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'folder-utility',
    name: 'Utilitaire',
    order: 2,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'folder-defense',
    name: 'Défense',
    order: 3,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];