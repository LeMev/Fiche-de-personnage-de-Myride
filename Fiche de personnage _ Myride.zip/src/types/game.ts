export interface Campaign {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
}

export interface Character {
  id: string;
  campaignId: string;
  role: 'GM' | 'PC';
  
  // Identity
  name: string;
  aliases: string[];
  race: string;
  class: string;
  level: number;
  age: number;
  alignment: string;
  combatStance: string;
  appearance?: string;
  distinctiveSign?: string;
  
  // New Attributes System (6 characteristics)
  attributes: {
    corps: number;      // Body (Corps)
    vitalité: number;   // Vitality (Vitalité)
    esprit: number;     // Mind (Esprit) - formerly mentale
    habilité: number;   // Skill (Habilité)
    sociale: number;    // Social (Sociale)
    pouvoir: number;    // Power (Pouvoir)
  };
  
  // Skills System - organized by characteristic
  skills: {
    corps: {
      mouvement: number;    // formerly athlétisme
      mêlée: number;        // formerly lutte
      puissance: number;    // unchanged
    };
    vitalité: {
      endurance: number;
      résistance: number;
      récupération: number;
    };
    esprit: {              // formerly mentale
      perception: number;
      analyse: number;
      volonté: number;
    };
    habilité: {
      distance: number;     // formerly mouvement
      discrétion: number;   // unchanged
      talent: number;       // formerly technique
    };
    sociale: {
      persuasion: number;
      intimidation: number;
      représentation: number;
    };
    pouvoir: {
      incantation: number;
      canalisation: number;
      rituel: number;
    };
  };
  
  // Mastery tracking for skill bonuses
  skillMastery: {
    [skillName: string]: {
      tier: 0 | 5 | 10 | 15 | 20;
      rerollsUsed: number; // For tier 10 mastery
      rerollsAvailable: number; // Reset on long rest
    };
  };
  
  // Character progression and rest management
  progression: {
    availableSkillPoints: number; // Extra points from leveling/RP rewards
  };
  
  // Resources - Updated with armor
  resources: {
    hp: { current: number; max: number };
    mp: { current: number; max: number };
    totalArmor: number;
    armorAutocalcEnabled: boolean;
    armorManualValue?: number;
    custom: Array<{
      id: string;
      label: string;
      current: number;
      max: number;
    }>;
  };
  
  // Magic - Updated structure
  magic: {
    schools: MagicSchool[];
    expandedSchools: string[]; // Track which schools are expanded
  };
  
  // Skills/Abilities - Updated with folders
  abilities: Ability[];
  abilityFolders: Folder[];
  
  // Background
  background: {
    origin: string;
    family: string;
    personality: string;
    objectives: string;
    languages: string[];
  };
  
  // Inventory - Updated with folders and weight
  inventory: {
    items: InventoryItem[];
    folders: Folder[];
    currency: {
      bronze: number;
      silver: number;
      gold: number;
    };
    totalWeight: number; // Auto-calculated
    encumbranceThreshold?: {
      light: number;
      medium: number;
      heavy: number;
    };
  };
  
  // Focus system for magic (reduces PM costs by 1)
  focus?: {
    active: boolean;
  };
  
  // Password protection system
  lock?: {
    enabled: boolean;
    code: string; // 4-digit PIN
    updatedAt: string;
  };
  
  createdAt: string;
  updatedAt: string;
}

// Folder system for organization
export interface Folder {
  id: string;
  name: string;
  parentId?: string; // For subfolder support
  type: 'ability' | 'inventory';
  expanded?: boolean; // For UI state
  color?: string; // Optional color coding
  icon?: string; // Optional icon
}

// Updated Ability System Types with folders
export interface Ability {
  id: string;
  name: string;
  type: 'passive' | 'active';
  description: string;
  folderId?: string; // Optional folder assignment
  tags?: string[]; // Multi-tag support
  
  // Resource costs with context
  costs: AbilityCost[];
  
  // For active abilities only
  activationType?: 'action' | 'bonus' | 'reaction' | 'free' | 'rest';
  
  // Usage limitations
  frequency?: 'once-per-turn' | 'once-per-day' | 'charges' | 'cooldown' | 'unlimited';
  charges?: number;
  maxCharges?: number;
  dailyUses?: number;
  usedToday?: number;
  cooldownTurns?: number;
  currentCooldown?: number;
  restRefresh?: 'short' | 'long' | 'none';
  
  // Charge system fields
  hasCharges?: boolean;
  currentCharges?: number;
  rechargesOnLongRest?: boolean;
  
  // Prerequisites
  prerequisites?: string;
  
  // Effects and mechanics
  effects: string;
  
  // Usage tracking
  usageLog?: Array<{
    timestamp: string;
    context?: string;
  }>;
  
  createdAt: string;
  updatedAt: string;
}

// Une ressource de coût (ex: PM, PV) avec un id stable pour l'UI
export interface CostResource {
  id: string;                     // <— NOUVEAU : identifiant unique pour les clés React
  type: 'PM' | 'PV' | 'MM' | string;
  amount: number;
  perUnit?: string;               // ex: "par cible supplémentaire"
}

export interface AbilityCost {
  context: string; // "Combat", "Hors combat", "Standard", "Amélioration", etc.
  resources: CostResource[];
}

// Magic System Types
export interface MagicSchool {
  id: string;
  name: string;
  description?: string;
  type: 'elven' | 'runic'; // Changed from 'standard' to 'elven'
  isShared: boolean;
  createdBy: string; // Character ID who created it
  
  // For elven schools
  spells?: Spell[];
  
  // For runic schools
  baseRunes?: BaseRune[];
}

export interface Spell {
  id: string;
  name: string;
  description: string;
  costs: SpellCost[];
  activationType: 'action' | 'bonus' | 'reaction' | 'free' | 'ritual';
  range?: string;
  duration?: string;
  scaling?: string;
  prerequisites?: string;
  limitations?: string;
  charges?: number;
  maxCharges?: number;
  dailyUses?: number;
  cooldownTurns?: number;
  tags?: string[]; // Multi-tag support for spells
}

export interface SpellCost {
  id: string; // Unique identifier for stable keys
  context: string; // "Combat", "Hors combat", "Standard", etc.
  resources: CostResource[];
}

export interface BaseRune {
  id: string;
  code: string; // "Ea", "Vérit", "Illusio"
  name: string;
  description: string;
  masteryPercentage?: number;
  quickPowers: RunePower[];
  lastingPowers: RunePower[];
}

export interface RunePower {
  id: string;
  name: string;
  description: string;
  costs: SpellCost[];
  activationType: 'action' | 'bonus' | 'reaction' | 'free' | 'ritual';
  range?: string;
  duration?: string;
  scaling?: string;
  prerequisites?: string;
  limitations?: string;
  charges?: number;
  maxCharges?: number;
  dailyUses?: number;
  cooldownTurns?: number;
}

// Updated Inventory Item with weight and folders
export interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  weight?: number; // Weight per unit
  weightUnit?: 'kg' | 'g' | 'lb' | 'oz'; // Weight unit
  folderId?: string; // Optional folder assignment
  charges?: number;
  maxCharges?: number;
  category: 'weapon' | 'armor' | 'consumable' | 'quest' | 'unknown' | 'misc' | 'container';
  damage?: string;
  rarity?: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  notes: string;
  equipped: boolean;
  identified: boolean;
  tags?: string[]; // Multi-tag support
  
  // Charge system fields
  hasCharges?: boolean;
  currentCharges?: number;
  rechargesOnLongRest?: boolean;
  
  // Armor bonus for Total Armor calculation
  armorBonus?: number;
  
  // Container properties
  isContainer?: boolean;
  containerCapacity?: number; // Max weight it can hold
  containedItems?: string[]; // IDs of items inside this container
}

// Currency adjustment types
export interface CurrencyAdjustment {
  type: 'bronze' | 'silver' | 'gold';
  amount: number;
  operation: 'add' | 'subtract';
  timestamp: string;
  reason?: string;
}

// Encumbrance levels
export type EncumbranceLevel = 'none' | 'light' | 'medium' | 'heavy' | 'overloaded';

export type SortField = 'name' | 'level' | 'class' | 'role';
export type SortDirection = 'asc' | 'desc';

export type InventorySortField = 'name' | 'category' | 'rarity' | 'quantity' | 'weight';
export type InventoryFilterCategory = 'all' | 'weapon' | 'armor' | 'consumable' | 'quest' | 'unknown' | 'misc' | 'container';
export type InventoryFilterEquipped = 'all' | 'equipped' | 'unequipped';

// Ability-specific types for filtering and sorting
export type AbilitySortField = 'name' | 'type' | 'activationType' | 'createdAt' | 'folder';
export type AbilityFilterType = 'all' | 'passive' | 'active';
export type AbilityFilterCost = 'all' | 'with-cost' | 'no-cost';
export type AbilityFilterUsage = 'all' | 'used-today' | 'available';

// Characteristics and Skills System Types
export type CharacteristicName = 'corps' | 'vitalité' | 'esprit' | 'habilité' | 'sociale' | 'pouvoir';

export interface CharacteristicDefinition {
  name: CharacteristicName;
  label: string;
  skills: SkillDefinition[];
}

export interface SkillDefinition {
  key: string;
  label: string;
  characteristic: CharacteristicName;
}

export interface MasteryTier {
  level: 0 | 5 | 10 | 15 | 20;
  name: string;
  description: string;
  criticalSuccess?: string;
  criticalFailure?: string;
  special?: string;
}

export interface AttributeValidationResult {
  isValid: boolean;
  remainingPoints: number;
  totalPoints: number;
  expectedTotal: number;
  maxBudget: number;
  errors: string[];
}

export interface SkillAllocationResult {
  [characteristic: string]: {
    available: number;
    used: number;
    canSpend: number;
  };
}

// Search and navigation types
export interface SearchResult {
  id: string;
  name: string;
  type: 'spell' | 'ability' | 'item' | 'school' | 'rune';
  description?: string;
  location: string; // Which section/school/folder it belongs to
  tags?: string[];
}

// UI State management
export interface UIState {
  expandedFolders: string[];
  expandedSchools: string[];
  searchQuery: string;
  selectedItems: string[];
}

// Glossary system for preset abilities and spells
export interface GlossaryItem {
  id: string;
  type: 'capacité' | 'magie';
  name: string;
  school?: string; // For magic spells only
  tags: string[];
  folderId?: string; // Optional folder assignment
  description: string;
  costProfiles: AbilityCost[] | SpellCost[]; // Depends on type
  createdAt: string;
  updatedAt: string;
  source: 'catalogue' | 'user'; // Whether it's from catalog or user-created
  
  // For abilities
  activationType?: 'action' | 'bonus' | 'reaction' | 'free' | 'rest' | 'ritual';
  frequency?: 'once-per-turn' | 'once-per-day' | 'charges' | 'cooldown' | 'unlimited';
  prerequisites?: string;
  effects?: string;
  
  // For magic spells
  range?: string;
  duration?: string;
  scaling?: string;
  limitations?: string;
}

export interface GlossaryFolder {
  id: string;
  parentId?: string; // For subfolder support
  name: string;
  order: number; // For custom ordering
  createdAt: string;
  updatedAt: string;
}

export type GlossarySortField = 'name' | 'school' | 'type' | 'createdAt';
export type GlossaryFilterType = 'all' | 'capacité' | 'magie';